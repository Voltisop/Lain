
const { Client, Intents, MessageEmbed } = require('discord.js');
const db = '/root/bot/tools/db/autopfp.json';
const db2 = '/root/bot/tools/db/autobanner.json';
const icons = '/root/bot/tools/images/icons';
const banners = '/root/bot/tools/images/banners';
const logging = require('/root/bot/tools/logging.js');
const config = '/root/bot/tools/config.json';
const Discord = require('discord.js');
const colors = require('colors');
const path = require('path');
const fs = require('fs');

const sessionIntents = [
  Intents.FLAGS.GUILDS,
  Intents.FLAGS.GUILD_MEMBERS,
  Intents.FLAGS.GUILD_BANS,
  Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
  Intents.FLAGS.GUILD_INTEGRATIONS,
  Intents.FLAGS.GUILD_WEBHOOKS,
  Intents.FLAGS.GUILD_INVITES,
  Intents.FLAGS.GUILD_VOICE_STATES,
  Intents.FLAGS.GUILD_MESSAGES,
  Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
  Intents.FLAGS.GUILD_MESSAGE_TYPING,
  Intents.FLAGS.DIRECT_MESSAGES,
  Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
  Intents.FLAGS.DIRECT_MESSAGE_TYPING,
  Intents.FLAGS.GUILD_PRESENCES,
  Intents.FLAGS.GUILD_MESSAGE_TYPING,
  
];

const session = new Client({
  partials: [
    'MESSAGE',
    'CHANNEL',
    'REACTION',
    'USER',
    'GUILD_MEMBER',
    'MESSAGE',
    'USER',
    'REACTION',
    'MESSAGE',
    'CHANNEL',
    'GUILD_MEMBER',
    'VOICE',
  ],
  intents: sessionIntents
});

session.developers = require(config).developers;
session.token = require(config).token;
session.invite = require(config).invite;
session.server = require(config).server;
session.color = require(config).color;
session.prefix = require(config).prefix;
session.mark = require(config).mark;
session.green = require(config).green;
session.grant = require(config).grant;
session.next = require(config).next;
session.previous = require(config).previous;
session.skip = require(config).skip;
session.cancel = require(config).cancel;
session.giphy = require(config).giphy;
session.gemini = require(config).gemini;
session.soundcloud = require(config).soundcloud;
session.clientId = require(config).clientId;
session.clientSecret = require(config).clientSecret;
session.wolfram = require(config).wolfram;
session.imdb = require(config).imdb;
session.timezone = require(config).timezone;
session.lastfm = require(config).lastfm;
session.fortnite = require(config).fortnite;
session.google = require(config).google;
session.cxKey = require(config).cxKey;
session.ocr = require(config).ocr;
session.command = require('/root/bot/tools/embeds/command.js').command;
session.warn = require('/root/bot/tools/embeds/warn.js').warn;
session.grant = require('/root/bot/tools/embeds/grant.js').grant;
session.neutral = require('/root/bot/tools/embeds/neutral.js').neutral;
session.log = require('/root/bot/tools/logging.js')
session.pagination = require('/root/bot/tools/paginator.js')
session.commands = new Discord.Collection();
session.aliases = new Discord.Collection();
session.log = logging.logger;

session.on('ready', () => {

  session.log('Connection:', `Logged in as ${session.user.username} (${session.user.id})`);
});

const getRandomPfpUrl = async () => {
  const files = fs.readdirSync(icons);
  const randomFile = files[Math.floor(Math.random() * files.length)];
  const urls = fs.readFileSync(path.join(icons, randomFile), 'utf-8')
    .split('\n')
    .filter(url => url.trim().length > 0);
  return urls[Math.floor(Math.random() * urls.length)];
};

const sendPfpToChannels = async (session) => {
  if (!fs.existsSync(db)) return;

  const autopfpData = JSON.parse(fs.readFileSync(db, 'utf-8'));
  const entriesToRemove = [];

  for (const guildId in autopfpData) {
    const channelId = autopfpData[guildId].channelId;
    const guild = session.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);

    if (channel?.isText()) {
      try {
        const pfpUrl = await getRandomPfpUrl();
        await channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(session.color)
              .setTitle(`${guild.name} pfps`)
              .setImage(pfpUrl)
              .setURL(pfpUrl)
          ]
        });
      } catch (error) {
        session.log(`Autopfp entry removed:`, `Removed ${channelId} in guild ${guildId}`, error);
      }
    } else {
      entriesToRemove.push(guildId);
    }
  }

  if (entriesToRemove.length > 0) {
    entriesToRemove.forEach(guildId => delete autopfpData[guildId]);
    fs.writeFileSync(db, JSON.stringify(autopfpData, null, 2));
    console.log('Removed invalid entries from the database:', entriesToRemove);
  }
};

setInterval(() => sendPfpToChannels(session), 40000);

const getRandomBannerUrl = async () => {
  const files = fs.readdirSync(banners);
  const randomFile = files[Math.floor(Math.random() * files.length)];
  const urls = fs.readFileSync(path.join(banners, randomFile), 'utf-8')
    .split('\n')
    .filter(url => url.trim().length > 0);
  return urls[Math.floor(Math.random() * urls.length)];
};

const sendBannerToChannels = async (session) => {
  if (!fs.existsSync(db2)) return;

  const autobannerData = JSON.parse(fs.readFileSync(db2, 'utf-8'));
  const entriesToRemove = [];

  for (const guildId in autobannerData) {
    const channelId = autobannerData[guildId].channelId;
    const guild = session.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);

    if (channel?.isText()) {
      try {
        const bannerUrl = await getRandomBannerUrl();
        await channel.send({
          embeds: [
            new MessageEmbed()
              .setColor(session.color)
              .setTitle(`${guild.name} banners`)
              .setImage(bannerUrl)
              .setURL(bannerUrl)
          ]
        });
      } catch (error) {
        session.log(`Autobanner entry removed:`, `Removed ${channelId} in guild ${guildId}`, error)
      }
    } else {
      entriesToRemove.push(guildId);
    }
  }

  if (entriesToRemove.length > 0) {
    entriesToRemove.forEach(guildId => delete autobannerData[guildId]);
    fs.writeFileSync(db2, JSON.stringify(autobannerData, null, 2));
    console.log('Removed invalid entries from the database:', entriesToRemove);
  }
};

setInterval(() => sendBannerToChannels(session), 40000);

session.login(session.token)
  .then(() => {
    session.log("Connection:", "Successfully connected to Discord API");
  })
  .catch((err) => {
    session.log("Token Login:", `Failed to log in through the Discord API. Error details: ${err}`);
    process.exit(1);
  });

function loadEvents(session, eventsDir) {
  const eventFiles = fs.readdirSync(eventsDir);

  for (const file of eventFiles) {
    const filePath = path.join(eventsDir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      loadEvents(session, filePath);
    } else if (file.endsWith('.js')) {
      try {
        const eventHandler = require(filePath);
        if (eventHandler.configuration && eventHandler.run) {
          session.on(eventHandler.configuration.eventName, (...args) => eventHandler.run(session, ...args));
          session.log("Events:", `Registered event ${eventHandler.configuration.eventName} in file ${file}`);
        } else {
          session.log("Events:", `Invalid event handler file ${file}: Missing configuration or run function`);
        }
      } catch (error) {
        session.log("Events:", `Error registering event in file ${file}: ${error.message}`);
      }
    }
  }
}

const eventsDir = '/root/bot/events';
loadEvents(session, eventsDir);

function loadCommands(session) {
  const commandsDir = '/root/bot/features';
  const commandFolders = fs.readdirSync(commandsDir);

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsDir, folder);
    if (fs.statSync(folderPath).isDirectory()) {
      const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));

      for (const file of commandFiles) {
        try {
          const commandFile = require(path.join(folderPath, file));
          if (commandFile.configuration && typeof commandFile.run === 'function') {
            session.commands.set(commandFile.configuration.name, commandFile);
            commandFile.configuration.aliases.forEach(alias => session.aliases.set(alias, commandFile.configuration.name));
            session.log("Commands:", `Registered command ${commandFile.configuration.name}`);
          } else {
            session.log("Commands:", `Invalid command file ${file}: Missing configuration or run function`);
          }
        } catch (error) {
          session.log("Commands:", `Error registering command in file ${file}: ${error.message}`);
        }
      }
    }
  }
}


loadCommands(session);