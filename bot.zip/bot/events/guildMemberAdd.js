const fs = require('fs').promises;
const { EmbedBuilder } = require('/root/bot/tools/embeds/builder.js');
const welcomeDbPath = '/root/bot/tools/db/welcome.json';
const antiraidDbPath = '/root/bot/tools/db/antiraid.json';
const antibotaddDbPath = '/root/bot/tools/db/antibotadd.json';
const autoroleFilePath = '/root/bot/tools/db/autorole.json';

module.exports = {
    configuration: {
        eventName: 'guildMemberAdd',
        devOnly: false
    },

    run: async (session, member) => {
        const guildId = member.guild.id;

        const autoroleConfig = await loadAutoroleConfig();
        if (autoroleConfig[guildId]) {
            const autoroles = autoroleConfig[guildId];
            for (const roleId of autoroles) {
                const role = member.guild.roles.cache.get(roleId);
                if (role) {
                    try {
                        await member.roles.add(role);
                    } catch (error) {
                        session.log('Error adding autorole:', error);
                    }
                }
            }
        }

        const welcomeSettings = await loadWelcomeSettings();
        const antiraidSettings = await loadAntiraidSettings();
        const antibotaddSettings = await loadAntibotaddSettings(); // Added loading of antibotadd settings

        if (welcomeSettings[guildId] && welcomeSettings[guildId].channelID && welcomeSettings[guildId].message) {
            const welcomeChannelId = welcomeSettings[guildId].channelID;
            const welcomeChannel = member.guild.channels.cache.get(welcomeChannelId);

            if (welcomeChannel && welcomeChannel.isText()) {
                let welcomeMessage = welcomeSettings[guildId].message;

                welcomeMessage = welcomeMessage
                    .replace(/{user}/g, member.user.username)
                    .replace(/{server.name}/g, member.guild.name)
                    .replace(/{server.count}/g, member.guild.memberCount)
                    .replace(/{user.mention}/g, member.toString())
                    .replace(/{user.avatar}/g, member.user.displayAvatarURL());

                const hasEmbedFormatting = welcomeMessage.includes('{');

                if (hasEmbedFormatting) {
                    try {
                        new EmbedBuilder(welcomeChannel, welcomeMessage, member.user);
                    } catch (error) {
                        session.log('Error sending embed welcome message:', error);
                    }
                } else {
                    try {
                        await welcomeChannel.send(welcomeMessage);
                    } catch (error) {
                        session.log('Error sending text welcome message:', error);
                    }
                }
            }
        }

        if (antibotaddSettings[guildId]?.enabled) {
            if (member.user.bot) {
                try {
                    await member.kick('Bot detected by antibotadd protection');
                } catch (error) {
                    console.error('Error kicking bot:', error);
                }
            }
        }

        if (antiraidSettings[guildId]?.enabled) {
            const hasDefaultAvatar = member.user.displayAvatarURL() === member.user.defaultAvatarURL;
            const accountAgeInDays = (Date.now() - member.user.createdAt) / (1000 * 60 * 60 * 24);
            const isNewAccount = accountAgeInDays < 7;
            await member.fetch();
            const isWebPresence = member.presence?.clientStatus?.web !== undefined;

            if (hasDefaultAvatar && isNewAccount && isWebPresence) {
                try {
                    await member.ban({ reason: 'Anti-raid protection' });
                } catch (error) {
                    session.log('Error banning user:', error);
                }
            }
        }
    }
};

async function loadWelcomeSettings() {
    try {
        const data = await fs.readFile(welcomeDbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading welcome settings file:', error.message);
        return {};
    }
}

async function loadAntiraidSettings() {
    try {
        const data = await fs.readFile(antiraidDbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading anti-raid settings file:', error.message);
        return {};
    }
}

async function loadAntibotaddSettings() {
    try {
        const data = await fs.readFile(antibotaddDbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading antibotadd settings file:', error.message);
        return {};
    }
}

async function loadAutoroleConfig() {
    try {
        const data = await fs.readFile(autoroleFilePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading autorole config:', error.message);
        return {};
    }
}