const { readFile } = require('fs').promises;
const { EmbedBuilder } = require('/root/bot/tools/embeds/builder.js');
const goodbyeSettingsPath = '/root/bot/tools/db/goodbye.json';

async function loadGoodbyeSettings() {
    try {
        const data = await readFile(goodbyeSettingsPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading goodbye settings file:', error.message);
        return {};
    }
}

async function handleGoodbye(session, member) {
    const guildId = member.guild.id;
    const settings = await loadGoodbyeSettings();

    if (settings[guildId] && settings[guildId].channelID && settings[guildId].message) {
        const goodbyeChannelId = settings[guildId].channelID;
        const goodbyeChannel = member.guild.channels.cache.get(goodbyeChannelId);

        if (goodbyeChannel && goodbyeChannel.isText()) {
            let goodbyeMessage = settings[guildId].message;

            const hasEmbedFormatting = goodbyeMessage.includes('{');

            if (hasEmbedFormatting) {
                try {
                    new EmbedBuilder(goodbyeChannel, goodbyeMessage, member.user);
                } catch (error) {
                    console.error('Error sending embed goodbye message:', error);
                }
            } else {
                try {
                    goodbyeMessage = goodbyeMessage
                        .replace(/{user}/g, member.user.username)
                        .replace(/{user.mention}/g, member.toString())
                        .replace(/{server.name}/g, member.guild.name)
                        .replace(/{server.count}/g, member.guild.memberCount)
                        .replace(/{user.avatar}/g, member.user.displayAvatarURL());
                    await goodbyeChannel.send(goodbyeMessage);
                } catch (error) {
                    console.error('Error sending text goodbye message:', error);
                }
            }
        }
    }
}

module.exports = {
    configuration: {
        eventName: 'guildMemberRemove',
        devOnly: false
    },

    run: async (session, member) => {
        await handleGoodbye(session, member);
    }
};
