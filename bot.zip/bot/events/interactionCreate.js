const fs = require('fs');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        eventName: 'interactionCreate',
        devOnly: false
    },
    run: async (session, interaction) => {
        try {
            if (!interaction.isMessageComponent()) return;

            let ticketsConfig;
            let config;

            try {
                ticketsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/ticket.json', 'utf8'));
                config = JSON.parse(fs.readFileSync('/root/bot/tools/db/tickets.json', 'utf8'));
            } catch (error) {
                console.error('Error loading ticket configuration:', error);
                return;
            }

            const ticketData = Object.values(ticketsConfig).find(data => data.messageLink === interaction.message.url);
            if (!ticketData) return;

            const existingTicketChannel = Object.keys(config).find(channelID => config[channelID] === interaction.user.id);
            if (existingTicketChannel) {
                interaction.reply({
                    embeds: [
                        new MessageEmbed()
                            .setColor(session.warn)
                            .setDescription(`${session.mark} ${interaction.user}: You already have a ticket open`)
                    ],
                    ephemeral: true
                });
                return;
            }

            if (!ticketData.category) {
                console.error('Parent category ID not found.');
                interaction.reply({
                    content: 'Error: Parent category not found. Please contact the server administrator.',
                    ephemeral: true
                });
                return;
            }

            const ticketChannel = await interaction.guild.channels.create(`${interaction.user.username}s-ticket`, {
                type: 'text',
                parent: ticketData.category,
                permissionOverwrites: [
                    { id: interaction.guild.roles.everyone, deny: ['VIEW_CHANNEL'] },
                    { id: interaction.user.id, allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'] }
                ]
            });

            ticketChannel.send({
                content: `${interaction.user}`,
                embeds: [
                    new MessageEmbed()
                        .setColor(session.color)
                        .setTitle('Ticket created')
                        .setDescription(`Please wait for staff to the answer the ticket`)
                ]
            });

            config[ticketChannel.id] = interaction.user.id;
            fs.writeFileSync('/root/bot/tools/db/tickets.json', JSON.stringify(config, null, 4));

            interaction.reply({
                content: `Ticket channel ${ticketChannel} created successfully.`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Error handling interaction:', error);
            interaction.reply({
                content: 'An error occurred while processing your request.',
                ephemeral: true
            });
        }
    }
};
