const { MessageAttachment, MessageEmbed } = require('discord.js');
const reposting = '/root/bot/tools/db/reposter.json';
const imageonly = '/root/bot/tools/db/imageonly.json';
const prefixdb = '/root/bot/tools/db/prefix.json';
const filterinvitesdb = '/root/bot/tools/db/filterinvites.json';
const commandsdb = '/root/bot/tools/db/commands.json';
const filterPath = '/root/bot/tools/db/chatfilter.json';
const fs = require('fs');
const axios = require('axios');
const ytdl = require('ytdl-core');
const cooldowns = new Map();

module.exports = {
    configuration: {
        eventName: 'messageCreate',
        devOnly: false
    },
    run: async (session, message) => {
        if (message.author.bot || message.channel.type === 'DM' || message.webhookID || message.system || message.partial) return;

        const filterWords = loadFilterWords()[message.guild.id]?.words;
        if (filterWords && filterWords.length > 0) {
            const isAdministrator = message.member.permissions.has('ADMINISTRATOR');
            const canManageGuild = message.member.permissions.has('MANAGE_GUILD');
            if (!isAdministrator && !canManageGuild) {
                const lowerCaseContent = message.content.toLowerCase();
                const containsFilteredWord = filterWords.some(word => lowerCaseContent.includes(word));

                if (containsFilteredWord) {
                    try {
                        await message.delete();
                    } catch (error) {
                        console.error('Error deleting filtered word message:', error);
                    }
                    return;
                }
            }
        }

        if (isInviteFilterEnabled(message.guild.id) && containsInviteLink(message.content) && !message.member.permissions.has('ADMINISTRATOR')) {
            message.delete().catch(err => session.log('Error deleting invite link message:', err));
            return;
        }

        if (isImageOnlyChannel(message.guild.id, message.channel.id) && !message.attachments.size) {
            message.delete().catch(err => console.error('Error deleting non-image message:', err));
            return;
        }

        if (message.content.includes('instagram.com')) {
            if (!isRepostingEnabled(message.guild.id)) {
                return;
            }

            try {
                const regex = /(https?:\/\/(?:www\.)?instagram\.com\/[-a-zA-Z0-9@:%._\+~#=\/]+)/g;
                const instagramUrls = message.content.match(regex);
                for (const instagramUrl of instagramUrls) {
                    const response = await axios.get('https://instagram-post-downloader.p.rapidapi.com/', {
                        params: { url: instagramUrl },
                        headers: {
                            'X-RapidAPI-Key': '141e070f61mshebb9f8f7dac8e8fp179694jsnb651b7323525',
                            'X-RapidAPI-Host': 'instagram-post-downloader.p.rapidapi.com'
                        }
                    });

                    const downloadUrl = response.data.data[0].download;
                    const thumbnailUrl = response.data.data[0].thumbnail;
                    let filename = 'lain_instagram';
                    let fileExtension = downloadUrl ? '.mp4' : '.png';

                    const urlToSend = downloadUrl || thumbnailUrl;
                    const attachment = new MessageAttachment(urlToSend, `${filename}${fileExtension}`);
                    message.channel.send({ files: [attachment] });
                }
            } catch (error) {
                console.error('Error sending a request to Instagram Post Downloader:', error);
            }
        }

        if (message.content.includes('discord.com/channels')) {
            if (!isRepostingEnabled(message.guild.id)) {
                return;
            }

            try {
                const regex = /https?:\/\/discord\.com\/channels\/(\d+)\/(\d+)\/(\d+)/;
                const matches = message.content.match(regex);
                if (!matches) return;
                const [_, guildId, channelId, messageId] = matches;
                const guild = message.client.guilds.cache.get(guildId);
                if (!guild) return;
                const channel = guild.channels.cache.get(channelId);
                if (!channel) return;
                const fetchedMessage = await channel.messages.fetch(messageId);
                if (!fetchedMessage) return;
                const embed = new MessageEmbed()
                    .setAuthor(fetchedMessage.author.username, fetchedMessage.author.displayAvatarURL())
                    .setDescription(fetchedMessage.content)
                    .setColor('#00ff00')
                    .setImage(fetchedMessage.attachments.first()?.url);
                message.channel.send({ embeds: [embed] });
            } catch (error) {
                console.error('Error fetching Discord message:', error);
            }
        }

        if (message.content.includes('tiktok.com')) {
            if (!isRepostingEnabled(message.guild.id)) {
                return;
            }

            message.delete().catch(err => console.error('Error deleting message:', err));
            try {
                const tiktokUrl = message.content.match(/(https?:\/\/.*?tiktok\.com[^$>\s]+)/g)[0];
                const response = await axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`);
                const data = response.data.data;

                const videoAttachment = new MessageAttachment(data.play, 'lain_tiktok.mp4');
                message.channel.send({ files: [videoAttachment] });
            } catch (error) {
                console.error('Error downloading TikTok video:', error);
            }
        }

        if (message.content.includes('youtube.com') || message.content.includes('youtu.be')) {
            if (!isRepostingEnabled(message.guild.id)) {
                return;
            }

            message.delete().catch(err => console.error('Error deleting message:', err));
            try {
                const urlMatches = message.content.match(/(https?:\/\/(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([^"&?\/\s]{11}))/);
                if (!urlMatches || urlMatches.length < 2) {
                    return;
                }
                const url = urlMatches[0];

                const stream = ytdl(url, { filter: 'videoandaudio' });

                const attachment = new MessageAttachment(stream, 'lain_youtube.mp4');
                message.channel.send({ files: [attachment] });
            } catch (error) {
                console.error('Error downloading YouTube video:', error);
            }
        }

        const prefix = getPrefix(message.guild.id, session.prefix);
        if (message.content.startsWith(prefix)) {
            const args = message.content.slice(prefix.length).trim().split(/ +/);
            const commandName = args.shift().toLowerCase();

            if (isCommandDisabled(message.guild.id, commandName)) {
                return;
            }

            const command = session.commands.get(commandName) || session.commands.get(session.aliases.get(commandName));
            if (!command) return;

            if (!cooldowns.has(commandName)) {
                cooldowns.set(commandName, new Map());
            }

            const now = Date.now();
            const timestamps = cooldowns.get(commandName);
            const cooldownAmount = 2000;

            if (timestamps.has(message.author.id)) {
                const expirationTime = timestamps.get(message.author.id) + cooldownAmount;

                if (now < expirationTime) {
                    const timeLeft = (expirationTime - now) / 1000;
                    session.warn(session, message, `Please wait ${timeLeft.toFixed(1)} more second(s)`);
                    return;
                }
            }

            timestamps.set(message.author.id, now);
            setTimeout(() => timestamps.delete(message.author.id), cooldownAmount);
            message.channel.sendTyping();

            command.run(session, message, args)
                .then(() => {
                })
                .catch(error => {
                    console.error('Error executing command:', error);
                });

            const log = require('/root/bot/tools/logging.js').logger;
            log("Commands:", `${message.author.username} used command '${command.configuration.name}' in ${message.guild ? message.guild.name : 'DMs'} (${message.guild ? message.guild.id : 'N/A'})`);
        }
    }
};

function isInviteFilterEnabled(guildID) {
    if (fs.existsSync(filterinvitesdb)) {
        const filterInvitesData = JSON.parse(fs.readFileSync(filterinvitesdb, 'utf8'));
        return filterInvitesData[guildID]?.enabled === true;
    }
    return false;
}

function containsInviteLink(content) {
    const inviteRegex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/[^\s/]+/i;
    return inviteRegex.test(content);
}

function isImageOnlyChannel(guildID, channelID) {
    if (fs.existsSync(imageonly)) {
        const imageOnlyData = JSON.parse(fs.readFileSync(imageonly, 'utf8'));
        if (imageOnlyData[guildID] && imageOnlyData[guildID].includes(channelID)) {
            return true;
        }
    }
    return false;
}

function isRepostingEnabled(guildID) {
    if (fs.existsSync(reposting)) {
        const repostersConfig = JSON.parse(fs.readFileSync(reposting, 'utf8'));
        return repostersConfig[guildID] === true;
    }
    return false;
}

function embeds(guildID) {
    const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json', 'utf8'));
    return embedsConfig[guildID] || false;
}

function getPrefix(guildID, defaultPrefix) {
    if (fs.existsSync(prefixdb)) {
        const prefixData = JSON.parse(fs.readFileSync(prefixdb, 'utf8'));
        return prefixData[guildID] || defaultPrefix;
    }
    return defaultPrefix;
}

function isCommandDisabled(guildID, commandName) {
    if (fs.existsSync(commandsdb)) {
        const commandData = JSON.parse(fs.readFileSync(commandsdb, 'utf8'));
        return commandData[guildID] && commandData[guildID].includes(commandName);
    }
    return false;
}

function loadFilterWords() {
    try {
        const data = fs.readFileSync(filterPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading filter words:', error);
        return {};
    }
}