const fs = require('fs').promises;
const { Permissions } = require('discord.js');
const dbPath = '/root/bot/tools/db/antiselfreact.json';

module.exports = {
    configuration: {
        eventName: 'messageReactionAdd',
        devOnly: false
    },
    
    run: async (session, reaction, user) => {
        if (!reaction || !user) return;

        const guildId = reaction.message.guild.id;

        const antiselfreactSettings = await loadAntiselfreactSettings();

        if (antiselfreactSettings[guildId]?.enabled) {
            const guildMember = reaction.message.guild.members.cache.get(user.id);
            if (!guildMember) return;

            if (guildMember.user.bot || guildMember.permissions.has(Permissions.FLAGS.ADMINISTRATOR) || guildMember.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
                return;
            }

            if (reaction.message.author.id === user.id) {
                try {
                    await reaction.users.remove(user);
                } catch (error) {
                    session.log('Error removing reaction from own message:', error);
                }
            }
        }
    }
};

async function loadAntiselfreactSettings() {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading antiselfreact settings file:', error.message);
        return {};
    }
}
