const fs = require('fs');
const path = require('path');

const voicemasterDataPath = '/root/bot/tools/db/voicemaster.json';
const voiceConfigPath = '/root/bot/tools/db/configuration.json';

module.exports = {
    configuration: {
        eventName: 'voiceStateUpdate',
        devOnly: false
    },
    run: async (session, oldState, newState) => {
        const guildID = newState.guild.id;

        if (!fs.existsSync(voicemasterDataPath)) return;

        const voicemasterData = JSON.parse(fs.readFileSync(voicemasterDataPath));
        if (!voicemasterData[guildID]) return;

        const { categoryID, channelID, customName } = voicemasterData[guildID];
        if (newState.channelId !== channelID) return;

        const user = newState.member;
        let channelName = customName ? customName.replace('{user}', user.user.username) : `${user.user.username}'s channel`;

        const userVoiceChannel = await newState.guild.channels.create(channelName, {
            type: 'GUILD_VOICE',
            parent: categoryID
        });
        await user.voice.setChannel(userVoiceChannel.id);

        const intervalID = setInterval(async () => {
            if (userVoiceChannel.members.size === 0) {
                await userVoiceChannel.delete();
                clearInterval(intervalID);
                removeVoiceConfigEntry(user.id);
            } else {
                updateVoiceConfigEntry(user.id, userVoiceChannel.id);
            }
        }, 1000);
    }
};

function updateVoiceConfigEntry(userID, voiceChannelID) {
    try {
        const voiceConfigData = fs.existsSync(voiceConfigPath) 
            ? JSON.parse(fs.readFileSync(voiceConfigPath)) 
            : {};
        voiceConfigData[userID] = voiceChannelID;
        fs.writeFileSync(voiceConfigPath, JSON.stringify(voiceConfigData, null, 4));
    } catch (error) {
        console.error('Error updating voice config:', error);
    }
}

function removeVoiceConfigEntry(userID) {
    try {
        if (!fs.existsSync(voiceConfigPath)) return;

        const voiceConfigData = JSON.parse(fs.readFileSync(voiceConfigPath));
        delete voiceConfigData[userID];
        fs.writeFileSync(voiceConfigPath, JSON.stringify(voiceConfigData, null, 4));
    } catch (error) {
        console.error('Error removing voice config entry:', error);
    }
}
