const dbPath = '/root/bot/tools/db/antiraid.json';
const { Permissions } = require('discord.js');
const fs = require('fs');
const trustedDbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'antiraid',
        aliases: ['antir'],
        description: 'Automatically ban suspicious users',
        syntax: 'antiraid [enable|disable]',
        module: 'automod'
    },

    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageGuildPermissions && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const subcommand = args.shift().toLowerCase();
        let antiraidConfig = {};
        if (fs.existsSync(dbPath)) {
            antiraidConfig = JSON.parse(fs.readFileSync(dbPath));
        }

        switch (subcommand) {
            case 'enable':
                antiraidConfig[message.guild.id] = { enabled: true };
                fs.writeFileSync(dbPath, JSON.stringify(antiraidConfig, null, 2));
                return message.react('✅');

            case 'disable':
                delete antiraidConfig[message.guild.id];
                fs.writeFileSync(dbPath, JSON.stringify(antiraidConfig, null, 2));
                return message.react('✅');

            default:
                return session.command(module.exports, session, message);
        }
    }
}
