const fs = require('fs');
const { Permissions } = require('discord.js');
const dbPath = '/root/bot/tools/db/antiselfreact.json';

module.exports = {
    configuration: {
        name: 'antiselfreact',
        aliases: ['antireact'],
        description: 'Prevents users from reacting to their own messages',
        syntax: 'antiselfreact [enable|disable]',
        module: 'automod'
    },

    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        const isServerOwner = message.guild.ownerId === message.author.id;

        if (!hasManageGuildPermissions && !isServerOwner) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const subcommand = args.shift().toLowerCase();

        let settings = {};
        try {
            if (fs.existsSync(dbPath)) {
                const data = fs.readFileSync(dbPath, 'utf8');
                settings = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the settings database.');
        }

        switch (subcommand) {
            case 'enable':
                settings[message.guild.id] = { enabled: true };
                fs.writeFileSync(dbPath, JSON.stringify(settings, null, 2));
                return message.react('✅');

            case 'disable':
                delete settings[message.guild.id];
                fs.writeFileSync(dbPath, JSON.stringify(settings, null, 2));
                return message.react('✅');

            default:
                return session.command(module.exports, session, message);
        }
    }
};
