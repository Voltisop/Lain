const fs = require('fs');
const { Permissions } = require('discord.js');
const filterPath = '/root/bot/tools/db/chatfilter.json';
const trustedDbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'chatfilter',
        aliases: ['filter'],
        description: 'Manage the chat filter',
        syntax: 'chatfilter [remove|add] <word>',
        example: 'chatfilter add poop',
        module: 'automod',
        subcommands: ['> chatfilter add\n> chatfilter remove\n> chatfilter reset'],
    },
    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageGuildPermissions && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args[0]) {
            return session.command(module.exports, session, message);
        }

        const subcommand = args[0].toLowerCase();
        const guildID = message.guild.id;

        const loadFilterWords = () => {
            try {
                const data = fs.readFileSync(filterPath, 'utf8');
                return JSON.parse(data);
            } catch (error) {
                session.log('Error reading filter words file:', error.message);
                return {};
            }
        };

        const saveFilterWords = (filterWords) => {
            try {
                fs.writeFileSync(filterPath, JSON.stringify(filterWords, null, 2), 'utf8');
            } catch (error) {
                session.log('Error writing filter words file:', error.message);
            }
        };

        switch (subcommand) {
            case 'add': {
                if (args.length < 2) {
                    return session.warn(session, message, 'Please provide a word to add to the chat filter');
                }
                const wordToAdd = args[1].toLowerCase();
                const filterWords = loadFilterWords();

                if (!filterWords[guildID]) {
                    filterWords[guildID] = { words: [] };
                }

                if (filterWords[guildID].words.length < 8) {
                    filterWords[guildID].words.push(wordToAdd);
                    saveFilterWords(filterWords);
                    return session.grant(session, message, `Added **${wordToAdd}** to the chat filter`);
                } else {
                    return session.warn(session, message, 'Chat filter already contains 8 words');
                }
            }

            case 'remove': {
                if (args.length < 2) {
                    return session.warn(session, message, 'Please provide a word to remove from the chat filter');
                }
                const wordToRemove = args[1].toLowerCase();
                const filterWords = loadFilterWords();

                if (filterWords[guildID]) {
                    const index = filterWords[guildID].words.indexOf(wordToRemove);
                    if (index !== -1) {
                        filterWords[guildID].words.splice(index, 1);
                        saveFilterWords(filterWords);
                        return session.grant(session, message, `Removed **${wordToRemove}** from the chat filter`);
                    } else {
                        return session.warn(session, message, `${wordToRemove} is not in the chat filter`);
                    }
                } else {
                    return session.warn(session, message, 'No words in the chat filter for this guild');
                }
            }

            case 'reset': {
                const filterWords = loadFilterWords();
                delete filterWords[guildID];
                saveFilterWords(filterWords);
                return session.grant(session, message, 'Chat filter has been cleared');
            }

            default:
                return session.command(module.exports, session, message);
        }
    }
};
