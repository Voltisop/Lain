const { Permissions } = require('discord.js');
const fs = require('fs');
const db = '/root/bot/tools/db/commands.json';
const trustedDbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'disablemodule',
        aliases: ['disablemod'],
        description: 'Disable all commands in a module',
        syntax: 'disablemodule <module>',
        example: 'disablemodule fun',
        module: 'automod'
    },
    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageGuildPermissions && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (args.length === 0) {
            return session.command(module.exports, session, message);
        }

        const moduleName = args[0].toLowerCase();
        if (moduleName === 'servers') {
            return session.warn(session, message, 'The servers module cannot be disabled.');
        }

        const guildID = message.guild.id;
        let commandData = {};

        if (fs.existsSync(db)) {
            commandData = JSON.parse(fs.readFileSync(db, 'utf8'));
        }

        if (!commandData[guildID]) {
            commandData[guildID] = [];
        }

        const commandsToDisable = [];
        session.commands.forEach((cmd, name) => {
            if (cmd.configuration.module === moduleName && !commandData[guildID].includes(name)) {
                commandsToDisable.push(name);
            }
        });

        if (commandsToDisable.length === 0) {
            return session.warn(session, message, 'No commands found in the specified module or they are already disabled.');
        }

        commandData[guildID].push(...commandsToDisable);
        fs.writeFileSync(db, JSON.stringify(commandData, null, 4));

        return session.grant(session, message, `All commands in the module \`${moduleName}\` have been disabled.`);
    }
};
