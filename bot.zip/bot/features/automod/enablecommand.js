const { Permissions } = require('discord.js');
const fs = require('fs');
const db = '/root/bot/tools/db/commands.json';
const trustedDbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'enablecommand',
        aliases: ['enablecmd', 'enable'],
        description: 'Enable a command',
        syntax: 'enablecommand <command>',
        example: 'enablecommand fortnite',
        module: 'automod'
    },
    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageGuildPermissions && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (args.length === 0) {
            return session.command(module.exports, session, message)
        }

        const commandName = args[0].toLowerCase();

        if (!session.commands.has(commandName) && !session.aliases.has(commandName)) {
            return session.warn(`The command \`${commandName}\` does not exist.`)
        }

        const guildID = message.guild.id;
        let commandData = {};

        if (fs.existsSync(db)) {
            commandData = JSON.parse(fs.readFileSync(db, 'utf8'));
        }

        if (!commandData[guildID]) {
            commandData[guildID] = [];
        }

        if (!commandData[guildID].includes(commandName)) {
            return session.warn(`The command \`${commandName}\` is already enabled.`)
        }

        commandData[guildID].splice(commandData[guildID].indexOf(commandName), 1);
        fs.writeFileSync(db, JSON.stringify(commandData, null, 4));

        session.grant(session, message, `The command \`${commandName}\` has been enabled`)
    }
}
