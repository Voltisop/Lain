const db = '/root/bot/tools/db/filterinvites.json';
const { Permissions } = require('discord.js');
const fs = require('fs');
const trustedDbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'filterinvites',
        aliases: ['antilink'],
        description: 'Prevent server invites from being sent',
        syntax: 'filterinvites [enable|disable]',
        module: 'automod'
    },

    run: async (session, message, args) => {
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageGuildPermissions && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const subcommand = args.shift().toLowerCase();
        let filterConfig = {};
        if (fs.existsSync(db)) {
            filterConfig = JSON.parse(fs.readFileSync(db));
        }

        switch (subcommand) {
            case 'enable':
                filterConfig[message.guild.id] = { enabled: true };
                fs.writeFileSync(db, JSON.stringify(filterConfig, null, 2));
                return message.react('✅');

            case 'disable':
                delete filterConfig[message.guild.id];
                fs.writeFileSync(db, JSON.stringify(filterConfig, null, 2));
                return message.react('✅');

            default:
                return session.command(module.exports, session, message);
        }
    }
};
