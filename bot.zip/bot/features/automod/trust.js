const { Permissions } = require('discord.js');
const fs = require('fs');
const dbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'trust',
        aliases: ['trust'],
        description: 'Trust a user to manaage automod features',
        syntax: 'trust [add|remove] (user)',
        module: 'moderation',
        subcommands: ['> trust add\n> trust remove\n> trust list\n> trust clear']
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (args.length < 1) {
            return session.command(module.exports, session, message);
        }

        let db = {};
        try {
            if (fs.existsSync(dbPath)) {
                const data = fs.readFileSync(dbPath, 'utf8');
                db = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the database.');
        }

        const guildId = message.guild.id;
        if (!db[guildId]) {
            db[guildId] = { trustedIDs: [] };
        }

        const subcommand = args[0].toLowerCase();

        switch (subcommand) {
            case 'add':
                if (args.length < 2) {
                    return session.warn(session, message, 'Please mention a user to add.');
                }
                const userToAdd = message.mentions.users.first();
                if (!userToAdd) {
                    return session.warn(session, message, 'Please mention a valid user');
                }
                if (!db[guildId].trustedIDs.includes(userToAdd.id)) {
                    db[guildId].trustedIDs.push(userToAdd.id);
                    saveDatabase(db);
                    return session.grant(session, message, `${userToAdd.tag} has been added as a trusted user`);
                } else {
                    return session.warn(session, message, `${userToAdd.tag} is already in the trusted list.`);
                }

            case 'remove':
                if (args.length < 2) {
                    return session.warn(session, message, 'Please mention a user to remove');
                }
                const userToRemove = message.mentions.users.first();
                if (!userToRemove) {
                    return session.warn(session, message, 'Please mention a valid user');
                }
                db[guildId].trustedIDs = db[guildId].trustedIDs.filter(id => id !== userToRemove.id);
                saveDatabase(db);
                return session.grant(session, message, `${userToRemove.tag} is no longer a trusted user`);

            case 'list':
                const trustedUsers = db[guildId].trustedIDs.map(id => `<@${id}>`).join('\n') || 'No trusted users.';
                return session.warn(session, message, `Trusted users:\n${trustedUsers}`);

            case 'clear':
                db[guildId].trustedIDs = [];
                saveDatabase(db);
                return session.warn(session, message, 'The trusted list has been cleared.');

            default:
                return session.command(module.exports, session, message);
        }
    }
};

function saveDatabase(db) {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2), 'utf8');
}
