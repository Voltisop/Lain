const fs = require('fs');

module.exports = {
    configuration: {
        name: 'commandtree',
        aliases: ['cmdtree', 'html'],
        description: 'Generate HTML source code to display all commands by module',
        usage: 'html',
        devOnly: true
    },
    run: async (session, message, args) => {
        const commandsByModule = {};
        session.commands.forEach(command => {
            const module = command.configuration.module || 'Uncategorized';
            if (module === 'Uncategorized') return;
            if (!commandsByModule[module]) {
                commandsByModule[module] = [];
            }
            commandsByModule[module].push(command);
        });

        let output = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lain - commands</title>
    <link rel="shortcut icon" href="https://lains.win/lain.png">

    <style>
@import url("https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;400&display=swap");

body {
    display: flex;
    flex-wrap: wrap;
    font-family: 'Work Sans', sans-serif;
    color: #fff;
    margin: 0;
    padding: 20px;
    background-color: #0c0d0d;
}

::-webkit-scrollbar { width: 12px; }
::-webkit-scrollbar-track { background: #1a1a1a; }
::-webkit-scrollbar-thumb {
    background-color: #101010;
    border-radius: 6px;
}
::-webkit-scrollbar-thumb:hover { background-color: #333; }

.navbar {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #0c0c0c;
    padding: 20px 20px;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
}

.navbar .left {
    display: flex;
    align-items: center;
}

.navbar .left img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.navbar .left span {
    font-size: 1.5em;
    font-weight: bold;
}

.navbar .middle {
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
}

.navbar .middle button {
    margin: 0 10px;
    background-color: #1a1a1a;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.2em;
}

.navbar .middle button:hover {
    background-color: #333;
}

.navbar .right {
    display: flex;
    align-items: center;
    margin-right: 20px;
}

.navbar .right button {
    background-color: #5865F2;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.2em;
    display: flex;
    align-items: center;
}

.navbar .right button img {
    width: 20px;
    height: 20px;
    margin-right: 5px;
}

.navbar .right button:hover {
    background-color: #4a5bd3;
}

.separator {
    width: 100%;
    height: 2px;
    margin: 70px 0 20px 0;
}

.search-container {
    width: 100%;
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}

.search-container input {
    width: 300px;
    padding: 10px;
    border: 1px solid #333;
    border-radius: 5px;
    background-color: #0c0c0c;
    color: #fff;
    font-size: 1em;
}

.tab-container {
    width: 100%;
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
    overflow-x: auto;
    white-space: nowrap;
    padding: 10px 0;
    background-color: #161717;
    border-radius: 5px;
}

.tab-container::-webkit-scrollbar { height: 12px; }
.tab-container::-webkit-scrollbar-track { background: #1a1a1a; }
.tab-container::-webkit-scrollbar-thumb {
    background-color: #161717;
    border-radius: 6px;
}
.tab-container::-webkit-scrollbar-thumb:hover { background-color: #333; }

.tab {
    background-color: #161717;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    margin: 5px;
    display: inline-block;
    font-size: 1.1em;
}

.tab:hover { background-color: #333; }

.command-box {
    position: relative;
    background-color: #111212;
    border-radius: 8px;
    text-align: center;
    margin: 10px;
    padding: 10px;
    flex: 0 0 calc(33.33% - 20px);
    box-sizing: border-box;
}

.command-box h3, .command-box p {
    color: #fff;
    font-family: 'Work Sans', sans-serif;
}

.command-box h3 { font-size: 1em; margin-bottom: 5px; }
.command-box p { font-size: 0.8em; }

.copy-icon {
    position: absolute;
    top: 5px;
    right: 5px;
    width: 20px;
    height: 20px;
    cursor: pointer;
}

    </style>

    <script>
        function copy(text) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            alert('Copied to clipboard: ' + text);
        }

        function search() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const commandBoxes = document.getElementsByClassName('command-box');

            Array.from(commandBoxes).forEach(box => {
                const module = box.getAttribute('data-module').toLowerCase();
                const name = box.getElementsByTagName('h3')[0].textContent.toLowerCase();
                const description = box.getElementsByTagName('p')[0].textContent.toLowerCase();
                const aliases = box.getElementsByTagName('p')[1].textContent.toLowerCase();

                if (module.includes(filter) || name.includes(filter) || description.includes(filter) || aliases.includes(filter)) {
                    box.style.display = '';
                } else {
                    box.style.display = 'none';
                }
            });
        }

        function filter(module) {
            const commandBoxes = document.getElementsByClassName('command-box');

            Array.from(commandBoxes).forEach(box => {
                if (module === 'All' || box.getAttribute('data-module') === module) {
                    box.style.display = '';
                } else {
                    box.style.display = 'none';
                }
            });
        }
    </script>
</head>
<body>
<body>
    <div class="navbar">
    <div class="left">
        <img src="https://lains.win/lain.png" alt="Bot Avatar">
        <span>lain</span>
    </div>
    <div class="middle">
        <button onclick="location.href='https://lains.win/status'">Status</button>
        <button onclick="location.href='https://lains.win/help'">Commands</button>
        <button onclick="location.href='https://lains.win/faq'">FAQ</button>
    </div>
    <div class="right">
        <button onclick="location.href='https://discord.com/invite/okay'">
            <img src="https://lains.win/discord.png" alt="Discord Logo">
            Discord
        </button>
    </div>
</div>
    <div class="separator"></div>

    <div class="search-container">
        <input type="text" id="searchInput" onkeyup="search()" placeholder="Search for commands...">
    </div>

    <div class="tab-container">
        <button class="tab" onclick="filter('All')">All</button>`;

        Object.keys(commandsByModule).forEach(module => {
            const capitalizedModule = module.charAt(0).toUpperCase() + module.slice(1);
            output += `<button class="tab" onclick="filter('${module}')">${capitalizedModule}</button>`;
        });

        output += `</div>`;

        Object.entries(commandsByModule).forEach(([module, commands]) => {
            commands.forEach(command => {
                const name = command.configuration.name;
                const description = command.configuration.description || 'N/A';
                const aliases = command.configuration.aliases || [];
                output += `
<div class="command-box" data-module="${module}">
    <img src="https://lains.win/copy.png" alt="Copy" class="copy-icon" onclick="copy('${name}')">
    <h3>${name}</h3>
    <p>${description}</p>
    <p>Aliases: ${aliases.join(', ')}</p>
</div>
`;
            });
        });

        output += `</body>
</html>`;

        fs.writeFile('commands.html', output, (err) => {
            if (err) throw err;
            console.log('HTML commands saved as commands.html');
        });
    }
};
