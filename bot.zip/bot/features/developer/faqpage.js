const fs = require('fs');

module.exports = {
    configuration: {
        name: 'faqpage',
        aliases: ['faq', 'htmlfaq'],
        description: 'Generate HTML source code to display FAQ',
        usage: 'faq',
        devOnly: true
    },
    run: async (session, message, args) => {
        let output = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lain - FAQ</title>
	<link rel="shortcut icon" href="https://lains.win/lain.png">

    <style>
        @import url("https://fonts.googleapis.com/css2?family=Work+Sans&display=swap");
        @import url("https://fonts.googleapis.com/css2?family=Rubik:wght@300&family=Work+Sans:wght@100;400&display=swap");

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-family: 'Work Sans', sans-serif;
            color: #fff;
            margin: 0;
            background: linear-gradient(to bottom right, #101010, #1a1a1a, #101010, #1a1a1a, #101010);
            background-size: 400% 400%;
            animation: gradientShift 15s infinite alternate;
        }

        @keyframes gradientShift {
            0% {
                background-position: 0% 0%;
            }
            100% {
                background-position: 100% 100%;
            }
        }

        .navbar {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #0c0c0c;
    padding: 20px 20px;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
}

.navbar .left {
    display: flex;
    align-items: center;
}

.navbar .left img {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    margin-right: 10px;
}

.navbar .left span {
    font-size: 1.5em;
    font-weight: bold;
}

.navbar .middle {
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
}

.navbar .middle button {
    margin: 0 10px;
    background-color: #1a1a1a;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.2em;
}

.navbar .middle button:hover {
    background-color: #333;
}

.navbar .right {
    display: flex;
    align-items: center;
    margin-right: 20px;
}

.navbar .right button {
    background-color: #5865F2;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1.2em;
    display: flex;
    align-items: center;
}

.navbar .right button img {
    width: 20px;
    height: 20px;
    margin-right: 5px;
}

.navbar .right button:hover {
    background-color: #4a5bd3;
}

        .separator {
            width: 100%;
            height: 2px;
            background-color: #ffffff;
            margin: 70px 0 20px 0;
        }



        .faq-container {
            margin-top: 80px;
            width: 60%;
        }

        .faq-item {
            background-color: #0c0c0c;
            border-radius: 8px;
            margin: 10px 0;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .faq-question {
            cursor: pointer;
            font-size: 1.2em;
            margin: 0;
            padding: 10px;
            transition: background-color 0.3s;
        }

        .faq-question:hover {
            background-color: #333;
        }

        .faq-answer {
            display: none;
            padding: 10px;
            font-size: 1em;
        }

        .separator {
            width: 100%;
            height: 2px;
            background-color: #ffffff;
            margin: 20px 0;
        }
    </style>
    <script>
        function toggleAnswer(element) {
            const answer = element.nextElementSibling;
            if (answer.style.display === "block") {
                answer.style.display = "none";
            } else {
                answer.style.display = "block";
            }
        }
    </script>
</head>
<body>
    <div class="navbar">
    <div class="left">
        <img src="https://lains.win/lain.png" alt="Bot Avatar">
        <span>lain</span>
    </div>
    <div class="middle">
        <button onclick="location.href='https://lains.win/status'">Status</button>
        <button onclick="location.href='https://lains.win/help'">Commands</button>
        <button onclick="location.href='https://lains.win/faq'">FAQ</button>
    </div>
    <div class="right">
        <button onclick="location.href='https://discord.com/invite/okay'">
            <img src="https://lains.win/discord.png" alt="Discord Logo">
            Discord
        </button>
    </div>
</div>
    <div class="faq-container">
        <div class="faq-item">
            <h3 class="faq-question" onclick="toggleAnswer(this)">What is lain?</h3>
            <div class="faq-answer">
                <p>lain is a multifunctional bot designed to assist with various tasks on your server, from moderation to entertainment.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question" onclick="toggleAnswer(this)">How do I invite lain to my server?</h3>
            <div class="faq-answer">
                <p>You can invite lain to your server by clicking on the invitation link provided on the Discord Bot List or our official website.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question" onclick="toggleAnswer(this)">What commands does lain have?</h3>
            <div class="faq-answer">
                <p>lain has a wide range of commands for moderation, music, games, and more. You can view the full list of commands on the commands page.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question" onclick="toggleAnswer(this)">How do I report a bug or suggest a feature?</h3>
            <div class="faq-answer">
                <p>To report a bug or suggest a feature, you can join our Discord server and post in the appropriate channel, or use the feedback form on our website.</p>
            </div>
        </div>
        <div class="faq-item">
            <h3 class="faq-question" onclick="toggleAnswer(this)">Is there a support server for lain?</h3>
            <div class="faq-answer">
                <p>Yes, you can join our support server by clicking on the Discord button in the top right corner of this page.</p>
            </div>
        </div>
    </div>
</body>
</html>`;

        fs.writeFile('faq.html', output, (err) => {
            if (err) throw err;
            console.log('HTML FAQ saved as faq.html');
        });
    }
};
