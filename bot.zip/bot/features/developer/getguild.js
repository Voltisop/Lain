const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'getguild',
        aliases: ['none'],
        description: 'Displays information about the specified server including bot permissions.',
        syntax: 'getguild [serverID]',
    },
    run: async (session, message, args) => {
        if (!session.developers.includes(message.author.id)) return;

        if (!args[0]) {
            return message.channel.send('Please provide a server ID.');
        }

        const guild = session.guilds.cache.get(args[0]);
        if (!guild) {
            return message.channel.send('Could not find a guild with that ID.');
        }

        const botMember = guild.members.cache.get(session.user.id);
        if (!botMember) {
            return message.channel.send('Could not find the bot member in the guild.');
        }

        const isAdmin = botMember.permissions.has('ADMINISTRATOR');

        const embed = new MessageEmbed()
            .setColor(session.color)
            .setTitle(`${guild.name} (${guild.vanityURLCode || 'None'})`)
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .addFields(
                { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
                { name: 'Bots', value: `${guild.members.cache.filter(member => member.user.bot).size}`, inline: true },
                { name: 'Members', value: `${guild.memberCount}`, inline: true },
                { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
                { name: 'Administrator', value: isAdmin ? 'Yes' : 'No', inline: true  }
            );
        
        message.channel.send({ embeds: [embed] });
    }
};
