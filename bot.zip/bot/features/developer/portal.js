const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: "getinvite",
        aliases: ['getinv', 'gi', 'portal'],
        description: "Generates an invitation to the server in question.",
    },
    run: async (session, message, args) => {
        if (!session.developers.includes(message.author.id)) return;
        
        let guild = null;

        if (!args[0]) return message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setDescription(`Provide a guild name or id`)
                    .setColor(session.color),
            ],
        });

        if (args[0]) {
            let fetched = session.guilds.cache.find(g => g.name === args.join(" "));
            let found = session.guilds.cache.get(args[0]);
            if (!found) {
                if (fetched) {
                    guild = fetched;
                }
            } else {
                guild = found;
            }
        } else {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription(`Invalid guild name or id`)
                        .setColor(session.color),
                ],
            });
        }
        if (guild) {
            let tChannel = guild.channels.cache.find(ch => ch.type == "GUILD_TEXT");
            if (!tChannel) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setDescription(`Something went wrong`)
                            .setColor(session.color),
                    ],
                });
            }
            let invite = await tChannel.createInvite({ temporary: false, maxAge: 0 }).catch(err => {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setDescription(`I dont have perms there`)
                            .setColor(session.color),
                    ],
                });
            });
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription(`${guild.name} server invite - [**here**](${invite.url})`)
                        .setColor(session.color),
                ],
            });
        } else {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription(` Im not in that server`)
                        .setColor(session.color),
                ],
            });
        }
    }
};
