module.exports = {
    configuration: {
        name: 'setavatar',
        aliases: ['x1'],
        description: 'Set the bot avatar',
        syntax: 'setavatar <url>',
        example: 'setavatar lains.win'
    },
    run: async (session, message, args) => {
        if (!session.developers.includes(message.author.id)) return;

        if (!args[0]) {
            return session.command(module.exports, session, message)
        }

        session.user.setAvatar(args[0]).then(() => {
            return session.neutral(session, message, `Avatar has been updated`);
        }).catch(error => {
            return session.warn(session, message, error.message);
        });
    }
};