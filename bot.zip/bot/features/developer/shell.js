const { exec } = require('child_process');

module.exports = {
    configuration: {
        name: 'shell',
        aliases: ['sh'],
        description: 'Run shell commands',
        syntax: 'shell <command>',
        example: 'shell ls'
    },

    run: async (session, message, args) => {
        if (!session.developers.includes(message.author.id)) return;

        if (!args[0]) {
            return session.command(module.exports, session, message)
        }

        exec(args.join(' '), (error, stdout, stderr) => {
            if (error) {
                return session.warn(session, message, error.message);
            }

            if (stderr) {
                return session.warn(session, message, stderr);
            }

            message.channel.send(`\`\`\`${stdout}\`\`\``);
        });
    }
};