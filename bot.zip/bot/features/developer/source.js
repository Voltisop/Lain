const fs = require('fs');
const path = require('path');
const { MessageAttachment } = require('discord.js');

module.exports = {
  configuration: {
    name: 'source',
    aliases: ['src'],
    description: 'Displays the source code of a file within a specified folder',
    usage: 'source <folder> <command>'
  },
  run: async (session, message, args) => {
    if (!session.developers.includes(message.author.id)) return;

    if (args.length !== 2) {
      session.command(module.exports, session, message);
      return;
    }

    const [folder, filename] = args;
    const basePath = '/root/bot/features';

    const filePath = path.join(basePath, folder, filename);
    
    try {
      const file = fs.readFileSync(filePath, 'utf8');
      const attachment = new MessageAttachment(Buffer.from(file), filename);
      message.channel.send({ files: [attachment] });
    } catch (error) {
      session.warn(session, message, 'File not found or error reading the file.');
    }
  }
};
