const fs = require('fs');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'balance',
        aliases: ['bal'],
        description: 'Check your balance and bank account',
        syntax: 'balance',
        module: 'economy'
    },
    run: async (session, message, args) => {
        const balancePath = '/root/bot/tools/db/economy/balace.json';
        const accountPath = '/root/bot/tools/db/economy/account.json';

        const userId = message.author.id;
        let balanceData = {};
        let accountData = {};

        if (fs.existsSync(balancePath)) {
            const rawData = fs.readFileSync(balancePath);
            balanceData = JSON.parse(rawData);
        }

        if (fs.existsSync(accountPath)) {
            const rawData = fs.readFileSync(accountPath);
            accountData = JSON.parse(rawData);
        }

        if (!balanceData[userId]) {
            balanceData[userId] = 0;
        }

        if (!accountData[userId]) {
            accountData[userId] = 0;
        }

        const embed = new MessageEmbed()
            .setColor(session.color)
            .setAuthor(`${message.author.username}'s balance`, message.author.displayAvatarURL())
            .addField('Balance', `${balanceData[userId]} coins`, true)
            .addField('Bank', `${accountData[userId]} coins`, true);

        return message.channel.send({ embeds: [embed] });
    }
};
