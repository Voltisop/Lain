const fs = require('fs');

module.exports = {
    configuration: {
        name: 'deposit',
        aliases: ['dep'],
        description: 'Deposit money from your balance to your bank account',
        syntax: 'deposit <all|half|amount>',
        module: 'economy'
    },
    run: async (session, message, args) => {
        const balancePath = '/root/bot/tools/db/economy/balace.json';
        const accountPath = '/root/bot/tools/db/economy/account.json';

        const userId = message.author.id;
        let depositAmount = 0;

        let balanceData = {};
        let accountData = {};

        if (fs.existsSync(balancePath)) {
            const rawData = fs.readFileSync(balancePath);
            balanceData = JSON.parse(rawData);
        }

        if (fs.existsSync(accountPath)) {
            const rawData = fs.readFileSync(accountPath);
            accountData = JSON.parse(rawData);
        }

        if (!balanceData[userId]) {
            balanceData[userId] = 0;
        }

        if (!accountData[userId]) {
            accountData[userId] = 0;
        }

        if (args[0] === 'all') {
            depositAmount = balanceData[userId];
        } else if (args[0] === 'half') {
            depositAmount = Math.floor(balanceData[userId] / 2);
        } else {
            depositAmount = parseInt(args[0]);

            if (isNaN(depositAmount) || depositAmount <= 0) {
                return session.warn(session, message, 'Please provide a valid amount to deposit');
            }

            if (depositAmount > balanceData[userId]) {
                return session.warn(session, message, 'You do not have enough coins to deposit');
            }
        }

        balanceData[userId] -= depositAmount;
        accountData[userId] += depositAmount;

        fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(accountPath, JSON.stringify(accountData, null, 2));

        return session.grant(session, message, `You have successfully deposited ${depositAmount} coins to your bank account`)
    }
};
