const fs = require('fs');
const balancePath = '/root/bot/tools/db/economy/balace.json';
const accountPath = '/root/bot/tools/db/economy/account.json';

module.exports = {
    configuration: {
        name: 'withdrawal',
        aliases: ['with'],
        description: 'Withdraw money from your bank account to your balance',
        syntax: 'withdrawal <all|half|amount>',
        module: 'economy'
    },
    run: async (session, message, args) => {
        const userId = message.author.id;
        let withdrawAmount = 0;

        let balanceData = {};
        let accountData = {};

        if (fs.existsSync(balancePath)) {
            const rawData = fs.readFileSync(balancePath);
            balanceData = JSON.parse(rawData);
        }

        if (fs.existsSync(accountPath)) {
            const rawData = fs.readFileSync(accountPath);
            accountData = JSON.parse(rawData);
        }

        if (!balanceData[userId]) {
            balanceData[userId] = 0;
        }

        if (!accountData[userId]) {
            accountData[userId] = 0;
        }

        if (args[0] === 'all') {
            withdrawAmount = accountData[userId];
        } else if (args[0] === 'half') {
            withdrawAmount = Math.floor(accountData[userId] / 2);
        } else {
            withdrawAmount = parseInt(args[0]);

            if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
                return session.warn(session, message, 'Please provide a valid amount to withdraw');
            }

            if (withdrawAmount > accountData[userId]) {
                return session.warn(session, message, 'You do not have enough coins to withdraw');
            }
        }

        balanceData[userId] += withdrawAmount;
        accountData[userId] -= withdrawAmount;

        fs.writeFileSync(balancePath, JSON.stringify(balanceData, null, 2));
        fs.writeFileSync(accountPath, JSON.stringify(accountData, null, 2));

        return session.grant(session, message, `You withdrew ${withdrawAmount} coins`)
    }
};