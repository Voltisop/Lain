const fs = require('fs');
const db = '/root/bot/tools/db/economy/balace.json';

module.exports = {
    configuration: {
        name: 'work',
        aliases: ['none'],
        description: 'Work to earn coins.',
        module: 'fun',
        syntax: 'economy'
    },
    run: async (session, message, args) => {

        const userId = message.author.id;
        const coinsEarned = Math.floor(Math.random() * (200 - 120 + 1) + 120);

        let balanceData = {};

        if (fs.existsSync(db)) {
            const rawData = fs.readFileSync(db);
            balanceData = JSON.parse(rawData);
        }

        if (!balanceData[userId]) {
            balanceData[userId] = 0;
        }

        balanceData[userId] += coinsEarned;

        fs.writeFileSync(db, JSON.stringify(balanceData, null, 2));


        return session.grant(session, message, `You worked and earned ${coinsEarned} coins`)
    }
};
