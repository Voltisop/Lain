const { MessageEmbed } = require("discord.js");
const db = '/root/bot/tools/db/marriage.json';
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'divorce',
        aliases: ['dvc'],
        description: 'Divorce your partner',
        syntax: 'divorce',
        example: 'divorce',
        module: 'fun',
    },
    run: async (session, message, args) => {
        const marriageData = loadMarriageData();
        const authorId = message.author.id;

        if (authorId in marriageData) {
            const spouseId = marriageData[authorId];
            delete marriageData[authorId];
            delete marriageData[spouseId];
            saveMarriageData(marriageData);

            return session.neutral(session, message, `${message.author} and <@${spouseId}> are now divorced`);
        }

        return session.warn(session, message, 'You are not married');
    }
};

function saveMarriageData(data) {
    fs.writeFileSync(db, JSON.stringify(data, null, 4));
}

function loadMarriageData() {
    try {
        const data = fs.readFileSync(db, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading marriage data:', error);
        return {};
    }
}