const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    configuration: {
        name: 'fyp',
        aliases: ['none'],
        description: 'Recieve a random trending video',
        syntax: 'fyp',
    },
    run: async (session, message, args) => {
        try {
            const response = await axios.post('https://www.tikwm.com/api/feed/list', {
                region: 'US',
                count: 1,
                cursor: 0,
                web: 1,
                hd: 1
            }, {
                headers: {
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'sec-ch-ua': '"Chromium";v="104", " Not A;Brand";v="99", "Google Chrome";v="104"',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36'
                }
            });

            const videoData = response.data;

            if (videoData && videoData.data && videoData.data.length > 0) {
                const video = videoData.data[0];
                const videoUrl = video.play; 

                const videoPath = path.join(__dirname, 'lain_foryoupage.mp4');
                const videoResponse = await axios.get(videoUrl, { responseType: 'stream' });

                const writer = fs.createWriteStream(videoPath);
                videoResponse.data.pipe(writer);

                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve);
                    writer.on('error', reject);
                });

                await message.channel.send({
                    files: [videoPath]
                });

                fs.unlinkSync(videoPath);
            } else {
                session.warn(session, message, 'No video found')
            }
        } catch (error) {
            session.log('Error fetching tiktok video:', error)
            session.warn(session, message, `${error}`)
        }
    }
};
