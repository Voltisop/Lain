const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'fox',
        aliases: ['foxes'],
        description: 'Get a random fox image',
        usage: 'fox',
        devOnly: false
    },

    run: async (session, message, args) => {
        try {
            const randomNumber = Math.floor(Math.random() * 122) + 1;
            const url = `https://randomfox.ca/images/${randomNumber}.jpg`;

            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(session.color)
                        .setImage(url)
                ]
            });
        } catch (error) {
            console.error('Error executing fox command:', error);
            return message.channel.send('An error occurred while processing the command.');
        }
    }
}