
const { MessageEmbed } = require("discord.js");
const db = '/root/bot/tools/db/marriage.json';
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'marriage',
        aliases: ['married'],
        description: 'See who a user is married to',
        syntax: 'marriage <member>',
        example: 'marriage @x6l',
        module: 'fun',
    },
    run: async (session, message, args) => {
        const marriageData = loadMarriageData();
        let targetId;

        if (message.mentions.users.size > 0) {
            targetId = message.mentions.users.first().id;
        } else {
            targetId = message.author.id;
        }

        if (targetId in marriageData) {
            const spouseId = marriageData[targetId];
            const spouse = message.guild.members.cache.get(spouseId);
            return session.neutral(session, message, `<@${targetId}> is married to ${spouse}`);
        }

        session.neutral(session, message, `You're not married`);
    }
};

function loadMarriageData() {
    try {
        const data = fs.readFileSync(db, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading marriage data:', error);
        return {};
    }
}
