const db = '/root/bot/tools/db/marriage.json';
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'marry',
        aliases: ['none'],
        description: 'Marry a server member',
        syntax: 'marry <member>',
        example: 'marry @kencarsonirl',
        module: 'fun',
    },
    
    run: async (session, message, args) => {
        const mention = message.mentions.members.first();
        if (!mention || mention.user.bot || mention.id === message.author.id) return session.command(module.exports, session, message);
    
        const marriageData = loadMarriageData();
        if (message.author.id in marriageData) return session.warn(session, message, `You are already married (cheater)`);
        if (mention.id in marriageData) return session.warn(session, message, `${mention} is already married (cuck)`);
    
        const embed = new MessageEmbed()
            .setColor(session.color)
            .setDescription(`${mention}, ${message.author} has proposed to marry you! Do you accept?`);
        const row = new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId('accept')
                .setLabel('Accept')
                .setStyle('SECONDARY'),
            new MessageButton()
                .setCustomId('reject')
                .setLabel('Reject')
                .setStyle('SECONDARY'),
        );
    
        const proposalMessage = await message.channel.send({ embeds: [embed], components: [row] });
    
        const filter = i => ['accept', 'reject'].includes(i.customId) && i.user.id === mention.id;
        const collector = proposalMessage.createMessageComponentCollector({ filter, time: 15000 });
    
        collector.on('collect', async interaction => {
            row.components.forEach(component => component.setDisabled(true));
            await proposalMessage.edit({ components: [row] });
    
            if (interaction.customId === 'accept') {
                marriageData[mention.id] = message.author.id;
                marriageData[message.author.id] = mention.id;
                saveMarriageData(marriageData);
                session.neutral(session, message, `${message.author} and ${mention} are now married!`);
            } else {
                session.neutral(session, message, `${mention} has rejected the proposal (LOL)`);
            }
        });
    
        collector.on('end', async () => {
            row.components.forEach(component => component.setDisabled(true));
            await proposalMessage.edit({ components: [row] });
        });
    }
};    

function loadMarriageData() {
    if (!fs.existsSync(db)) fs.writeFileSync(db, '{}');
    const rawData = fs.readFileSync(db);
    return JSON.parse(rawData);
}

function saveMarriageData(data) {
    fs.writeFileSync(db, JSON.stringify(data, null, 2));
}
