const axios = require('axios');
const { MessageEmbed } = require('discord.js');
const url = 'https://meme-api.com/gimme'

module.exports = {
    configuration: {
        name: 'meme',
        aliases: ['memes'],
        description: 'Get a random meme from Reddit',
        usage: 'meme',
        devOnly: false
    },

    run: async (session, message, args) => {
        try {
            const { data } = await axios.get(url);
            const meme = new MessageEmbed()
                .setColor(session.color)
                .setTitle(data.title)
                .setURL(data.postLink)
                .setImage(data.url)
                .setFooter(`👍 ${data.ups} | Author: ${data.author}`);

            return message.channel.send({ embeds: [meme] });
        } catch (error) {
            console.error('Error executing meme command:', error);
            return message.channel.send('An error occurred while processing the command.');
        }
    }
}