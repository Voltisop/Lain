module.exports = {
    configuration: {
        name: 'penis',
        aliases: ['pp'],
        description: 'Check the size of a mentioned user\'s imaginary penis.',
        usage: 'penis [user]',
        module: 'fun'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;

        const replies = [
            "is 1 inch",
            "is 2 inches",
            "is 3 inches",
            "is 4 inches",
            "is 3 inches",
            "is 5 inches",
            "is 6 inches",
            "is 7 inches",
            "is 8 inches",
            "is overly beefy",
            "is nonexistent",
            "is too big",
        ];

        const randomIndex = Math.floor(Math.random() * replies.length);
        const randomResponse = replies[randomIndex];

        return session.neutral(session, message, `${user}'s penis ${randomResponse}`)
    }
};
