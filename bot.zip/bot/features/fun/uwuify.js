const axios = require('axios');

module.exports = {
    configuration: {
        name: 'uwuify',
        aliases: ['uwu'],
        description: 'Uwuify a string of text',
        syntax: 'uwuify [text]',
        example: 'uwuify i love you',
        module: 'fun'
    },
    run: async (session, message, args) => {
        try {
            const text = args.join(' ');

            if (!text) {
                return session.command(module.exports, session, message)
            }

            const response = await axios.get(`https://nekos.life/api/v2/owoify?text=${encodeURIComponent(text)}`);

            session.neutral(session, message,  response.data.owo);
        } catch (error) {
            session.log('Error fetching uwuified text:', error);
            session.warn(session, message, error.message);
        }
    }
};
