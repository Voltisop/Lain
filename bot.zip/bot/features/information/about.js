const { MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'about',
        aliases: ['botinfo'],
        description: 'Shows information about the bo',
        syntax: 'botinfo',
        module: 'information',
        devOnly: false
    },
    run: async (session, message, args) => {

        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(session.color)
                    .setTitle(`__${session.user.username}__`)
                    .setDescription(`**Memory usage:** ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB\n**Commands:** ${session.commands.size}`)
                    .addFields(
                        { name: 'Guilds', value: `${session.guilds.cache.size} servers`, inline: true },
                        { name: 'Users', value: `${session.guilds.cache.map((guild) => guild.memberCount).reduce((p, c) => p + c, 0).toLocaleString()} users`, inline: true },
                        { name: 'Library', value: `Discord.js`, inline: true }
                    )
            ]
        });
    }
};
