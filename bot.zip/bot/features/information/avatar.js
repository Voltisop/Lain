const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'avatar',
        aliases: ['av'],
        description: 'View a user\'s avatar',
        syntax: 'avatar <user>',
        module: 'information'
    },
    run: async (session, message, args) => {
        let mentionedMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        
        if (!mentionedMember) {
            const searchName = args.join(' ').toLowerCase();
            mentionedMember = message.guild.members.cache.find(member => 
                member.user.username.toLowerCase() === searchName ||
                member.displayName.toLowerCase() === searchName
            );
        }

        const user = mentionedMember?.user || message.author;

        return message.channel.send({ embeds: [
            new MessageEmbed()
                .setColor(session.color)
                .setTitle(`${user.username}'s avatar`)
                .setImage(user.displayAvatarURL({ dynamic: true }))
        ]
         });
    }
};
