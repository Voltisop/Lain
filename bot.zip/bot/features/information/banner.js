const axios = require("axios");
const { MessageEmbed } = require('discord.js');

module.exports = {
  configuration: {
    name: 'banner',
    aliases: ['none'],
    description: 'View a user\'s banner',
    syntax: 'banner <user>',
    module: 'information',
  },
  run: async (session, message, args) => {
    try {
      let mentionedMember = message.mentions.members.first() || 
        message.guild.members.cache.get(args[0]);

      if (!mentionedMember) {
        const searchName = args.join(' ').toLowerCase();
        mentionedMember = message.guild.members.cache.find(member => 
          member.user.username.toLowerCase() === searchName ||
          member.displayName.toLowerCase() === searchName
        );
      }

      const user = mentionedMember?.user || message.author;

      const res = await axios.get(`https://discord.com/api/users/${user.id}`, {
        headers: {
          Authorization: `Bot ${session.token}`
        },
      });

      const { banner } = res.data;

      if (banner) {
        const extension = banner.startsWith("a_") ? ".gif" : ".png";
        const url = `https://cdn.discordapp.com/banners/${user.id}/${banner}${extension}?size=2048`;

        const embed = new MessageEmbed()
          .setColor(session.color)
          .setTitle(`${user.username}'s banner`)
          .setImage(url);

        message.channel.send({ embeds: [embed] });
      } else {
        session.warn(session, message, 'No banner found');
      }
    } catch (error) {
      session.warn(session, message, error.message);
    }
  }
};
