const axios = require('axios');

module.exports = {
    configuration: {
        name: 'checkvanity',
        aliases: ['checkurl'],
        description: 'Check if a vanity URL is available',
        syntax: 'checkvanity <vanity url>',
        module: 'information'
    },

    run: async (session, message, args) => {
        const vanity = args[0];

        if (!vanity) {
            return session.command(module.exports, session, message);
        }

        try {
            const response = await axios.get(`https://discord.com/api/invite/${vanity}`);
            
            if (response.data.code) {
                return session.warn(session, message, `The vanity \`${vanity}\` is already in use`);
            } else {
                return session.grant(session, message, `The vanity \`${vanity}\` is available`);
            }
        } catch (error) {
            if (error.response && error.response.status === 404) {
                return session.grant(session, message, `The vanity \`${vanity}\` is available`);
            } else {
                session.log('Error checking vanity URL:', error);
                return session.warn(session, message, 'Error checking vanity URL');
            }
        }
    }
};
