const { MessageEmbed } = require('discord.js')

module.exports = {
    configuration : {
        name: 'donate',
        aliases: ['none'],
        description: 'Donate to the bot\'s hosting expenses',
        syntax: 'donate'
    },

    run: async(session, message, args) => {
        message.channel.send({ embeds: [
            new MessageEmbed()
            .setTitle('Donation methods')
            .setColor(session.color)
            .setDescription('<:CashApp:1215454421492703232> [Cashapp](https://cash.app/$entxxs)\n<:venmo:1215454441352863774> [Venmo](https://discord.gg/okay)')
        ]})
    }
}