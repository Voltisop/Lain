module.exports = {
    configuration : {
        name: 'faq',
        aliases: ['faq'],
        description: 'Shows the FAQ of the bot',
        syntax: 'faq',
        module: 'information'
    },

    run: async(session, message, args) => {
        session.neutral(session, message, `https://lains.win/faq`)
    }
}