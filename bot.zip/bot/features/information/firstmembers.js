const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'firstmembers',
        aliases: ['recent'],
        description: 'Shows the first members to join the server',
        syntax: 'recentmembers',
        example: 'recentmembers',
        module: 'information',
    },
    run: async (session, message, args) => {
        const firstMembers = message.guild.members.cache.sort((a, b) => (a.joinedAt || 0) - (b.joinedAt || 0)).first(10);
        const pages = firstMembers.map(member => {
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setTitle(`First member: ${member.user.username}`)
                .setThumbnail(member.user.displayAvatarURL({ dynamic: true }));
            const createdAtString = member.user.createdAt instanceof Date ? member.user.createdAt.toDateString() : 'Unknown';

            embed.setDescription(`**Created:** ${createdAtString} (<t:${Math.floor(member.user.createdAt.getTime() / 1000)}:R>)`);
            return embed;
        });

        session.pagination(session, message, pages, 1);
    }
};
