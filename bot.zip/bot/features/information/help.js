const { MessageEmbed } = require("discord.js");
const fs = require("fs");

function embeds(guildID) {
    const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json'));
    return embedsConfig[guildID] || false;
}

async function displayCommandInfo(session, message, name) {
    const command = session.commands.get(name.toLowerCase()) || session.aliases.get(name.toLowerCase());

    if (!command || !command.configuration) {
        return session.warn(session, message, `Invalid command. Use \`help\` to see the list of available commands.`)
    }

    const commandInfo = new MessageEmbed()

    .setColor(session.color)
    .setAuthor(`${session.user.username} help`, session.user.displayAvatarURL())
    .setTitle(`__${command.configuration.name}__`)
    .setDescription(`${command.configuration.description || 'No description has been set'}`)
    .addField('Aliases', `${command.configuration.aliases.join(', ') || 'N/A'}`, true)
    .addField('Module', `${command.configuration.module}`, true)
    .addField('Usage:', `\`\`\`${command.configuration.syntax || 'No syntax has been set'}\`\`\``);

if (command.configuration.subcommands && command.configuration.subcommands.length > 0) {
    commandInfo.addField('Subcommands', `${command.configuration.subcommands}`, true);
}
    const embedsEnabled = embeds(message.guild.id);

    if (embedsEnabled) {
        return message.channel.send({ embeds: [commandInfo] });
    } else {
        const commandInfoText = `${session.prefix}${command.configuration.syntax}\n**Aliases:** ${command.configuration.aliases.join(', ')}\n\n${command.configuration.description}`;
        return message.channel.send(commandInfoText);
    }
}

async function displayModulesHelp(session, message, moduleName = '') {
    const modules = {};

    session.commands.forEach(command => {
        if (command.configuration && command.configuration.module !== 'uncategorized' && command.configuration.module) {
            const capitalizedModule = command.configuration.module.charAt(0).toUpperCase() + command.configuration.module.slice(1);
            if (!modules[capitalizedModule]) {
                modules[capitalizedModule] = [];
            }
            modules[capitalizedModule].push(command.configuration.name);
        }
    });

    if (moduleName) {
        const moduleCommands = modules[moduleName.charAt(0).toUpperCase() + moduleName.slice(1)];
        if (!moduleCommands) {
            return displayCommandInfo(session, message, moduleName);
        }

        const moduleInfo = new MessageEmbed()
            .setColor(session.color)
            .setDescription(`Use \`${session.prefix}help [command]\` for more info on a command.\nYou can also use \`${session.prefix}help [category]\` for more info on a category\n\n**${moduleName} commands**\n${moduleCommands.join('\n')}`);

        const embedsEnabled = embeds(message.guild.id);
        if (embedsEnabled) {
            return message.channel.send({ embeds: [moduleInfo] });
        } else {
            return message.channel.send(moduleCommands.join(', '));
        }
    } else {
        const helpEmbed = new MessageEmbed()
            .setColor(session.color)
            .setDescription(`Use \`${session.prefix}help [command]\` for more info on a command.\nYou can also use \`${session.prefix}help [category]\` for more info on a category`);

        for (const module in modules) {
            helpEmbed.addField(`__${module}__`, `${modules[module].join('  ')}`);
        }

        const embedsEnabled = embeds(message.guild.id);
        if (embedsEnabled) {
            return message.channel.send({ embeds: [helpEmbed] });
        } else {
            let helpMessage = `Use \`${session.prefix}help [command | module]\` for more information\n\n`;
            for (const module in modules) {
                helpMessage += `__**${module}**__\n${modules[module].join('  ')}\n\n`;
            }
            return message.channel.send(helpMessage);
        }
    }
}

module.exports = {
    configuration: {
        name: 'help',
        aliases: ['commands', 'h', 'cmds'],
        description: 'Displays information about a command/module',
        syntax: 'help [command|module]',
        module: 'information'
    },
    run: async (session, message, args) => {
        if (args.length === 0) {
            session.neutral(session, message, 'https://lains.win/help');
        } else {
            const query = args.join(' ').toLowerCase();
            let command = session.commands.get(query) || session.aliases.get(query);
    
            if (!command) {
                session.commands.forEach(cmd => {
                    if (cmd.configuration && cmd.configuration.aliases && cmd.configuration.aliases.includes(query)) {
                        command = cmd;
                    }
                });
            }
    
            if (command && command.configuration) {
                return displayCommandInfo(session, message, command.configuration.name);
            } else {
                let matchedCommand;
                session.commands.forEach(cmd => {
                    if (cmd.configuration && cmd.configuration.aliases && cmd.configuration.aliases.includes(query)) {
                        matchedCommand = cmd;
                    }
                });
    
                if (matchedCommand && matchedCommand.configuration) {
                    return displayCommandInfo(session, message, matchedCommand.configuration.name);
                } else {
                    return displayModulesHelp(session, message, query);
                }
            }
        }
    }
}    