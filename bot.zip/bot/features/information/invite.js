module.exports = {
    configuration: {
        name: 'invite',
        description: 'Get the invite link for the bot.',
        syntax: 'invite',
        example: 'invite',
        aliases: ['inv'],
        module: 'information'
    },
    
    run: async (session, message, args) => {
        return session.neutral(session, message, `https://discord.com/oauth2/authorize?client_id=${session.user.id}&permissions=8&scope=bot`)
    }
};
