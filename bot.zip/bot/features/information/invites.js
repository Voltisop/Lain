const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'invites',
        aliases: ['invs'],
        description: 'Shows all the server\'s invites',
        syntax: 'invites',
        module: 'information'
    },

    run: async (session, message) => {
        try {
            const guildInvites = await message.guild.invites.fetch();

            if (guildInvites.size === 0) {
                return session.warn(session, message, 'There are no active invites in this server.');
            }

            const inviteList = [...guildInvites.values()].map((invite, index) => `${index + 1} ${invite.code} (@${invite.inviter.username}) \`${invite.uses}\``);

            const embed = new MessageEmbed()
                .setColor(session.color)
                .setTitle(`Active Invites`)
                .setDescription(inviteList.join('\n'));

            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching invites:', error);
            session.warn(session, message, 'An error occurred while fetching the server invites.');
        }
    }
};
