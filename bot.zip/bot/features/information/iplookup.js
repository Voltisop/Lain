const axios = require('axios');

module.exports = {
    configuration: {
        name: 'iplookup',
        aliases: ['ip'],
        description: 'Lookup information about an IP address',
        syntax: 'iplookup <ip>',
        module: 'information'
    },
    run: async (session, message, args) => {
        if (args.length === 0) {
            return session.warn(session, message, 'Please provide an IP address to lookup.');
        }

        const ipAddress = args[0];

        try {
            const response = await axios.get(`https://ipinfo.io/${ipAddress}/json`);
            const ipInfo = response.data;

            const infoMessage = `\nIP Address: ${ipInfo.ip}\nLocation: ${ipInfo.city}, ${ipInfo.region}, ${ipInfo.country}\nISP: ${ipInfo.org || 'Unknown'}\nHostname: ${ipInfo.hostname || 'Unknown'}\nTimezone: ${ipInfo.timezone || 'Unknown'}\nCoordinates: ${ipInfo.loc || 'Unknown'}
            `;

            session.neutral(session, message, `**Ip information**\n${infoMessage}`);
        } catch (error) {
            console.error('Error retrieving IP information:', error);
            session.error(session, message, 'An error occurred while retrieving information for the provided IP address.');
        }
    }
};
