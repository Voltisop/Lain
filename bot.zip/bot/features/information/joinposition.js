module.exports = {
    configuration: {
        name: 'joinposition',
        aliases: ['joinpos'],
        description: 'See what # member you were',
        syntax: 'joinposition',
        module: 'information',
    },
    run: async (session, message, args) => {
        try {
            const joinPosition = fetch(message.guild, message.author);
            let suffix = '';
            if (joinPosition % 10 === 1 && joinPosition !== 11) {
                suffix = 'st';
            } else if (joinPosition % 10 === 2 && joinPosition !== 12) {
                suffix = 'nd';
            } else if (joinPosition % 10 === 3 && joinPosition !== 13) {
                suffix = 'rd';
            } else {
                suffix = 'th';
            }
            session.neutral(session, message, `You were the ${joinPosition}${suffix} member to join this server`);
        } catch (error) {
            session.log('Error fetching join position:', error)
            return session.warn(session, message, 'An error occurred while getting the join position.');
        }
    }
};

function fetch(guild, member) {
    const members = guild.members.cache;
    const sortedMembers = Array.from(members.values()).sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);
    const index = sortedMembers.findIndex(m => m.id === member.id);
    return index !== -1 ? index + 1 : null;
}
