const { MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'membercount',
        aliases: ['mc', 'members'],
        description: 'View the server\'s member count',
        syntax: 'membercount',
        module: 'information'
    },
    run: async (session, message) => {

        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(session.color)
                    .setAuthor(`${message.guild.name} statistics`, message.guild.iconURL({ dynamic: true }))
                    .addFields(
                        { name: 'Members', value: `${message.guild.memberCount}`, inline: true },
                        { name: 'Robots', value: `${message.guild.members.cache.filter(member => member.user.bot).size}`, inline: true },
                        { name: 'Boosts', value: `${message.guild.premiumSubscriptionCount || '0'}`, inline: true }
                    )
            ]
        });
    }
};
