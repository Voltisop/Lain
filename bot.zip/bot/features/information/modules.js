module.exports = {
    configuration: {
        name: 'modules',
        aliases: ['listmodules'],
        description: 'List all modules',
        syntax: 'modules',
        module: 'information'
    },
    run: async (session, message, args) => {
        const commandModules = new Map();

        session.commands.forEach(command => {
            const moduleName = command.configuration.module;
            if (moduleName && moduleName !== 'uncategorized') {
                if (commandModules.has(moduleName)) {
                    commandModules.set(moduleName, commandModules.get(moduleName) + 1);
                } else {
                    commandModules.set(moduleName, 1);
                }
            }
        });

        let moduleList = '```';
        commandModules.forEach((count, moduleName) => {
            moduleList += `${moduleName} (${count})\n`;
        });
        moduleList += '```';

        return session.neutral(session, message, `**Modules**\n${moduleList}`);
    }
};
