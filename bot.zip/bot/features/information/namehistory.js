const fs = require('fs');
const { MessageEmbed } = require('discord.js');
const nameHistoryPath = '/root/bot/tools/db/namehistory.json';

module.exports = {
    configuration: {
        name: 'namehistory',
        aliases: ['names'],
        description: 'View the name history of a user',
        syntax: 'namehistory <user>',
        module: 'information'
    },

    run: async (session, message, args) => {
        let userId;

        if (args.length === 0) {
            userId = message.author.id;
        } else {
            if (message.mentions.users.size > 0) {
                userId = message.mentions.users.first().id; 
            } else {
                userId = args[0];
            }
        }

        try {
            const nameHistoryData = JSON.parse(fs.readFileSync(nameHistoryPath, 'utf8'));
            const userHistory = nameHistoryData[userId];
            if (!userHistory || userHistory.length === 0) {
                return session.warn(session, message, 'No name history found for this user.');
            }

            const formattedHistory = userHistory.map(entry => entry);
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setTitle(`Name History for User`)
                .setDescription(`${formattedHistory.join('\n') || 'N/A'}`);

            if (formattedHistory.length > 0) {
                if (formattedHistory.length < 10) {
                    await message.channel.send({ embeds: [embed]});
                } else {
                    await session.pagination(session, message, [embed], { fastForwardAndRewind: true, goTo: true });
                }
            } else {
                return session.warn(session, message, 'No name history found for this user.');
            }
        } catch (error) {
            console.error('Error reading name history:', error);
            return session.warn(session, message, 'An error occurred while reading name history.');
        }
    }
};
