module.exports = {
    configuration: {
        name: 'ping',
        description: 'Get the bot\'s latency to discord',
        syntax: 'ping',
        example: 'ping',
        aliases: ['ws'],
        module: 'information'
    },

    run: async (session, message, args) => {

        session.neutral(session, message, `... \`${session.ws.ping}\`ms`)

    }
}