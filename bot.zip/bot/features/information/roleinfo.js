const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'roleinfo',
        aliases: ['ri'],
        description: 'Get information about a role'
    },

    run: async (session, message, args) => {
        try {

            if (!args.length) {
                return session.warn('Please specify a role by mentioning it or providing its name');
            }

            let role = message.mentions.roles.first() || 
                        message.guild.roles.cache.get(args[0]) || 
                        message.guild.roles.cache.find(r => r.name.toLowerCase() === args.join(' ').toLowerCase());

            if (!role) {
                return session.warn('Role not found');
            }

            const embed = new MessageEmbed()
                .setTitle(`@${role.name} information`)
                .setURL(session.server)
                .setColor(role.color)
                .addField('Name', role.name, true)
                .addField('Mentionable', role.mentionable ? 'Yes' : 'No', true)
                .addField('Hoisted', role.hoist ? 'Yes' : 'No', true)
                .addField('Members', role.members.size.toString(), true)
                .addField('Permissions', role.permissions.toArray().join(', ') || 'None', true)
                .setFooter(`Role ID: ${role.id} | position: ${role.position}`);

            return message.channel.send({ embeds: [embed] });

        } catch (error) {
            console.error(`Error executing command: ${error.message}`);
            return session.warn('An error occurred while executing the command.');
        }
    }
};
