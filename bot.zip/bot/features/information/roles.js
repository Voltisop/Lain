const { MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'roles',
        aliases: ['role'],
        description: 'Shows all roles in the server',
        syntax: 'roles',
        example: 'roles',
        module: 'information',
    },

    run: async (session, message, args) => {
        const roles = message.guild.roles.cache
            .filter(role => role.name !== '@everyone')
            .sort((a, b) => b.position - a.position)
            .map(role => role);

        if (roles.length === 0) {
            return session.warn(session, message, 'No roles found in this server')
        }

        if (roles.length <= 10) {
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
                .setTitle(`Role list`)
                .setDescription(roles.map(role => `<@&${role.id}>`).join('\n'));

            return message.channel.send({ embeds: [embed] });
        }

        const pages = [];
        for (let i = 0; i < roles.length; i += 10) {
            const current = roles.slice(i, i + 10);
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
                .setTitle(`Role list`)
                .setDescription(current.map(role => `<@&${role.id}> (\`${role.id}\`)`).join('\n'));
            pages.push(embed);
        }

        session.pagination(session, message, pages, 1);
    }
};