const { MessageAttachment } = require('discord.js');

module.exports = {
    configuration: {
        name: 'serverbanner',
        aliases: ['banner', 'sbnr'],
        description: 'Show the server banner.',
        syntax: 'serverbanner <invite>',
        example: 'serverbanner',
        module: 'information'
    },
    run: async (session, message, args) => {
        let guildBanner;
    
        if (args.length > 0) {
        const inviteCode = args[0];
        const invite = await session.fetchInvite(`https://discord.gg/${inviteCode}`).catch(() => null);
    
        if (invite && invite.guild) {
            guildBanner = invite.guild.bannerURL({ dynamic: true, size: 4096 }) || null;
        } else {
            return session.warn(session, message, 'Invalid invite code')
        }
        } else {
        guildBanner = message.guild.bannerURL({ dynamic: true, size: 4096 }) || null;
        }
    
        if (!guildBanner) {
        return session.warn(session, message, 'Server banner not found');
        }
    
        const attachment = new MessageAttachment(guildBanner, 'serverbanner.png');
    
        message.channel.send({ files: [attachment] });
    },
    };