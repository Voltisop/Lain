const { MessageAttachment } = require('discord.js');

module.exports = {
  configuration: {
    name: 'servericon',
    aliases: ['icon', 'sicon'],
    description: 'Show the server icon.',
    syntax: 'servericon <invite>',
    example: 'servericon',
    module: 'information'
  },
  run: async (session, message, args) => {
    let guildIcon;

    if (args.length > 0) {
      const inviteCode = args[0];
      const invite = await session.fetchInvite(`https://discord.gg/${inviteCode}`).catch(() => null);

      if (invite && invite.guild) {
        guildIcon = invite.guild.iconURL({ dynamic: true, size: 4096 }) || null;
      } else {
        return session.warn(session, message, 'Invalid invite code')
      }
    } else {
      guildIcon = message.guild.iconURL({ dynamic: true, size: 4096 }) || null;
    }

    if (!guildIcon) {
      return session.warn(session, message, 'Server icon not found');
    }

    const attachment = new MessageAttachment(guildIcon, 'servericon.png');

    message.channel.send({ files: [attachment] });
  },
};
