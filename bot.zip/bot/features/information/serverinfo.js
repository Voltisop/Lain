const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'serverinfo',
        aliases: ['si'],
        description: 'Return server information',
        syntax: 'serverinfo',
        example: 'serverinfo',
        module: 'information',
    },

    run: async (session, message) => {


        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(session.color)
                    .setAuthor(`${message.guild.name} (${message.guild.id})`, message.guild.iconURL({ dynamic: true }))
                    .setThumbnail(message.guild.iconURL({ dynamic: true }))
                    .setImage(message.guild.bannerURL({ dynamic: true }))
                    .addFields(
                        { name: 'Statistics', value: `**Total:** ${message.guild.memberCount}\n**Humans:** ${message.guild.members.cache.filter(member => !member.user.bot).size}\n**Robots:** ${message.guild.members.cache.filter(member => member.user.bot).size}`, inline: true },
                        { name: 'Channels', value: `**Total:**: ${message.guild.channels.cache.size}\n**Text:** ${message.guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT').size}\n**Voice:** ${message.guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE').size}`, inline: true },
                        {
                            name: 'Roles',
                            value: message.guild.roles.cache.size > 5 ?
                                message.guild.roles.cache.sort((a, b) => b.position - a.position).map((role, index) => index < 5 ? role.toString() : '').join(' ') + '...' :
                                message.guild.roles.cache.sort((a, b) => b.position - a.position).map(role => role.toString()).join(' '),
                            inline: false
                        }

                    )
            ]
        });
    }
}