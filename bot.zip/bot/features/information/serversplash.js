const { MessageAttachment } = require('discord.js');

module.exports = {
    configuration: {
        name: 'serversplash',
        aliases: ['splash', 'sspl'],
        description: 'Show the server splash.',
        syntax: 'serversplash <invite>',
        example: 'serversplash',
        module: 'information'
    },
    run: async (session, message, args) => {
        let guildSplash;
    
        if (args.length > 0) {
        const inviteCode = args[0];
        const invite = await session.fetchInvite(`https://discord.gg/${inviteCode}`).catch(() => null);
    
        if (invite && invite.guild) {
            guildSplash = invite.guild.splashURL({ dynamic: true, size: 4096 }) || null;
        } else {
            return session.warn(session, message, 'Invalid invite code')
        }
        } else {
        guildSplash = message.guild.splashURL({ dynamic: true, size: 4096 }) || null;
        }
    
        if (!guildSplash) {
        return session.warn(session, message, 'Server splash not found');
        }
    
        const attachment = new MessageAttachment(guildSplash, 'serversplash.png');
    
        message.channel.send({ files: [attachment] });
    },
    };