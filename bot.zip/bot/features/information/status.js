module.exports = {
    configuration : {
        name: 'status',
        aliases: ['status'],
        description: 'Shows the status of the bot',
        syntax: 'status',
        module: 'information'
    },

    run: async(session, message, args) => {
        session.neutral(session, message, `https://lains.win/status`)
    }
}