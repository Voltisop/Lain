module.exports = {
    configuration : {
        name: 'subcommands',
        aliases: ['none'],
        description: 'Shows the subcommands of a command',
        syntax: 'subcommands <command>',
        example: 'subcommands uwuify',
        module: 'information'
    },

    run: async (session, message, args) => {
        const commandName = args[0];
        const command = session.commands.get(commandName);

        if (!command) {
            return session.warn(session, message, 'Command not found');
        }

        const { name, subcommands } = command.configuration;

        return session.neutral(session, message, `**Command:** ${name}\n\n**Subcommands:**\n${subcommands}`);

    }
}