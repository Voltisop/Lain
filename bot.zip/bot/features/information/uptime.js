module.exports = {
    configuration: {
        name: 'uptime',
        aliases: ['none'],
        description: 'Shows bot uptime.',
        usage: 'uptime',
        module: 'information',
        devOnly: false
    },
    run: async (session, message, args) => {

        return session.neutral(session, message, `I have been online for **${Math.floor(session.uptime / 86400000)}d ${Math.floor(session.uptime / 3600000) % 24}h ${Math.floor(session.uptime / 60000) % 60}m ${Math.floor(session.uptime / 1000) % 60}s**`);
    }
};
