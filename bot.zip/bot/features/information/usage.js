module.exports = {
    configuration: {
        name: 'usage',
        aliases: ['none'],
        description: 'Shows the usage of a command',
        syntax: 'usage <command alias>',
        example: 'usage uwuify',
        module: 'information'
    },

    run: async (session, message, args) => {
        const commandAlias = args[0];
        let command;

        session.commands.forEach(cmd => {
            if (cmd.configuration.aliases && cmd.configuration.aliases.includes(commandAlias)) {
                command = cmd;
            }
        });

        if (!command) {
            return session.warn(session, message, 'Invalid command. Use `help` to see the list of available commands.');
        }

        const { name, description, syntax, example } = command.configuration;

        return session.neutral(session, message, `**Command:** ${name}\n**Description:** ${description}\n**Syntax:** ${syntax}\n**Example:** ${example}`);
    }
};
