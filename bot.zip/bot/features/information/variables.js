const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration : {
        name: 'variables',
        aliases: ['vars'],
        description: 'View the bot\'s variables',
        syntax: 'variables',
        module: 'information'
    },

    run: async (session, message, args) => {

        message.channel.send({
            embeds: [
                new MessageEmbed()
                .setColor(session.color)
                .setTitle('Bot Variables')
                .setDescription('{user} - The user\'s username\n{user.mention} - Mentions the user\n{user.avatar} - Displays the user\'s avatar\n{server.count} - Displays the server member count\n{sever.name} - Displays the server\'s name')
            ]
        })

    }
}