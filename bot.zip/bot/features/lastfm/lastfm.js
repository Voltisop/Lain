const db = '/root/bot/tools/db/lastfm.json';
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'lastfm',
        aliases: ['lf'],
        description: 'Interact with your music',
        syntax: 'lastfm [set|reset] <username>',
        module: 'lastfm',
        subcommands: ['> lastfm set\n> lastfm reset']
    },
    run: async (session, message, args) => {

        if (!args[0]) return session.command(module.exports, session, message);

        const subcommand = args.shift().toLowerCase();
        const userID = message.author.id;
        const lastfmData = JSON.parse(fs.readFileSync(db, 'utf8'));

        switch (subcommand) {
            case 'set':
                if (!args[0]) return session.warn(session, message, 'Please provide a last.fm username');
            
                if (lastfmData[userID]) return session.warn(session, message, 'You already have a last.fm username set');
                
                lastfmData[userID] = args[0];
                fs.writeFileSync(db, JSON.stringify(lastfmData, null, 4));
            
                return message.react('✅');
            
            case 'reset':
                if (!lastfmData[userID]) return session.warn(session, message, 'You don\'t have a last.fm username set');
                delete lastfmData[userID];
                fs.writeFileSync(db, JSON.stringify(lastfmData, null, 4));
                return message.react('✅');
                                

        
            default:
                return session.command(module.exports, session, message)
        }
    }
}
