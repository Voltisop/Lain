const { MessageEmbed } = require('discord.js');
const db = '/root/bot/tools/db/lastfm.json';
const axios = require('axios');
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'nowplaying',
        aliases: ['fm', 'np', 'song'],
        description: 'Shows your currently playing song',
        syntax: 'nowplaying',
        module: 'lastfm'
    },
    run: async (session, message, args) => {

        const lastfmData = JSON.parse(fs.readFileSync(db, 'utf8'));
        const userID = message.mentions.users.first()?.id || message.author.id;

        if (!lastfmData[userID]) {
            return session.warn(session, message, 'You don\'t have a last.fm username set');
        }

        try {
            const response = await axios.get(`https://ws.audioscrobbler.com/2.0/?method=user.getrecenttracks&user=${lastfmData[userID]}&api_key=${session.lastfm}&format=json&limit=1`);
            const recentTrack = response.data.recenttracks.track[0];

            if (!recentTrack) {
                return session.warn(session, message, 'No recent tracks found');
            }
            return session.neutral(session, message, `**[${recentTrack.name}](${recentTrack.url})** by **${recentTrack.artist['#text']}**`)
        } catch (error) {
            session.warn(session, message, error.message);
            session.log('Error fetching now playing:', error);
        }
    }
};