const fs = require('fs');
const { MessageEmbed } = require('discord.js');
const axios = require('axios');
const db = '/root/bot/tools/db/lastfm.json';

module.exports = {
    configuration: {
        name: 'recent',
        aliases: ['none'],
        description: 'Shows your most recent tracks',
        syntax: 'recent',
        example: 'recent',
        module: 'lastfm'
    },

    run: async (session, message, args) => {

        let targetUser = message.mentions.members.first() || message.member;
        const userID = targetUser.id;
        const lastfmData = JSON.parse(fs.readFileSync(db, 'utf8'));

        const lastfmUsername = lastfmData[userID];

        if (!lastfmUsername) {
            return session.warn(session, message, 'You don\'t have a last.fm username set');
        }

        try {
            const { data } = await axios.get(`https://ws.audioscrobbler.com/2.0/?method=user.getrecenttracks&user=${lastfmUsername}&api_key=${session.lastfm}&format=json&limit=20`);
            const recentTracks = data.recenttracks.track;

            if (!recentTracks || recentTracks.length === 0) {
                return session.warn(session, message, 'You haven\'t listened to any tracks recently');
            }

            const embeds = [];
            for (let i = 0; i < recentTracks.length; i += 10) {
                const tracksChunk = recentTracks.slice(i, i + 10);
                const embed = new MessageEmbed()
                    .setColor(session.color)
                    .setAuthor(message.author.username, message.author.displayAvatarURL({ format: 'png', size: 512, dynamic: true }))
                    .setTitle(`Recent Tracks for ${lastfmUsername}`)
                    .setDescription(tracksChunk.map((track, index) => `\`${i + index + 1}.\` **[${track.name}](${track.url})** by **${track.artist['#text']}**`).join('\n'));
                embeds.push(embed);
            }

            session.pagination(session, message, embeds, embeds.length, recentTracks.length, `Recent Tracks for ${lastfmUsername}`, '<:lastfm:1210618435411775549>');
            
        } catch (error) {
            session.log('Error sending request to Last.FM:', error);
            session.warn(session, message, 'Couldn\t fetch recent tracks');
        }
    }
};
