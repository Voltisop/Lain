const fs = require('fs');
const axios = require('axios');
const db = '/root/bot/tools/db/lastfm.json';

module.exports = {
    configuration: {
        name: 'recommend',
        aliases: ['rec'],
        description: 'Recommend a song based on your LastFM history',
        syntax: 'recommend',
        example: 'recommend',
        module: 'lastfm',
    },
    run: async (session, message, args) => {
        try {
            const lastfmData = JSON.parse(fs.readFileSync(db, 'utf8'));
            const lastfmUsername = lastfmData[message.author.id];
            if (!lastfmUsername) {
                return session.warn(session, message, 'You don\'t have a last.fm username set')
            }

            const { data } = await axios.get(`https://ws.audioscrobbler.com/2.0/?method=user.getRecentTracks&user=${lastfmUsername}&api_key=${session.lastfm}&format=json&limit=100`);
            const tracks = data.recenttracks.track;
            const randomTrack = tracks[Math.floor(Math.random() * tracks.length)];

            return session.neutral(session, message, `I recommend you listen to **${randomTrack.name}** by **${randomTrack.artist['#text']}**`)
        } catch (error) {
            session.log('Error fetching recommended track', error);
            session.warn(session, message, 'Error fetching recommended track');
        }
    }
};