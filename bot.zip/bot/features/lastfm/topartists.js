const fs = require('fs');
const axios = require('axios');
const { MessageEmbed } = require('discord.js');
const db = '/root/bot/tools/db/lastfm.json';

module.exports = {
    configuration: {
        name: 'topartists',
        aliases: ['topar', 'ta'],
        description: 'View your top artists',
        syntax: 'topartists',
        module: 'lastfm'
    },
    run: async (session, message, args) => {
        const userID = message.author.id;
        const lastfmData = JSON.parse(fs.readFileSync(db, 'utf8'));

        if (!lastfmData[userID]) {
            return session.warn(session, message, 'You don\'t have a last.fm username set');
        }

        try {
            const response = await axios.get(`https://ws.audioscrobbler.com/2.0/?method=user.gettopartists&user=${lastfmData[userID]}&api_key=${session.lastfm}&format=json`);
            const data = response.data;
            const topArtists = data.topartists.artist;

            const chunkedArtists = chunkArray(topArtists, 10);

            const embeds = chunkedArtists.map((chunk, index) => {
                const embed = new MessageEmbed()
                    .setColor(session.color)
                    .setAuthor(`Top Artists for ${lastfmData[userID]}`, message.author.displayAvatarURL())
                    .setDescription(chunk.map((artist, i) => `\`${i + 1 + index * 10}.\` **${artist.name}** - \`${artist.playcount}\` plays`).join('\n'));
                return embed;
            });

            session.pagination(session, message, embeds, embeds.length, topArtists.length);
        } catch (error) {
            session.log('Error fetching top artists:', error);
            session.warn(session, message, error.message);
        }
    }
};

function chunkArray(array, chunkSize) {
    const chunkedArr = [];
    for (let i = 0; i < array.length; i += chunkSize) {
        chunkedArr.push(array.slice(i, i + chunkSize));
    }
    return chunkedArr;
}
