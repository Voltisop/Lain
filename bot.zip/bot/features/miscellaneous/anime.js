const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'anime',
        aliases: ['none'],
        description: 'Search an Anime on Kitsu.io',
        syntax: 'anime <title>',
        example: 'anime Naruto Shippuden',
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (args.length === 0) {
            return session.command(module.exports, session, message);
        }

        const title = args[0];

        try {
            const response = await axios.get(`https://kitsu.io/api/edge/anime?filter[text]=${encodeURIComponent(title)}`);
            const data = response.data.data;

            if (!data || !data.length) return session.warn(session, message, 'No results found');

            const embeds = data.map(anime => {
                return new MessageEmbed()
                    .setColor(session.color)
                    .setTitle(anime.attributes.titles.en ? `${anime.attributes.titles.en} (Japanese: ${anime.attributes.titles.en_jp})` : anime.attributes.titles.en_jp)
                    .setDescription(anime.attributes.synopsis)
                    .addFields({
                        name: 'Age Rating',
                        value: `${anime.attributes.ageRating}${anime.attributes.ageRatingGuide ? ` (${anime.attributes.ageRatingGuide})` : ''}`,
                        inline: true
                    })
                    .addFields({
                        name: 'Episodes',
                        value: `${anime.attributes.episodeCount} (${anime.attributes.episodeLength} Min Per Episode)`,
                        inline: true
                    })
                    .addFields({
                        name: 'Date Aired',
                        value: `**Start:** ${anime.attributes.startDate}\n**End:** ${anime.attributes.endDate}`
                    })
                    .setImage(anime.attributes.coverImage && anime.attributes.coverImage.original)
                    .setThumbnail(anime.attributes.posterImage && anime.attributes.posterImage.original)
                    .setURL(`https://kitsu.io/anime/${anime.id}`);
            });

            session.pagination(session, message, embeds, embeds.length, data.length, `Search Results for ${title}`, ':tv:');
            
        } catch (error) {
            session.log('Error fetching anime information:', error);
            session.warn(session, message, 'Error fetching anime information');
        }
    }
};
