const { MessageEmbed } = require('discord.js');
const AppleStore = require('app-store-scraper');

module.exports = {
    configuration: {
        name: 'appstore',
        aliases: ["playstore", "app"],
        description: 'View an app on the app store',
        syntax: 'appstore <query>',
        example: 'appstore Uber',
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (!args[0]) return session.command(module.exports, session, message);

        AppleStore.search({
            term: args.join(' '),
            num: 1,
        }).then((data) => {
            try {
                const AppInfo = data[0];
                const description = AppInfo.description.length > 200 ? `${AppInfo.description.substr(0, 200)}...` : AppInfo.description;
                const price = AppInfo.free ? 'Free' : `$${AppInfo.price}`;
                const rating = AppInfo.score.toFixed(1);

                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setTitle(`**${AppInfo.title}**`)
                            .setThumbnail(AppInfo.icon)
                            .setURL(AppInfo.url)
                            .setTimestamp()
                            .setColor(session.color)
                            .setDescription(description)
                            .addField(`**Price**`, price, true)
                            .addField(`**Developer**`, AppInfo.developer, true)
                            .addField(`**Rating**`, rating, true)
                    ]
                });
            } catch (error) {
                session.warn(session, message, 'No results found');
            }
        });
    }
};
