const { MessageEmbed, Permissions } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'fortnite',
        aliases: ['fort', 'fn'],
        description: 'View fortnite related information',
        syntax: 'fortnite [lookup|shop] <cosmetic>',
        example: 'fortnite lookup Renegade Raider',
        subcommands: ['> fortnite shop\n> fortnite lookup'],
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        const commands = ['lookup', 'search', 'find', 'shop', 'store', 'channel'];
        const command = args[0]?.toLowerCase();

        if (!command || !commands.includes(command)) {
            return session.command(module.exports, session, message);
        }

        switch (command) {
            case 'lookup':
            case 'search':
            case 'find': {
                const cosmetic = args.slice(1).join(' ');
                if (!cosmetic) {
                    return session.command(module.exports, session, message)
                }

                try {
                    const response = await axios.get(`https://fnbr.co/api/images?search=${encodeURIComponent(cosmetic)}`, {
                        headers: {
                            'x-api-key': session.fortnite
                        }
                    });
                    const data = response.data;

                    if (data.status !== 200 || data.data.length === 0) {
                        return session.warn(session, message, 'No results found')
                    }

                    const { name, description, type, readableType, rarity, images, price } = data.data[0];
                    const embed = new MessageEmbed()
                        .setTitle(name)
                        .setURL(session.server)
                        .setDescription(description)
                        .addField('Type', `> ${readableType}`, true)
                        .addField('Rarity', `> ${rarity}`, true)
                        .setThumbnail(images.icon)
                        .setColor(session.color)

                    message.channel.send({ embeds: [embed] });
                } catch (error) {
                    session.log('Error sending a request to Fortnite:', error.message);
                    session.warn(session, message, 'No results found')

                }

                break;
            }
            case 'shop':
            case 'store': {
                try {
                    const date = new Date();
                    const format = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
                    const shopImageUrl = `https://bot.fnbr.co/shop-image/fnbr-shop-${format}.png`;

                    const embed = new MessageEmbed()
                        .setTitle('Fortnite Item Shop')
                        .setImage(shopImageUrl)
                        .setColor(session.color);

                    message.channel.send({ embeds: [embed] });
                } catch (error) {
                    session.log('Error sending a request to Fortnite:', error.message);
                    session.warn(session, message, 'Couldn\t get the fortnite item shop')
                }
            }
                break;

            default:
                session.command(module.exports, session, message);
        }
    }
}