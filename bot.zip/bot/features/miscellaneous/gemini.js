const { GoogleGenerativeAI } = require("@google/generative-ai");
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'gemini',
        aliases: ['gpt', 'ask', 'chatgpt'],
        description: 'Generate text with prompts',
        module: 'miscellaneous',
        syntax: 'gemini <prompt>',
        example: 'gemini What is the meaning of life?',
    },

    run: async (session, message, args) => {
        const genAI = new GoogleGenerativeAI(session.gemini);
        try {
            const prompt = args.join(' ');

            if (!prompt) {
                return session.command(module.exports, session, message);
            }

            const model = genAI.getGenerativeModel({ model: "gemini-pro" });
            const result = await model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();

            return session.neutral(session, message, `\`\`\`${text}\`\`\``)
        } catch (error) {
            session.log('Error generating text with Gemini:', error);
            session.warn(session, message, 'Error generating text with Gemini')
        }
    }
};
