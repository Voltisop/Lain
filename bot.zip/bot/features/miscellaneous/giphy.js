const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'giphy',
        aliases: ['gif'],
        description: 'Search Giphy for a GIF.',
        syntax: 'giphy <query>',
        example: 'giphy cats',
        module: 'miscellaneous',
    },
    run: async (session, message, args) => {
        const giphy = require('giphy')(session.giphy);
        const query = args.join(' ');

        if (!query) {
            return session.command(module.exports, session, message)
        }

        try {
            giphy.search({ q: query }, (err, response) => {
                if (err) {
                    console.error('Error searching Giphy:', err);
                    return session.warn(session, message, error.message);
                }

                if (!response || response.data.length === 0) {
                    return session.warn(session, message, 'No GIF found for that query');
                }

                const gif = response.data[0];

                message.channel.send({ content: gif.url });
            });
        } catch (error) {
            session.log('Error searching Giphy:', error);
            session.warn(session, message, error.message);
        }
    },
};
