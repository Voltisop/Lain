const { MessageEmbed } = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
    configuration: {
        name: 'github',
        description: 'Get information from a github profile',
        syntax: 'github <username>',
        example: 'github enlarged',
        aliases: ['git', 'gh'],
        module: 'miscellaneous'
    },

    run: async (session, message, args) => {
        try {
            const username = args[0];
            if (!username) {
                return session.command(module.exports, session, message);
            }

            const response = await fetch(`https://api.github.com/users/${username}`);
            const data = await response.json();

            if (response.status === 404) {
                return session.warn(session, message, 'User not found');
            }

            const embed = new MessageEmbed()
                .setColor(session.color)
                .setAuthor(data.name, data.avatar_url)
                .setURL(data.html_url)
                .setThumbnail(data.avatar_url);

            let information = (data.bio || '') +
                (data.email ? `\n📧 ${data.email}` : '') +
                (data.company ? `\n🏢 [${data.company}](https://google.com/search?q=${encodeURIComponent(data.company)})` : '') +
                (data.location ? `\n🌎 [${data.location}](https://maps.google.com/search?q=${encodeURIComponent(data.location)})` : '') +
                (data.twitter_username ? `\n<:twitter:1195575740863873125> [${data.twitter_username}](https://twitter.com/${data.twitter_username})` : '');

            if (information) {
                embed.addField('Information', information, false);
            }

            if (data.public_repos) {
                const reposResponse = await fetch(data.repos_url);
                const repos = await reposResponse.json();

                embed.addField(`Repositories (${repos.length})`, repos
                    .sort((a, b) => b.stargazers_count - a.stargazers_count)
                    .slice(0, 3)
                    .map(repo => `[⭐ ${repo.stargazers_count.toLocaleString()}, ${new Date(repo.created_at).toLocaleDateString('en-US')} ${repo.name}](${repo.html_url})`)
                    .join('\n'), false);
            }

            embed.addFields(
                { name: 'Following', value: data.following.toLocaleString(), inline: true },
                { name: 'Followers', value: data.followers.toLocaleString(), inline: true },
            );

            return message.channel.send({ embeds: [embed] });
        } catch (error) {
            session.log('Error sending a request to GitHub:', error);
            return session.warn(session, message, error.message);
        }
    }
};
