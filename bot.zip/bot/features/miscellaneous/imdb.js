const { MessageEmbed } = require("discord.js");
const imdb = require("imdb-api");

module.exports = {
    configuration: {
        name: "imdb",
        aliases: ["movie", "series"],
        description: "Get information on a series",
        syntax: "imdb <query>",
        example: "imdb Smile",
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const imdbClient = new imdb.Client({ apiKey: session.imdb });
        try {
            const movie = await imdbClient.get({ name: args.join(" ") })

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle(movie.title)
                        .setColor(session.color)
                        .setThumbnail(movie.poster)
                        .setDescription(movie.plot)
                        .setFooter(`Ratings: ${movie.rating}`)
                        .addField("Country", movie.country, true)
                        .addField("Languages", movie.languages, true)
                        .addField("Type", movie.type, true)
                ]
            });
        } catch (error) {
            session.log("Error sending a request to IMDB:", error);
            session.warn(session, message, error.message);
        }
    }
};
