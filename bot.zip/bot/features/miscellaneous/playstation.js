const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration : {
        name: 'playstation',
        aliases: ['psn'],
        syntax: 'playstation [username]',
        example: 'playstation rust',
        description: 'Search for a PlayStation profile',
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        try {
            const response = await axios.get(`https://psnprofiles.com/${args[0]}`);
            const [, ogTitle] = response.data.match(/<meta property="og:title" content="(.*?)" \/>/);
            const [, ogDescription] = response.data.match(/<meta property="og:description" content="(.*?)" \/>/);
            const [, ogImage] = response.data.match(/<meta property="og:image" content="(.*?)" \/>/);
            const [, ogUrl] = response.data.match(/<meta property="og:url" content="(.*?)" \/>/);

            const embed = new MessageEmbed()
                .setTitle(args[0])
                .setDescription(ogDescription)
                .setImage(ogImage)
                .setURL(ogUrl)
                .setColor(session.color);

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            session.log('Error sending a request to PlayStation', error);
            session.warn(session, message, 'User not found');
        }
    },
};
