const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'pokemon',
        aliases: ['pokedex'],
        description: 'View information about a Pokémon',
        syntax: 'pokedex <pokemon>',
        example: 'pokedex pikachu',
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);      
        }

        try {
            const { data } = await axios.get(`https://pokeapi.co/api/v2/pokemon/${args.join('-').toLowerCase()}`);
            const embed = new MessageEmbed()
                .setTitle(`${data.name.charAt(0).toUpperCase() + data.name.slice(1)} (#${data.id})`)
                .addField('Type(s)', data.types.map(type => type.type.name).join(', '), true)
                .addField('Abilities', data.abilities.map(ability => ability.ability.name).join(', '), true)
                .setColor(session.color)
                .setThumbnail(`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${data.id}.png`);

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            session.log('Error fetching pokemon:', error);
            session.warn(session, message, 'Invalid Pokémon name');
        }
    }
};
