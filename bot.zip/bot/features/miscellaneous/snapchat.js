const { MessageEmbed } = require('discord.js');
const axios = require('axios');
const cheerio = require('cheerio');

module.exports = {
    configuration: {
        name: 'snapchat',
        aliases: ['sc'],
        description: 'View a snapchat profile',
        syntax: 'snapchat <username>',
        example: 'snapchat entxxs',
        module: 'miscellaneous'
    },
  run: async (session, message, args) => {
    const username = args[0];

    if (!username) {
        return session.command(module.exports, session, message)
    }

    try {
      const response = await axios({
        method: 'GET',
        url: `https://story.snapchat.com/add/${username}`
      });

      if (response.status !== 200) {
        return session.warn(session, message, error.message);
      }

      const $ = cheerio.load(response.data);
      const scriptData = $('script#__NEXT_DATA__').html();
      const json = JSON.parse(scriptData);

      const user = json.props.pageProps.userProfile;
      const public = user.publicProfileInfo || user.userInfo;

      const embed = new MessageEmbed()
        .setColor('#FFFC00')
        .setTitle(`${public.displayName || public.title || public.username} (@${username})`)
        .setURL(`https://www.snapchat.com/add/${public.username}`)
        .setImage(public.snapcodeImageUrl.replace('SVG', 'PNG'));

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      session.log('Error looking up Snapchat profile:', error);
      session.warn(session, message, error.message);
    }
  }
};
