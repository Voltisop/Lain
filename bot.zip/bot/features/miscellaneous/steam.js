const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'steam',
        aliases: ['game'],
        description: 'Search Steam for a game',
        syntax: 'steam <game>',
        example: 'steam CSGO',
        module: 'miscellaneous'
    },

    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        try {
            const { data: { items: [game] } } = await axios.get('https://store.steampowered.com/api/storesearch', {
                params: { cc: 'us', l: 'en', term: args.join(" ") }
            });

            if (!game) return session.warn(session, message, 'No results found');

            const { data: { [game.id]: { data } } } = await axios.get('https://store.steampowered.com/api/appdetails', {
                params: { appids: game.id }
            });

            const price = data.price_overview ? `$${data.price_overview.final / 100}` : 'Free';
            const platforms = Object.keys(data.platforms || {}).filter(platform => data.platforms[platform]);
            
            message.channel.send({ embeds: [
                new MessageEmbed()
                .setColor(session.color)
                .setTitle(`**${data.name}**`)
                .setURL(`http://store.steampowered.com/app/${data.steam_appid}`)
                .setImage(game.tiny_image)
                .addField('Price', price, true)
                .addField('Recommendations', data.recommendations ? data.recommendations.total : '???', true)
                .addField('Platforms', platforms.length ? platforms.join(', ') : 'None', true)
                .addField('Release Date', data.release_date ? data.release_date.date : '???', true)
                .addField('Developers', data.developers ? data.developers.join(', ') : '???', true)
                .addField('Publishers', data.publishers ? data.publishers.join(', ') : '???', true)
            ] });
        } catch (error) {
            session.warn(session, message, 'An error occurred.');
            session.log('Error searching Steam:', error);
        }
    }
};
