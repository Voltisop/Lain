const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'tiktok',
        aliases: ['tt'],
        description: 'View a tiktok profile',
        syntax: 'tiktok <username>',
        example: 'tiktok kyliejenner',
        module: 'miscellaneous'
    },
    run: async (session, message, args, prefix) => {
        try {
            if (!args.length) {
                return session.command(module.exports, session, message);
            }

            const username = String(args[0]).toLowerCase();
            const response = await axios.post(`https://www.tikwm.com/api/user/info?unique_id=${username}`);
            const data = response.data;

            if (!data.data) {
                return session.warn(session, message, 'User not found');
            }

            const { user, stats } = data.data;

            const embed = new MessageEmbed()
                .setTitle(`${user.uniqueId !== user.nickname ? `${user.nickname} (@${user.uniqueId})` : `${user.uniqueId}`} ${user.privateAccount ? ':lock:' : user.verified ? ':ballot_box_with_check:' : ''}`)
                .setURL(`https://www.tiktok.com/@${user.uniqueId}`)
                .setDescription(user.signature)
                .addFields(
                    { name: 'Likes', value: stats.heartCount.toLocaleString(), inline: true },
                    { name: 'Followers', value: stats.followerCount.toLocaleString(), inline: true },
                    { name: 'Following', value: stats.followingCount.toLocaleString(), inline: true }
                )
                .setThumbnail(user.avatarLarger)
                .setColor(session.color);

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            return session.log('Error sending a request to TikTok:', error);
        }
    }
};
