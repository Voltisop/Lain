const axios = require('axios');
const { MessageEmbed } = require('discord.js')

module.exports = {
    configuration: {
        name: 'twitter',
        aliases: ['x'],
        description: 'View a twitter profile',
        syntax: 'twitter <username>',
        example: 'twitter mommy',
        module: 'miscellaneous'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message)
        }

        const screenName = args[0];
        const twitterData = await fetchTwitterData(screenName);

        if (!twitterData) {
            return session.warn(session, message, 'User not found');
        }

        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setColor(session.color)
                    .setTitle(`${twitterData.user.name} (@${twitterData.user.profile})`)
                    .setURL(`https://twitter.com/${twitterData.user.profile}`)
                    .setDescription(twitterData.user.desc || 'No bio available')
                    .setThumbnail(twitterData.user.avatar)
                    .setImage(twitterData.user.header_image)
                    .addField('Followers', twitterData.user.sub_count.toLocaleString(), true)
                    .addField('Following', twitterData.user.friends.toLocaleString(), true)
            ]
        });
    }
};

const fetchTwitterData = async (screenName) => {
    const options = {
        method: 'GET',
        url: 'https://twitter-api45.p.rapidapi.com/timeline.php',
        params: {
            screenname: screenName
        },
        headers: {
            'X-RapidAPI-Key': '141e070f61mshebb9f8f7dac8e8fp179694jsnb651b7323525',
            'X-RapidAPI-Host': 'twitter-api45.p.rapidapi.com'
        }
    };

    try {
        const response = await axios.request(options);
        return response.data;
    } catch (error) {
        console.error(error);
        return null;
    }
};
