const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'xbox',
        syntax: 'xbox <username>',
        example: 'xbox c9ce',
        aliases: ['xb', 'xbl'],
        description: 'Gets profile information on the given Xbox gamertag',
        module: 'miscellaneous'
    },

    run: async (session, message, args) => {
        try {
            const gamertag = args.join(' ');

            if (!gamertag) {
                return session.command(module.exports, session, message)
            }

            const response = await axios.get(`https://playerdb.co/api/player/xbox/${encodeURIComponent(gamertag)}`);

            if (response.status !== 200 || !response.data.success) {
                return session.warn(session, message, error.message);
            }

            const player = response.data.data.player;

            const embed = new MessageEmbed()
                .setTitle(player.username)
                .setURL(session.server)
                .addField('Gamerscore', player.meta.gamerscore, true)
                .addField('Account Tier', player.meta.accountTier, true)
                .setImage(player.avatar)
                .setColor(session.color);

            message.channel.send({ embeds: [embed] });
        } catch (error) {
            session.log('Error:', error);
            session.warn(session, message, error.message);
        }
    }
};
