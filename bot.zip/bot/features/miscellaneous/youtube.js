const yts = require('yt-search');

module.exports = {
  configuration: {
    name: 'youtube',
    aliases: ['yt'],
    description: 'Searches YouTube for video query',
    usage: 'youtube <query>',
    module: 'miscellaneous'
  },
  run: async (session, message, args) => {
    if (args.length < 1) {
      session.command(module.exports, session, message);
      return;
    }

    try {
      const videoResults = await yts(args.join(' '));

      if (videoResults.videos.length > 0) {
        message.channel.send(`https://www.youtube.com/watch?v=${videoResults.videos[0].videoId}`);
      } else {
        session.warn(session, message, 'No results found');
      }
    } catch (error) {
      session.log('Error sending a request to YouTube:', error);
      session.warn(session, message, error.message);
    }
  }
};
