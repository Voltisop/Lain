const { MessageEmbed, Util, Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'addmany',
        aliases: ['addm', 'am'],
        description: 'Add multiple emojis to the server',
        syntax: 'addmany <emoji1> <emoji2> ... <emoji10>',
        module: 'moderation'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_EMOJIS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!message.guild.me.permissions.has('MANAGE_EMOJIS')) {
            return session.warn(session, message, 'I do not have the required permissions to add emojis');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const addedEmojis = [];
        const failedEmojis = [];

        await Promise.all(args.slice(0, 10).map(async emoji => {
            const parsedEmoji = Util.parseEmoji(emoji);
            let emojiURL = '';

            if (parsedEmoji && parsedEmoji.id) {
                emojiURL = `https://cdn.discordapp.com/emojis/${parsedEmoji.id}.${parsedEmoji.animated ? 'gif' : 'png'}`;
                try {
                    const createdEmoji = await message.guild.emojis.create(emojiURL, parsedEmoji.name);
                    addedEmojis.push(createdEmoji);
                } catch (error) {
                    failedEmojis.push(emoji);
                }
            } else {
                failedEmojis.push(emoji);
            }
        }));

        if (addedEmojis.length) {
            message.react('👍');
        }

        session.grant(session, message, `Added ${addedEmojis.length ? addedEmojis.map(e => `<:${e.name}:${e.id}>`).join(', ') : 'None'} to the server`)
    }
};
