const { Permissions, MessageButton, MessageActionRow, MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'ban',
        aliases: ['deport'],
        description: 'Ban a member from the server',
        syntax: 'ban @c2rter Bad Boy',
        module: 'moderation'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const userToBan = message.mentions.members.first();
        const reason = args.slice(1).join(' ') || 'No reason provided';

        if (!userToBan) {
            return session.command(module.exports, session, message)
        }

        if (userToBan.roles.highest.position >= message.member.roles.highest.position) {
            return session.warn(session, message,'You cannot ban a member with a role equal to or higher than yours');
        }

        const isBooster = message.guild.premiumSubscriptionCount > 0 && userToBan.premiumSince !== null;

        if (isBooster) {
            const banButton = new MessageButton()
                .setCustomId('confirm_ban')
                .setLabel('Yes')
                .setStyle('SUCCESS');

            const cancelButton = new MessageButton()
                .setCustomId('cancel_ban')
                .setLabel('No')
                .setStyle('DANGER');

            const row = new MessageActionRow()
                .addComponents(banButton, cancelButton);

            const confirmationMessage = await message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(session.color)
                        .setDescription(`Are you sure you want to ban ${userToBan}?`)
                ], components: [row]
            });

            const filter = i => (i.customId === 'confirm_ban' || i.customId === 'cancel_ban') && i.user.id === message.author.id;
            const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 15000 });

            collector.on('collect', async interaction => {
                if (interaction.customId === 'confirm_ban') {

                    await userToBan.ban({ reason: reason });
                    await interaction.update({
                        embeds: [
                            new MessageEmbed()
                                .setColor(session.color)
                                .setDescription(`${userToBan} has been banned successfully`)
                        ], components: []
                    });
                } else if (interaction.customId === 'cancel_ban') {
                    await interaction.update({
                        embeds: [
                            new MessageEmbed()
                                .setColor(session.color)
                                .setDescription('Ban cancelled')
                        ], components: []
                    });
                }
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    confirmationMessage.edit({
                        embeds: [
                            new MessageEmbed()
                                .setColor(session.color)
                                .setDescription('Ban cancelled due to inactivity')
                        ], components: []
                    });
                }
            });
        } else {
            await userToBan.ban({ reason: reason });
            session.success(`${userToBan} has been banned successfully!`);
        }
    }
};
