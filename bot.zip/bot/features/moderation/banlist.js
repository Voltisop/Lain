const { MessageEmbed, Permissions } = require("discord.js");


module.exports = {
    configuration: {
        name: 'banlist',
        aliases: ['bans'],
        description: 'Shows all banned users in the server',
        syntax: 'banlist',
        example: 'banlist',
        permissions: 'ban_members',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const bans = await message.guild.bans.fetch();
        const bannedUsers = bans.map(ban => ban.user);

        if (bannedUsers.length === 0) {
            return session.warn(session, message, 'There are no banned users in this server')
        }

        if (bannedUsers.length <= 10) {
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
                .setTitle(`Banned users list`)
                .setDescription(bannedUsers.map(user => `<@${user.id}>`).join('\n'));

            return message.channel.send({ embeds: [embed] });
        }

        const pages = [];
        for (let i = 0; i < bannedUsers.length; i += 10) {
            const current = bannedUsers.slice(i, i + 10);
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
                .setTitle(`Banned users list`)
                .setDescription(current.map(user => `<@${user.id}>`).join('\n'));
            pages.push(embed);
        }

        session.pagination(session, message, pages, 1);
    }
};