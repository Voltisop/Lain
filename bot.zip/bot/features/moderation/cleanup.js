const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'cleanup',
        aliases: ['clear', 'bc'],
        description: 'Delete a certain amount of messages from bots',
        syntax: 'cleanup <amount>',
        example: 'cleanup 10',
        permissions: 'MANAGE_MESSAGES',
        module: 'moderation',
    },

    run: async(session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        if (!args[0]) {
            return session.command(module.exports, session, message)
        }

        const amount = parseInt(args[0]) + 1;

        if (isNaN(amount)) {
            return session.command(module.exports, session, message)
        }

        if (amount > 100) {
            return message.channel.send('You can only delete 100 messages at a time')
        }

        message.channel.bulkDelete(amount, true).catch(error => {
            session.warn(session, message, error)
        });

    
    }
}

