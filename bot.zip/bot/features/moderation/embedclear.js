const { Permissions } = require("discord.js");

module.exports = {
    configuration: {
        name: 'embedclear',
        aliases: ['clearembed', 'clearembeds'],
        description: 'Clears all embeds in a channel',
        syntax: 'embedclear',
        module: 'moderation'

    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const messages = await message.channel.messages.fetch({ limit: 100 });
        const embeds = messages.filter(msg => msg.embeds.length > 0);

        if (embeds.size === 0) {
            return session.warn(session, message, 'There are no embeds in this channel')
        }

        await message.channel.bulkDelete(embeds);
        session.grant(session, message, `Successfully cleared ${embeds.size} embeds from this channel`);
    }
};