const { Permissions } = require("discord.js");

module.exports = {
    configuration: {
        name: 'imageclear',
        aliases: ['clearimage', 'clearimages'],
        description: 'Clears all images in a channel',
        syntax: 'imageclear',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const messages = await message.channel.messages.fetch({ limit: 100 });
        const images = messages.filter(msg => msg.attachments.size > 0);

        if (images.size === 0) {
            return session.warn(session, message, 'There are no images in this channel')
        }

        await message.channel.bulkDelete(images);
        session.grant(session, message, `Successfully cleared ${images.size} images from this channel`);
    }
};