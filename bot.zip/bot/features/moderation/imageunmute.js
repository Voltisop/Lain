const fs = require('fs');
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'imageunmute',
        aliases: ['unmuteimage', 'unimagemute'],
        description: 'Unmute images for a specific user in the channel',
        syntax: 'imageunmute <user>',
        example: 'imageunmute @user',
        permissions: 'MANAGE_ROLES',
        module: 'moderation',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const targetUser = message.mentions.members.first();
        if (!targetUser) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const moderationSettingsPath = '/root/bot/tools/db/moderation.json';

        try {
            let moderationSettings = {};
            if (fs.existsSync(moderationSettingsPath)) {
                moderationSettings = JSON.parse(fs.readFileSync(moderationSettingsPath, 'utf8'));
            }

            const guildSettings = moderationSettings[guildID];
            if (!guildSettings) {
                return session.warn(session, message, 'Moderation settings have not been configured for this server, run `setupmod`');
            }

            const imageMuteRoleID = guildSettings.roles.imageMuteRole;
            const imageMuteRole = message.guild.roles.cache.get(imageMuteRoleID);
            if (!imageMuteRole) {
                return session.warn(session, message, 'Image mute role not found. Please configure moderation settings using `removemod` & run `setupmod`');
            }

            await targetUser.roles.remove(imageMuteRole);
            session.grant(session, message, `Unmuted images for ${targetUser}`);
        } catch (error) {
            console.error('Error removing image mute role:', error);
            session.error(session, message, 'An error occurred while removing image mute role');
        }
    }
};