const fs = require('fs').promises;
const { Permissions } = require('discord.js');
const dbPath = '/root/bot/tools/db/jail.json';

module.exports = {
    configuration: {
        name: 'jail',
        aliases: ['none'],
        description: 'Jails a mentioned user',
        syntax: 'jail @user',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const jailSettings = await loadJailSettings();
        const guildId = message.guild.id;
        const jailData = jailSettings[guildId];

        if (!jailData) {
            return session.warn(session, message, 'Jail has not been set up in this guild');
        }

        const jailRoleId = jailData.jailRoleId;
        const jailChannelId = jailData.jailChannelId;

        const userToJail = message.mentions.members.first();
        if (!userToJail) {
            return session.warn(session, message, 'Please mention a user to jail');
        }

        try {
            await userToJail.roles.set([jailRoleId]);
        } catch (error) {
            console.error('Error jailing user:', error);
            return session.warn(session, message, 'An error occurred while jailing the user.');
        }

        const jailChannel = message.guild.channels.cache.get(jailChannelId);
        if (jailChannel && jailChannel.isText()) {
            try {
                await jailChannel.send(`You have been jailed ${userToJail}`);
            } catch (error) {
                console.error('Error sending jail message:', error);
            }
        }

        return message.react('✅');
    }
};

async function loadJailSettings() {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading jail settings file:', error.message);
        return {};
    }
}