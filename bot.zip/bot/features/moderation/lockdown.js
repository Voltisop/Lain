const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'lockdown',
        aliases: ['lock'],
        description: 'Lock down the channel',
        syntax: 'lockdown',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const channel = message.channel;
        const everyone = message.guild.roles.everyone;

        channel.permissionOverwrites.edit(everyone, {
            SEND_MESSAGES: false
        });

        session.grant(session, message, 'This channel has been locked for `@everyone`');
    }
}