const { Permissions } = require('discord.js');
const fs = require('fs');
const dbPath = '/root/bot/tools/db/moderation.json';

module.exports = {
    configuration: {
        name: 'muted',
        aliases: ['mute'],
        description: 'See how many users are muted',
        syntax: 'muted',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn(session, message,'You do not have the required permissions to use this command');
        }

        let muteRoleId;
        try {
            const data = fs.readFileSync(dbPath, 'utf8');
            const db = JSON.parse(data);
            const guildConfig = db[message.guild.id];

            if (!guildConfig || !guildConfig.roles || !guildConfig.roles.muteRole) {
                return session.warn(session, message,'Mute role ID not found in the database.');
            }

            muteRoleId = guildConfig.roles.muteRole;
        } catch (err) {
            console.error(err);
            return session.warn(session, message,'An error occurred while reading the database.');
        }

        const muteRole = message.guild.roles.cache.get(muteRoleId);
        if (!muteRole) {
            return session.warn(session, message,'Mute role not found in the server.');
        }

        const mutedMembers = muteRole.members.size;

        return session.neutral(session, message, `There are ${mutedMembers} members muted in this server`);
    }
};
