const { Permissions } = require("discord.js");

module.exports = {
    configuration: {
        name: 'nickname',
        aliases: ['nick'],
        description: 'Change the nickname of a user',
        syntax: 'nickname @c2rter <nickname>',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_NICKNAMES)) {
            return session.warn('You do not have the required permissions to use this command');
        }

        if (!args[0]) {
            return session.command(module.exports, session, message);
        }

        const user = message.mentions.members.first();
        if (!user) {
            return session.warn('Please provide a valid user to change their nickname');
        }

        if (user.roles.highest.position >= message.member.roles.highest.position) {
            return session.warn('You cannot change the nickname of a member with a role equal to or higher than yours.');
        }

        const nickname = args.slice(1).join(' ');
        if (!nickname) {
            return session.warn('Please provide a nickname to change');
        }

        try {
            await user.setNickname(nickname);
            session.grant(`Successfully changed the nickname of ${user} to \`${nickname}\``);
        } catch (error) {
            session.warn('An error occurred while trying to change the nickname of the user', error);
            session.log(error);
        }
    }
};
