const { Permissions, MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'nicknamereset',
        aliases: ['resetnickname', 'resetnick', 'nickreset'],
        description: 'Reset the nickname of a user',
        syntax: 'nicknamereset @c2rter',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_NICKNAMES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args[0]) {
            return session.command(module.exports, session, message);
        }

        const user = message.mentions.members.first();
        if (!user) {
            return session.command(module.exports, session, message);
        }

        if (user.roles.highest.position >= message.member.roles.highest.position) {
            session.warn(session, message, 'You cannot reset the nickname of a member with a role equal to or higher than yours');
        }

        try {
            await user.setNickname(null);
            session.grant(session, message, `Successfully reset the nickname of ${user}`);
        } catch (error) {
            session.warn(session, message, 'An error occurred while trying to reset the nickname of the user', error);
            session.log('Error resetting nickname:', error);
        }
    }
};
