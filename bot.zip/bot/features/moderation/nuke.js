const { Permissions, MessageButton, MessageActionRow } = require('discord.js');
const fs = require('fs');
const dbPath = '/root/bot/tools/db/trusted.json';

module.exports = {
    configuration: {
        name: 'nuke',
        aliases: ['nukechannel'],
        description: 'Nuke the channel',
        syntax: 'nuke',
        module: 'moderation'
    },

    run: async (session, message, args) => {

        let db = {};
        try {
            if (fs.existsSync(dbPath)) {
                const data = fs.readFileSync(dbPath, 'utf8');
                db = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = db[guildId] ? db[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const channel = message.channel;

        const nukeButton = new MessageButton()
            .setCustomId('nuke')
            .setLabel('Yes')
            .setStyle('SUCCESS');

        const cancelButton = new MessageButton()
            .setCustomId('cancel')
            .setLabel('No')
            .setStyle('DANGER');

        const row = new MessageActionRow()
            .addComponents(nukeButton, cancelButton);

        const nukeMessage = await message.channel.send({
            embeds: [
                {
                    description: 'Are you sure you want to nuke this channel?',
                    color: session.color
                }
            ], components: [row]
        });

        const filter = i => i.user.id === message.author.id;

        const collector = nukeMessage.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async i => {
            if (i.customId === 'nuke') {
                await channel.clone().then(async newChannel => {
                    await newChannel.setPosition(channel.position);
                    await channel.delete();
                });
            } else if (i.customId === 'cancel') {
                await i.update({ embeds: [
                    {
                        description: 'The nuke has been cancelled',
                        color: session.color
                    }
                
                ], components: [] });
            }
        });

        collector.on('end', async () => {
            await nukeMessage.edit({ embeds: [
                {
                    description: 'The nuke has timed out',
                    color: session.color
                }
            ], components: [] });
        });
    }
}
