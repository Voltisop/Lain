const { Permissions, MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'purge',
        description: 'Mass delete messages',
        syntax: 'purge @c2rter 100',
        aliases: ['clear', 'c'],
        module: 'moderation'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command')
        }

        if (args.length === 0) {
            return session.command(module.exports, session, message)
        }

        let user = null;
        let limit = null;
        const firstArg = args[0];
        
        if (message.mentions.members.size > 0) {
            user = message.mentions.members.first();
            args.shift();
        } else {
            user = message.guild.members.cache.find(member =>
                member.user.username.toLowerCase() === firstArg.toLowerCase());
        }

        if (args.length > 0) {
            const parsedLimit = parseInt(args[args.length - 1]);
            if (!isNaN(parsedLimit)) {
                limit = parsedLimit;
                args.pop();
            }
        }

        if (user) {
            const messages = await message.channel.messages.fetch({ limit: limit || 100 });
            const userMessages = messages.filter(msg => msg.author.id === user.id);
            await message.channel.bulkDelete(userMessages, true);
        } else if (limit) {
            await message.channel.bulkDelete(limit, true);
        }
    }
};
