const fs = require('fs');
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'reactionmute',
        aliases: ['rmute'],
        description: 'Mute reactions for a specific user in the channel',
        syntax: 'reactionmute <user>',
        example: 'reactionmute @user',
        permissions: 'MANAGE_ROLES',
        module: 'moderation',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const targetUser = message.mentions.members.first();
        if (!targetUser) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const moderationSettingsPath = '/root/bot/tools/db/moderation.json';

        try {
            let moderationSettings = {};
            if (fs.existsSync(moderationSettingsPath)) {
                moderationSettings = JSON.parse(fs.readFileSync(moderationSettingsPath, 'utf8'));
            }

            const guildSettings = moderationSettings[guildID];
            if (!guildSettings) {
                return session.warn(session, message, 'Moderation settings have not been configured for this server, run `setupmod`');
            }

            const reactionMuteRoleID = guildSettings.roles.reactionMuteRole;
            const reactionMuteRole = message.guild.roles.cache.get(reactionMuteRoleID);
            if (!reactionMuteRole) {
                return session.warn(session, message, 'Reaction mute role not found. Please configure moderation settings using `removemod` & run `setupmod`');
            }

            await targetUser.roles.add(reactionMuteRole);
            session.grant(session, message, `Removed reaction permissions from ${targetUser}`);
        } catch (error) {
            console.error('Error applying reaction mute role:', error);
            session.error(session, message, 'An error occurred while applying reaction mute role');
        }
    }
};
