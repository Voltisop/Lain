const { Permissions } = require('discord.js');
const fs = require('fs').promises;
const dbPath = '/root/bot/tools/db/jail.json';

module.exports = {
    configuration: {
        name: 'removejail',
        aliases: ['rjail'],
        description: 'Removes the jail setup from the server',
        syntax: 'removejail',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const jailSettings = await loadJailSettings();
        const guildId = message.guild.id;
        const jailData = jailSettings[guildId];

        if (!jailData) {
            return session.warn(session, message, 'Jail has not been set up in this guild');
        }

        const jailRoleId = jailData.jailRoleId;
        const jailChannelId = jailData.jailChannelId;

        const jailRole = message.guild.roles.cache.get(jailRoleId);
        if (jailRole) {
            try {
                await jailRole.delete('Jail removed by admin');
            } catch (error) {
                console.error('Error deleting Jail role:', error);
                return session.warn(session, message, 'An error occurred while deleting the Jail role.');
            }
        }

        const jailChannel = message.guild.channels.cache.get(jailChannelId);
        if (jailChannel) {
            try {
                await jailChannel.delete('Jail removed by admin');
            } catch (error) {
                console.error('Error deleting Jail channel:', error);
                return session.warn(session, message, 'An error occurred while deleting the Jail channel.');
            }
        }

        delete jailSettings[guildId];
        await saveJailSettings(jailSettings);

        return message.react('✅');
    }
};

async function loadJailSettings() {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading jail settings file:', error.message);
        return {};
    }
}

async function saveJailSettings(settings) {
    try {
        await fs.writeFile(dbPath, JSON.stringify(settings, null, 2));
    } catch (error) {
        console.error('Error saving jail settings file:', error.message);
    }
}