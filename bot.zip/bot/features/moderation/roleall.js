const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'roleall',
        aliases: ['none'],
        description: 'Give a role to all members',
        syntax: 'roleall <role>',
        example: 'roleall @Members',
        module: 'moderation'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const role = message.mentions.roles.first();

        if (!role) {
            return session.command(module.exports, session, message);
        }

        message.guild.members.cache.forEach(member => {
            member.roles.add(role).catch(error => {
                session.log('Error adding role to member:', error);
                session.warn(session, message, 'Error adding role to member');
            });
        });

        message.react('✅');
    }
};