
module.exports = {
    configuration: {
        name: 'selfpurge',
        aliases: ['me'],
        description: 'Delete 100 of your own messages',
        syntax: 'selfpurge',
        example: 'selfpurge',
        permissions: 'MANAGE_MESSAGES',
        module: 'moderation',
    },

    run: async(session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const amount = 100;

        message.channel.bulkDelete(amount, true).catch(error => {
            session.warn(session, message, error)
        });
    }
}