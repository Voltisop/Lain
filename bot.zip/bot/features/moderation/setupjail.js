const fs = require('fs').promises;
const { Permissions } = require('discord.js');
const dbPath = '/root/bot/tools/db/jail.json';

module.exports = {
    configuration: {
        name: 'setupjail',
        aliases: ['setupj'],
        description: 'Sets up the jail role and channel',
        syntax: 'setupjail',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const guild = message.guild;

        let jailRole;
        try {
            jailRole = await guild.roles.create({
                name: 'Jail',
                permissions: []
            });
        } catch (error) {
            console.error('Error creating Jail role:', error);
            return session.warn(session, message, 'An error occurred while creating the Jail role.');
        }

        let jailChannel;
        try {
            jailChannel = await guild.channels.create('jail', {
                type: 'GUILD_TEXT',
                permissionOverwrites: [
                    {
                        id: guild.id, // Everyone
                        deny: [Permissions.FLAGS.VIEW_CHANNEL]
                    },
                    {
                        id: jailRole.id,
                        allow: [Permissions.FLAGS.VIEW_CHANNEL],
                        deny: [
                            Permissions.FLAGS.SEND_MESSAGES,
                            Permissions.FLAGS.ADD_REACTIONS,
                            Permissions.FLAGS.CONNECT,
                            Permissions.FLAGS.SPEAK
                        ]
                    }
                ]
            });
        } catch (error) {
            console.error('Error creating Jail channel:', error);
            return session.warn(session, message, 'An error occurred while creating the Jail channel.');
        }

        try {
            await Promise.all(guild.channels.cache.map(channel => {
                if (channel.id !== jailChannel.id) {
                    return channel.permissionOverwrites.edit(jailRole, {
                        VIEW_CHANNEL: false
                    });
                }
            }));
        } catch (error) {
            console.error('Error overwriting channel permissions:', error);
            return session.warn(session, message, 'An error occurred while overwriting channel permissions.');
        }

        const jailData = {
            [guild.id]: {
                jailRoleId: jailRole.id,
                jailChannelId: jailChannel.id
            }
        };

        try {
            await fs.writeFile(dbPath, JSON.stringify(jailData, null, 2));
        } catch (error) {
            console.error('Error saving jail data to database:', error);
            return session.warn(session, message, 'An error occurred while saving the jail data.');
        }

        return message.react('✅');
    }
};
