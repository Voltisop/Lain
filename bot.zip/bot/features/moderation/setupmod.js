const fs = require('fs');
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'setupmod',
        aliases: ['setme'],
        description: 'Setup moderation settings for the server',
        syntax: 'setupmod',
        example: 'setupmod',
        permissions: 'ADMINISTRATOR',
        module: 'moderation',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const guildID = message.guild.id;

        let imageMuteRole = message.guild.roles.cache.find(role => role.name === 'Image Mute');
        if (!imageMuteRole) {
            try {
                imageMuteRole = await message.guild.roles.create({
                    name: 'Image Mute',
                    permissions: []
                });
            } catch (error) {
                console.error('Error creating image mute role:', error);
                return session.error(session, message, 'An error occurred while creating the image mute role');
            }
        }

        let reactionMuteRole = message.guild.roles.cache.find(role => role.name === 'Reaction Mute');
        if (!reactionMuteRole) {
            try {
                reactionMuteRole = await message.guild.roles.create({
                    name: 'Reaction Mute',
                    permissions: []
                });
            } catch (error) {
                console.error('Error creating reaction mute role:', error);
                return session.error(session, message, 'An error occurred while creating the reaction mute role');
            }
        }

        let muteRole = message.guild.roles.cache.find(role => role.name === 'Mute');
        if (!muteRole) {
            try {
                muteRole = await message.guild.roles.create({
                    name: 'Mute',
                    permissions: []
                });
            } catch (error) {
                console.error('Error creating mute role:', error);
                return session.error(session, message, 'An error occurred while creating the mute role');
            }
        }

        const moderationSettingsPath = '/root/bot/tools/db/moderation.json';
        try {
            let moderationSettings = {};
            if (fs.existsSync(moderationSettingsPath)) {
                moderationSettings = JSON.parse(fs.readFileSync(moderationSettingsPath, 'utf8'));
            }

            moderationSettings[guildID] = {
                roles: {
                    imageMuteRole: imageMuteRole.id,
                    reactionMuteRole: reactionMuteRole.id,
                    muteRole: muteRole.id
                }
            };

            fs.writeFileSync(moderationSettingsPath, JSON.stringify(moderationSettings, null, 2));

            // Configure channel permissions for each role in each category
            message.guild.channels.cache.forEach(async channel => {
                if (channel.type === 'GUILD_CATEGORY') {
                    try {
                        await channel.children.forEach(async (childChannel) => {
                            await childChannel.permissionOverwrites.create(imageMuteRole, {
                                VIEW_CHANNEL: true,
                                ATTACH_FILES: false
                            });

                            await childChannel.permissionOverwrites.create(reactionMuteRole, {
                                VIEW_CHANNEL: true,
                                ADD_REACTIONS: false
                            });

                            await childChannel.permissionOverwrites.create(muteRole, {
                                VIEW_CHANNEL: true,
                                SEND_MESSAGES: false
                            });
                        });
                    } catch (error) {
                        console.error(`Error configuring permissions for channels in category ${channel.name}:`, error);
                    }
                }
            });

            session.grant(session, message, 'Moderation settings have been successfully configured');
        } catch (error) {
            console.error('Error saving moderation settings:', error);
            session.error(session, message, 'An error occurred while saving moderation settings');
        }
    }
};
