const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'slowmode',
        aliases: ['sm'],
        description: 'Set the slowmode of a channel',
        syntax: 'slowmode 10s',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        if (!args.length) {
            return session.command(session, message, module.exports)
        }

        let slowmode;
        const time = args[0].toLowerCase();
        if (time.endsWith('s')) {
            slowmode = parseInt(time);
        } else if (time.endsWith('m')) {
            const minutes = parseInt(time.slice(0, -1));
            slowmode = minutes * 60;
        } else if (time.endsWith('h')) {
            const hours = parseInt(time.slice(0, -1));
            slowmode = hours * 60 * 60;
        } else {
            return session.warn(session, message, 'Please provide a valid time format (e.g., 10s, 1m, 2h)')
        }

        if (isNaN(slowmode) || slowmode < 0 || slowmode > 21600) {
            return session.warn(session, message, 'Please provide a valid timestamp')
        }

        await message.channel.setRateLimitPerUser(slowmode);
        session.grant(session, message, `Slowmode has been set to **${slowmode}** seconds`)
    }
};
