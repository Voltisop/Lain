const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'steal',
        aliases: ['none'],
        description: 'Steal an emoji',
        syntax: 'steal <emoji> <name>',
        module: 'utility'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_EMOJIS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const [emoji, name] = args;

        if (!emoji || !name) {
            return session.warn(session, message, 'Please provide both the emoji and the name');
        }

        try {
            const url = `https://cdn.discordapp.com/emojis/${emoji.replace(/\D/g, '')}.png`;
            const addedEmoji = await message.guild.emojis.create(url, name);
            return session.neutral(session, message, `${addedEmoji} has been added successfully.`);
        } catch (error) {
            console.error('Error adding emoji:', error);
            return session.warn(session, message, 'An error occurred while adding the emoji.');
        }
    }
};
