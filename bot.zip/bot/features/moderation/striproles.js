const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'striproles',
        aliases: ['strip'],
        description: 'Strip all of a user\'s roles',
        syntax: 'striproles <member>',
        example: 'striproles @kencarsonirl',
        module: 'moderation'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn('You do not have the required permissions to use this command');
        }
        
        const user = message.mentions.members.first();
        if (!user || user.guild.id !== message.guild.id) {
            return session.command(module.exports, session, message);
        }

        if (user.roles.highest.position >= message.member.roles.highest.position) {
            return session.warn('You cannot strip roles from this user');
        }

        try {
            await user.roles.set([]);
            session.grant(session, message, `Stripped roles from ${user}`);
        } catch (error) {
            session.log('Error stripping roles:', error);
            session.warn(session, message, error);
        }
    }
};
