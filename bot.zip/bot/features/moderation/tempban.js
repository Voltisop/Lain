const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'tempban',
        aliases: ['tban'],
        description: 'Temporarily bans a user',
        syntax: 'tempban @c2rter <time> [reason]',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const user = message.mentions.users.first();
        if (!user) {
            return session.command(module.exports, session, message);
        }

        const timeString = args[1];
        if (!timeString) {
            return session.warn(session, message, 'You need to specify a time to ban the user for');
        }

        let time;
        if (/^\d+s$/.test(timeString)) {
            time = parseInt(timeString) * 1000;
        } else if (/^\d+m$/.test(timeString)) {
            time = parseInt(timeString) * 60 * 1000;
        } else if (/^\d+h$/.test(timeString)) {
            time = parseInt(timeString) * 60 * 60 * 1000; 
        } else {
            return session.warn(session, message, 'Invalid time format. Use formats like "60s", "1m", "1h"');
        }

        const reason = args.slice(2).join(' ') || 'No reason provided';

        const member = message.guild.members.cache.get(user.id);
        if (member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn(session, message, 'You cannot ban this user');
        }

        await member.ban({ reason: reason });

        setTimeout(async () => {
            await message.guild.members.unban(user.id);
        }, time);

        session.grant(session, message, `Successfully banned ${user.tag} for ${timeString}`);
    }
};
