const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'topic',
        aliases: ['settopic', 'setdescription'],
        description: 'Set the channel topic',
        syntax: 'topic <topic>',
        module: 'moderation'
    },

    run: async(session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        if (!args.length) {
            return session.command(module.exports, session, message)
        }

        const channel = message.channel;
        const topic = args.join(' ');

        channel.setTopic(topic);

        session.grant(session, message, `The topic for this channel has been set to \`${topic}\``);
    }
}