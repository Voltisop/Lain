const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'unban',
        aliases: ['unbanuser'],
        description: 'Unban a user',
        syntax: 'unban <user>',
        module: 'moderation',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command')
        }

        const user = args[0];
        if (!user) {
            return session.commmand(module.exports, session, message);
        }

        message.guild.members.unban(user);

        session.grant(session, message, `User ${user} has been unbanned`);
    }
}