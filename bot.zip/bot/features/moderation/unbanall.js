const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'unbanall',
        aliases: ['unbanall'],
        description: 'Unban all members in the server',
        syntax: 'unbanall',
        module: 'moderation',
        permissions: 'ban_members'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.BAN_MEMBERS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command')
        }

        const bans = await message.guild.fetchBans();
        bans.forEach(async ban => {
            await message.guild.members.unban(ban.user.id);
        });

        session.grant(session, message, 'All members have been unbanned');
    }
}