const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'unhidechannel',
        aliases: ['unhide'],
        description: 'Unhide the channel',
        syntax: 'unhide',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const channel = message.channel;
        const everyone = message.guild.roles.everyone;

        channel.permissionOverwrites.edit(everyone, {
            VIEW_CHANNEL: true
        });

        session.grant(session, message, 'This channel has been unhidden for `@everyone`');
    }
}