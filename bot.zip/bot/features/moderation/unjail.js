const { Permissions } = require('discord.js');
const fs = require('fs').promises;
const dbPath = '/root/bot/tools/db/jail.json';

module.exports = {
    configuration: {
        name: 'unjail',
        aliases: ['ujail'],
        description: 'Unjails a mentioned user',
        syntax: 'unjail @user',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const jailSettings = await loadJailSettings();
        const guildId = message.guild.id;
        const jailData = jailSettings[guildId];

        if (!jailData) {
            return session.warn(session, message, 'Jail has not been set up in this guild');
        }

        const jailRoleId = jailData.jailRoleId;

        const userToUnjail = message.mentions.members.first();
        if (!userToUnjail) {
            return session.warn(session, message, 'Please mention a user to unjail');
        }

        try {
            await userToUnjail.roles.remove(jailRoleId);
        } catch (error) {
            console.error('Error unjailing user:', error);
            return session.warn(session, message, 'An error occurred while unjailing the user.');
        }

        if (jailData.previousRoles && jailData.previousRoles[userToUnjail.id]) {
            try {
                const previousRoles = jailData.previousRoles[userToUnjail.id];
                for (const roleId of previousRoles) {
                    const role = message.guild.roles.cache.get(roleId);
                    if (role) {
                        await userToUnjail.roles.add(role);
                    }
                }
                delete jailData.previousRoles[userToUnjail.id];
                await saveJailSettings(jailSettings);
            } catch (error) {
                console.error('Error restoring previous roles:', error);
            }
        }

        return message.react('✅');
    }
};

async function loadJailSettings() {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading jail settings file:', error.message);
        return {};
    }
}

async function saveJailSettings(settings) {
    try {
        await fs.writeFile(dbPath, JSON.stringify(settings, null, 2));
    } catch (error) {
        console.error('Error saving jail settings file:', error.message);
    }
}