const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'unlock',
        aliases: ['unlockdown', 'unlockchannel'],
        description: 'Unlock the channel',
        syntax: 'unlock',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        const channel = message.channel;
        const everyone = message.guild.roles.everyone;

        channel.permissionOverwrites.edit(everyone, {
            SEND_MESSAGES: true
        });

        session.grant(session, message, 'This channel has been unlocked for `@everyone`');
    }
}