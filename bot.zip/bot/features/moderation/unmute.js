const fs = require('fs');
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'unmute',
        aliases: ['unshutup'],
        description: 'Unmute a specific user in the channel',
        syntax: 'unmute <user>',
        example: 'unmute @user',
        permissions: 'MANAGE_ROLES',
        module: 'moderation',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_ROLES)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const targetUser = message.mentions.members.first();
        if (!targetUser) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const moderationSettingsPath = '/root/bot/tools/db/moderation.json';

        try {
            let moderationSettings = {};
            if (fs.existsSync(moderationSettingsPath)) {
                moderationSettings = JSON.parse(fs.readFileSync(moderationSettingsPath, 'utf8'));
            }

            const guildSettings = moderationSettings[guildID];
            if (!guildSettings) {
                return session.warn(session, message, 'Moderation settings have not been configured for this server, run `setupmod`');
            }

            const muteRoleID = guildSettings.roles.muteRole;
            const muteRole = message.guild.roles.cache.get(muteRoleID);
            if (!muteRole) {
                return session.warn(session, message, 'Mute role not found. Please configure moderation settings using `removemod` & run `setupmod`');
            }

            await targetUser.roles.remove(muteRole);
            session.grant(session, message, `Unmuted ${targetUser}`);
        } catch (error) {
            console.error('Error removing mute role:', error);
            session.error(session, message, 'An error occurred while removing mute role');
        }
    }
};
