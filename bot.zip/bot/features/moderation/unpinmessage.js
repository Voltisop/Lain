const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'unpinmessage',
        aliases: ['unpin'],
        description: 'Unpin a message',
        syntax: 'unpin <message>',
        module: 'moderation'
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        if (!args.length) {
            return session.command(module.exports, session, message)
        }

        const channel = message.channel;
        const messageID = args[0];

        channel.messages.fetch(messageID)
            .then(message => message.unpin())
            .then(() => session.grant(session, message, 'The message has been unpinned'))
            .catch(() => session.warn('The message could not be unpinned'))
    }
}