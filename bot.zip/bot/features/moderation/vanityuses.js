const { Permissions } = require('discord.js');

module.exports = {
    configuration : {
        name: 'vanityuses',
        aliases: ['uses'],
        description: 'Check how many uses your vanity has',
        syntax: 'vanityuses',
        module: 'moderation',
        permissions: 'manage_guild'
    },

    run: async (session, message, args) => {

        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn('You do not have the required permissions to use this command')
        }

        if (!message.guild.features.includes('VANITY_URL')) {
            return session.warn(session, message, 'This server does not have a vanity');
        }

        const vanityURL = message.guild.vanityURLCode;
        if (!vanityURL) {
            return session.warn(session, message, 'This server does not have a vanity');
        }

        const vanityInfo = await message.guild.fetchVanityData();
        return session.neutral(session, message, `The vanity **${vanityURL}** has been used **${vanityInfo.uses}** times`);
    }
}