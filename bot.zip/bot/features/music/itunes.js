const { MessageEmbed } = require('discord.js');
const axios = require('axios');
const qs = require('qs');

module.exports = {
    configuration: {
        name: 'itunes',
        aliases: ['itu'],
        description: 'Search iTunes for a song',
        syntax: 'itunes <query>',
        example: 'itunes Hardcore',
        module: 'music'
    },

    run: async (session, message, args) => {
        try {
            if (!args[0]) {
                return session.command(module.exports, session, message);
            }

            const query = qs.stringify({
                term: args.join(' '),
                entity: 'song'
            });

            const response = await axios.get(`https://itunes.apple.com/search?${query}`);

            if (!response.data.results.length) {
                return session.warn(session, message, 'No results found for that query');
            }

            message.channel.send(response.data.results[0].trackViewUrl);
        } catch (error) {
            session.log('Error searching iTunes:', error);
            session.warn(session, message, error.message);
        }
    }
};
