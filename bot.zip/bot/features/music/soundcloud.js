const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'soundcloud',
        description: 'Search for a song on SoundCloud',
        syntax: 'soundcloud <query>',
        example: 'soundcloud Hardcore',
        aliases: ['sc'],
        module: 'music'
    },
    run: async (session, message, args, prefix) => {
        try {
            if (!args[0]) {
                return session.command(module.exports, session, message);
            }

            const response = await axios.get(`https://api-v2.soundcloud.com/search/tracks?q=${args.join(' ')}`, {
                headers: {
                    'Authorization': session.soundcloud
                }
            });
            const results = response.data;

            if (!results.collection.length) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(session.warn)
                            .setDescription(`${session.mark} ${message.author}: No results found for **${args.join(' ')}**`)
                    ]
                });
            }

            message.channel.send(`${results.collection[0].permalink_url}`);

            if (!args[0]) {
                return session.command(module.exports, session, message);
            }
        } catch (error) {
            session.log('Error searching SoundCloud:', error);
            session.warn(session, message, error.message);
        }
    }
};
