const SpotifyWebApi = require('spotify-web-api-node');

module.exports = {
    configuration: {
        name: 'spotify',
        aliases: ['sp'],
        description: 'Search spotify for a song',
        syntax: 'spotify <query>',
        example: 'spotify Hardcore',
        module: 'music'
    },

    run: async (session, message, args) => {

        const SpotifyClient = new SpotifyWebApi({
            clientId: session.clientId,
            clientSecret: session.clientSecret
        });

        try {
            const query = args.join(' ');

            if (!query) {
                return session.command(module.exports, session, message);
            }

            const credentials = await SpotifyClient.clientCredentialsGrant();
            SpotifyClient.setAccessToken(credentials.body['access_token']);

            const { body: { tracks } } = await SpotifyClient.searchTracks(query);

            if (!tracks || tracks.items.length === 0) {
                return session.warn(session, message, error.message);
            }

            const track = tracks.items[0];

            message.channel.send(track.external_urls.spotify);
        } catch (error) {
            session.log('Error searching Spotify:', error);
            session.warn(session, message, error.message);
        }
    }
};