const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'cuddle',
        aliases: ['none'],
        description: 'Cuddle with a member',
        syntax: 'cuddle <member>',
        example: 'cuddle @c2rter',
        module: 'roleplay'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first();

        if (!user) {
            return session.command(module.exports, session, message)
        }

        try {
            const { data } = await axios.get('https://nekos.life/api/v2/img/cuddle');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription(`${message.author} cuddles ${user.user}`)
                        .setURL(data.url)
                        .setImage(data.url)
                        .setColor(session.color)
                ]
            });

        } catch (error) {
            session.log('Error fetching cuddle image/gif:', error);
            session.warn(session, message, 'Error fetching cuddle image/gif');
        }
    }
};