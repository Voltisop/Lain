const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'feed',
        aliases: ['none'],
        description: 'Feed a member',
        syntax: 'feed <member>',
        example: 'feed @kencarsonirl',
        module: 'roleplay'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first();

        if (!user) {
            return session.command(module.exports, session, message)
        }

        try {
            const { data } = await axios.get('https://nekos.life/api/v2/img/feed');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle(`${message.author.username} fed ${user.user.username}`)
                        .setURL(data.url)
                        .setImage(data.url)
                        .setColor(session.color)
                ]
            });
        } catch (error) {
            session.log('Error fetching feed image:', error);
            session.warn(session, message, error.message);
        }
    }
};
