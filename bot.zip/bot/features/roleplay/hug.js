const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'hug',
        aliases: ['none'],
        description: 'Hug a member',
        syntax: 'hug <member>',
        example: 'hug @c2rter',
        module: 'roleplay'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first();

        if (!user) {
            return session.command(module.exports, session, message)
        }

        try {
            const { data } = await axios.get('https://nekos.life/api/v2/img/hug');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle(`${message.author.username} hugged ${user.user.username}`)
                        .setURL(data.url)
                        .setImage(data.url)
                        .setColor(session.color)
                ]
            });
        } catch (error) {
            session.log('Error fetching hug image:', error);
            session.warn(session, message, error.message);
        }
    }
};
