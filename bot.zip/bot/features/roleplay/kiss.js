const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'kiss',
        aliases: ['none'],
        description: 'Kiss with a member',
        syntax: 'kiss <member>',
        example: 'kiss @c2rter',
        module: 'roleplay'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first();

        if (!user) {
            return session.command(module.exports, session, message)
        }

        try {
            const { data } = await axios.get('https://nekos.life/api/v2/img/kiss');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle(`${message.author.username} kissed ${user.user.username}`)
                        .setURL(data.url)
                        .setImage(data.url)
                        .setColor(session.color)
                ]
            });
        } catch (error) {
            session.log('Error fetching kiss image:', error);
            session.warn(session, message, error.message);
        }
    }
};