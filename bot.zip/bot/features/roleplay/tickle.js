const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'tickle',
        aliases: ['none'],
        description: 'Tickle a member',
        syntax: 'tickle <member>',
        example: 'tickle @c2rter',
        module: 'roleplay'
    },
    run: async (session, message, args) => {
        const user = message.mentions.members.first();

        if (!user) {
            return session.command(module.exports, session, message);
        }

        try {
            const { data } = await axios.get('https://nekos.life/api/v2/img/tickle');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription(`${message.author} tickles ${user.user}`)
                        .setURL(data.url)
                        .setImage(data.url)
                        .setColor(session.color)
                ]
            });

        } catch (error) {
            session.log('Error fetching tickle image/gif:', error);
            session.warn(session, message, 'Error fetching tickle image/gif');
        }
    }
};
