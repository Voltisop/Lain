const fs = require('fs');
const { Permissions } = require('discord.js');
const db = '/root/bot/tools/db/autopfp.json';

let autopfpConfig = {};
if (fs.existsSync(db)) {
    autopfpConfig = JSON.parse(fs.readFileSync(db));
}

const saveConfig = (config) => {
    fs.writeFileSync(db, JSON.stringify(config, null, 2));
};

module.exports = {
    configuration: {
        name: 'autopfp',
        aliases: ['pfps'],
        description: 'Automatically sends pfps to a channel',
        syntax: 'autopfp [set|reset] <channel>',
        module: 'servers',
        subcommands: ['> autopfp set\n> autopfp reset']
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const subcommand = args.shift().toLowerCase();

        switch (subcommand) {
            case 'set':
                if (!args.length || !message.mentions.channels.size) {
                    return session.warn(session, message, 'Please mention a channel');
                }
                const channel = message.mentions.channels.first();
                if (channel.guild.id !== message.guild.id) {
                    return session.warn(session, message, 'The mentioned channel is not in this server');
                }
                autopfpConfig[message.guild.id] = { channelId: channel.id };
                saveConfig(autopfpConfig);
                return message.react('✅');

            case 'reset':
                delete autopfpConfig[message.guild.id];
                saveConfig(autopfpConfig);
                return message.react('✅');

            default:
                return session.command(module.exports, session, message);
        }
    }
};
