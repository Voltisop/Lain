const fs = require('fs');
const path = require('path');
const { MessageEmbed, Permissions } = require('discord.js');
const db = '/root/bot/tools/db/autorole.json'

const readAutoroleConfig = () => {
    try {
        const data = fs.readFileSync(db, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading autorole config:', error);
        return {};
    }
};

const writeAutoroleConfig = (config) => {
    try {
        fs.writeFileSync(db, JSON.stringify(config, null, 4));
    } catch (error) {
        console.error('Error writing autorole config:', error);
    }
};

module.exports = {
    configuration: {
        name: "autorole",
        aliases: ['arl'],
        description: "Manage autoroles for the server",
        syntax: "autorole [add|remove|reset|list] <role>",
        subcommands: ['> autorole add\n> autorole remove\n> autorole reset\n> autorole list'],
        module: 'servers',
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const [action, ...roleArgs] = args;
        if (!action) return session.command(module.exports, session, message);

        switch (action.toLowerCase()) {
            case 'add': {
                const config = readAutoroleConfig();
                const guildId = message.guild.id;
                
                if (!config[guildId]) config[guildId] = [];
                if (config[guildId].length >= 3) {
                    return session.warn(session, message, 'You can only have up to 3 autoroles');
                }

                const role = getRoleFromMention(message, roleArgs.join(" "));
                if (!role) {
                    return session.warn(session, message, 'Please mention a role');
                }

                if (config[guildId].includes(role.id)) {
                    return session.warn(session, message, 'This role is already an autorole.');
                }

                if (message.guild.me.roles.highest.comparePositionTo(role) <= 0) {
                    return session.warn(session, message, 'I cannot assign roles higher than my own')
                }

                config[guildId].push(role.id);
                writeAutoroleConfig(config);

                session.grant(session, message, `Auto role **${role.name}** has been added`)
                break;
            }
            case 'remove': {
                const config = readAutoroleConfig();
                const guildId = message.guild.id;

                if (!config[guildId]) {
                    return session.warn(session, message, 'There are no autoroles in this server')
                }

                const role = getRoleFromMention(message, roleArgs.join(" "));
                if (!role) {
                    return session.warn(session, message, 'Please mention a role')
                }

                if (!config[guildId].includes(role.id)) {
                    return session.warn(session, message, 'This role is not an autorole')
                }

                config[guildId] = config[guildId].filter(id => id !== role.id);
                writeAutoroleConfig(config);

                session.grant(session, message, `Auto role **${role.name}** has been removed`)
                break;
            }
            case 'reset': {
                const config = readAutoroleConfig();
                const guildId = message.guild.id;

                if (!config[guildId]) {
                    return session.warn(session, message, 'There are no autoroles in this server')
                }

                delete config[guildId];
                writeAutoroleConfig(config);

                return session.grant(session, message, 'Auto roles have been reset')
                break;
            }
            case 'list': {
                const config = readAutoroleConfig();
                const guildId = message.guild.id;

                if (!config[guildId] || config[guildId].length === 0) {
                    return session.warn(session, message, 'There are no autoroles in this server')
                }

                const autoroleNames = config[guildId].map(roleId => {
                    const role = message.guild.roles.cache.get(roleId);
                    return role ? role.name : `Unknown Role (${roleId})`;
                });

                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setTitle(`Auto roles for ${message.guild}`)
                            .setDescription(`${autoroleNames.join('\n')}`)
                            .setColor(session.color)
                    ]
                });
                break;
            }
            default:
                return session.command(module.exports, session, message);
        }
    }
};

const getRoleFromMention = (message, mention) => {
    const matches = mention.match(/^<@&(\d+)>$/);
    if (!matches) return null;
    const roleId = matches[1];
    return message.guild.roles.cache.get(roleId);
};
