const db = '/root/bot/tools/db/embeds.json';
const { Permissions } = require('discord.js');
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'embeds',
        aliases: ['embed'],
        description: 'Make warning/approval messages embeds or messages',
        syntax: 'embeds [enable|disable]',
        module: 'servers',
        subcommands: ['> embeds enable\n> embeds disable']
    },
    run: async (session, message, args) => {
        if (!message.guild) {
            return session.warn(session, message, 'This command can only be used in a server.');
        }

        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn('You do not have the required permissions to use this command');
        }

        if (!args.length || (args[0] !== 'enable' && args[0] !== 'disable')) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const embedsData = JSON.parse(fs.readFileSync(db, 'utf8'));

        switch (args[0]) {
            case 'enable':
                embedsData[guildID] = true;
                fs.writeFileSync(db, JSON.stringify(embedsData, null, 4));
                return session.grant(session, message, 'Embeds enabled for this guild');
            case 'disable':
                embedsData[guildID] = false;
                fs.writeFileSync(db, JSON.stringify(embedsData, null, 4));
                return session.grant(session, message, 'Embeds disabled for this guild');
            default:
                return session.command(module.exports, session, message);
        }
    },
    embedsEnabledForGuild
};

function embedsEnabledForGuild(guildID) {
    const embedsData = JSON.parse(fs.readFileSync(db, 'utf8'));
    return embedsData[guildID] || false;
}
