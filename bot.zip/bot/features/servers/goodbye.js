const { MessageEmbed } = require('discord.js');
const fs = require('fs').promises;
const db = '/root/bot/tools/db/goodbye.json';

async function loadGoodbyeSettings() {
    try {
        const data = await fs.readFile(db, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading goodbye settings file:', error.message);
        return {};
    }
}

async function saveGoodbyeSettings(settings) {
    try {
        await fs.writeFile(db, JSON.stringify(settings, null, 2), 'utf8');
    } catch (error) {
        console.error('Error writing goodbye settings file:', error.message);
    }
}

module.exports = {
    configuration: {
        name: 'goodbye',
        aliases: ['gb'],
        description: 'Manage goodbye settings for the server.',
        syntax: 'goodbye <subcommand>',
        example: 'goodbye message goodbye {user}',
        subcommands: ['> goodbye message\n> goodbye channel\n> goodbye view\n> goodbye clear'],
        module: 'servers'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }
        const subcommand = args[0];

        if (!subcommand) {
            return session.command(module.exports, session, message);
        }

        const guildId = message.guild.id;
        const allSettings = await loadGoodbyeSettings();
        const guildSettings = allSettings[guildId] || {};

        switch (subcommand.toLowerCase()) {
            case 'message':
                const goodbyeMessage = args.slice(1).join(' ');

                if (!goodbyeMessage) {
                    return session.warn(session, message, 'Please provide a goodbye message');
                }

                guildSettings.message = goodbyeMessage;
                allSettings[guildId] = guildSettings;
                await saveGoodbyeSettings(allSettings);

                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(session.color)
                            .setDescription(`Goodbye message set to:\n\`\`\`${goodbyeMessage}\`\`\``)
                    ]
                });
                break;

            case 'channel':
                const goodbyeChannel = message.mentions.channels.first();
                if (!goodbyeChannel) {
                    return session.warn(session, message, 'Please mention a channel');
                }

                guildSettings.channelID = goodbyeChannel.id;
                allSettings[guildId] = guildSettings;
                await saveGoodbyeSettings(allSettings);
                return session.grant(session, message, `Now saying goodbye to users in ${goodbyeChannel}`);
                break;

            case 'view':
                const viewEmbed = new MessageEmbed()
                    .setColor(session.color)
                    .setTitle('Goodbye Settings')
                    .addField('Message', guildSettings.message || 'Not set', true)
                    .addField('Channel', guildSettings.channelID ? `<#${guildSettings.channelID}>` : 'Not set', true);
                message.channel.send({ embeds: [viewEmbed] });
                break;

            case 'clear':
                delete allSettings[guildId];
                await saveGoodbyeSettings(allSettings);
                return session.grant(session, message, 'Goodbye settings have been cleared');
                break;

            default:
                return session.command(module.exports, session, message);
        }
    }
};
