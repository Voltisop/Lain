const fs = require('fs');
const db = '/root/bot/tools/db/imageonly.json';
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'imageonly',
        aliases: ['gallery'],
        description: 'Restrict a channel to images only',
        syntax: 'imageonly [add|remove|clear] #channel',
        example: 'imageonly add #selfies',
        subcommands: ['> imageonly add\n> imageonly remove\n> imageonly clear']
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_CHANNELS)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const action = args[0];
        const channel = message.mentions.channels.first();
        const guildId = message.guild.id;

        let imageOnlyData;
        try {
            if (!fs.existsSync(db)) {
                fs.writeFileSync(db, JSON.stringify({}), 'utf8');
            }
            const fileContent = fs.readFileSync(db, 'utf8');
            imageOnlyData = JSON.parse(fileContent);
            if (typeof imageOnlyData !== 'object' || imageOnlyData === null) {
                throw new Error('Invalid JSON format');
            }
        } catch (error) {
            session.log(`Failed to read or parse ${db}:`, error);
            imageOnlyData = {};
            fs.writeFileSync(db, JSON.stringify(imageOnlyData), 'utf8');
            session.warn(session, message, 'The configuration file was invalid and has been reset.');
        }

        if (!imageOnlyData[guildId]) {
            imageOnlyData[guildId] = [];
        }

        switch (action) {
                case 'add':
                    break;
                case 'remove':
                    if (!channel) return session.warn(session, message, 'Please mention a channel');
                    if (!imageOnlyData[guildId].includes(channel.id)) return session.warn(session, message, 'This channel is not restricted to images only');
                    imageOnlyData[guildId] = imageOnlyData[guildId].filter(id => id !== channel.id);
                    if (imageOnlyData[guildId].length === 0) {
                        delete imageOnlyData[guildId];
                    }
                    fs.writeFileSync(db, JSON.stringify(imageOnlyData), 'utf8');
                    session.grant(session, message, 'The channel restriction to images only has been successfully removed');
                    break;
                case 'clear':
                    imageOnlyData[guildId] = [];
                    delete imageOnlyData[guildId];
                    fs.writeFileSync(db, JSON.stringify(imageOnlyData), 'utf8');
                    session.grant(session, message, 'All channels have been cleared from the images only restriction');
                    break;
                default:
                    return session.warn(session, message, 'Invalid command usage. Use add, remove or clear');
            }
        }
    }
