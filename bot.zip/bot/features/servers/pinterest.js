const { MessageAttachment, Permissions } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: "pinterestboard",
        aliases: ['pins'],
        description: "Search pins or view a user's pins on Pinterest",
        syntax: "pinterestboard add <channel> (username)",
        example: "pinterestboard add #pfps hygric",
        module: 'servers',
    },
    run: async (session, message, args) => {
        const subcommand = args[0]?.toLowerCase();

        if (subcommand === 'add') {
            if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
                return session.warn(session, message, 'You do not have the required permissions to use this command');
            }

            const channelArg = args[1];
            const username = args[2];

            if (!channelArg || !username) {
                return displayCommandInfo(module.exports, session, message);
            }
            let channel;
            if (channelArg.startsWith('<#') && channelArg.endsWith('>')) {
                const channelId = channelArg.slice(2, -1);
                channel = message.guild.channels.cache.get(channelId);
            } else {
                const channelName = channelArg.replace(/^#/, '');
                channel = message.guild.channels.cache.find(ch => ch.name === channelName);
            }
            if (!channel) {
                return session.warn(session, message, 'Channel not found');
            }
            try {
                const pins = await fetchPins(username);
                if (pins.length === 0) {
                    return session.warn(session, message, 'No pins found for that user');
                }
                let attachments = [];
                let i = 0;
                for (const pin of pins) {
                    if (i >= 2) {
                        await channel.send({ files: attachments });
                        attachments = [];
                        i = 0;
                    }
                    const attachment = new MessageAttachment(pin.image);
                    attachments.push(attachment);
                    i++;
                }
                if (attachments.length > 0) {
                    await channel.send({ files: attachments });
                }
            } catch (error) {
                session.log('Error fetching pins:', error);
                return session.warn(session, message, error.message);
            }
        } else {
            return session.command(module.exports, session, message)
        }
    }
};

async function fetchPins(username) {
    const pinsUrl = `https://api.pinterest.com/v3/pidgets/users/${username}/pins/`;
    const response = await axios.get(pinsUrl);
    const pins = response.data.data.pins.map(pin => ({
        description: pin.description || 'Pin',
        url: `https://www.pinterest.com${pin.link}`,
        image: pin.images['564x'].url
    }));
    return pins;
}
