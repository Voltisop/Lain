const fs = require('fs');
const { Permissions } = require('discord.js');
const db = '/root/bot/tools/db/prefix.json';

module.exports = {
    configuration: {
        name: 'prefix',
        aliases: ['setprefix'],
        description: 'Set the bot prefix for this server',
        syntax: 'prefix <set|reset> <prefix>',
        example: 'prefix set !',
        module: 'servers'
    },
    run: async (session, message, args) => {
        if (!message.guild) {
            return session.warn('This command can only be used in a server.');
        }

        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn('You do not have the required permissions to use this command.');
        }

        if (args.length === 0) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const prefixData = JSON.parse(fs.readFileSync(db, 'utf8'));

        const action = args[0].toLowerCase();

        switch (action) {
            case 'set':
                if (args.length < 2) {
                    return session.warn('Please specify the new prefix.');
                }
                const newPrefix = args[1];
                prefixData[guildID] = newPrefix;

                fs.writeFileSync(db, JSON.stringify(prefixData, null, 4));
                return message.react('✅');

            case 'reset':
                delete prefixData[guildID];

                fs.writeFileSync(db, JSON.stringify(prefixData, null, 4));
                return message.react('✅');

            default:
                return session.warn('Invalid action. Use `prefix set <prefix>` to set a new prefix or `prefix reset` to reset to the default prefix.');
        }
    }
};
