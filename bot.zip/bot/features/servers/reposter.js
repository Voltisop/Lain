const db = '/root/bot/tools/db/reposter.json';
const { Permissions } = require('discord.js');
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'reposters',
        aliases: ['reposter'],
        description: 'Toggle whether social media links are reposted',
        syntax: 'reposters [enable|disable]',
        module: 'servers',
        subcommands: ['> reposters enable\n> reposters disable']
    },
    run: async (session, message, args) => {
        if (!message.guild) {
            return session.warn('This command can only be used in a server.');
        }

        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return session.warn('You do not have the required permissions to use this command');
        }

        if (!args.length || (args[0] !== 'enable' && args[0] !== 'disable')) {
            return session.command(module.exports, session, message);
        }

        const guildID = message.guild.id;
        const reposterData = JSON.parse(fs.readFileSync(db, 'utf8'));

        switch (args[0]) {
            case 'enable':
                reposterData[guildID] = true;
                fs.writeFileSync(db, JSON.stringify(reposterData, null, 4));
                return session.grant(session, message, 'Reposting enabled for this guild');
            case 'disable':
                reposterData[guildID] = false;
                fs.writeFileSync(db, JSON.stringify(reposterData, null, 4));
                return session.grant(session, message, 'Reposting disabled for this guild');
            default:
                return session.command(module.exports, session, message);
        }
    },
    reposterEnabledForGuild
};

function reposterEnabledForGuild(guildID) {
    const reposterData = JSON.parse(fs.readFileSync(db, 'utf8'));
    return reposterData[guildID] || false;
}