module.exports = {
    configuration : {
        name: 'stealbanner',
        aliases: ['stealb'],
        description: 'Steal the banner of another server',
        syntax: 'stealbanner <invite code>',
        example: 'stealbanner okay',
        module: 'servers',
    },

    run: async (session, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command')
        }

        if (!args[0]) {
            return session.command(module.exports, session, message);
        }

        let invite = await message.client.fetchInvite(args[0]).catch(() => {
            return session.warn(session, message, 'Invalid invite')
        });

        let guild = invite.guild;
        let banner = guild.bannerURL({ format: 'png', size: 1024 });

        if (!banner) {
            return session.warn(session, message, 'This server does not have a banner');
        }

        message.guild.setBanner(banner).then(() => {
            return session.grant(session, message, `Set the banner to **[this image](banner)**`)
        }).catch(error => {
            session.warn(session, message, error)
            session.log('Error setting banner:', error)
        });
    }
}