module.exports = {
    configuration : {
        name: 'stealicon',
        aliases: ['steali'],
        description: 'Steal the icon of another server using its invite',
        syntax: 'stealicon <invite code>',
        example: 'stealicon okay',
        module: 'servers',
    },

    run: async (session, message, args) => {
            
            if (!message.member.permissions.has('MANAGE_GUILD')) {
                return session.warn(session, message, 'You do not have the required permissions to use this command')
            }
    
            if (!args[0]) {
                return session.command(module.exports, session, message);
            }
    
            let invite = await message.client.fetchInvite(args[0]).catch(() => {
                return session.warn(session, message, 'Invalid invite')
            });
    
            let guild = invite.guild;
            let icon = guild.iconURL({ format: 'png', size: 1024 });
    
            if (!icon) {
                return session.warn(session, message, 'This server does not have an icon');
            }
    
            message.guild.setIcon(icon).then(() => {
                session.grant(session, message, `Set the icon to **[this image](${icon})**`)
            });
        }
    }