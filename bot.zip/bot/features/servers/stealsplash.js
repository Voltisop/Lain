module.exports = {
    configuration : {
        name: 'stealsplash',
        aliases: ['steals'],
        description: 'Steal the splash of another server using its invite',
        syntax: 'stealsplash <invite code>',
        example: 'stealsplash okay',
        module: 'servers',
    },

    run: async (session, message, args) => {

        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command')
        }

        if (!args[0]) {
            return session.command(module.exports, session, message);
        }

        let invite = await message.client.fetchInvite(args[0]).catch(() => {
            return session.warn(session, message, 'Invalid invite')
        });

        let guild = invite.guild;
        let splash = guild.splashURL({ format: 'png', size: 1024 });

        if (!splash) {
            return session.warn(session, message, 'This server does not have a splash');
        }

        message.guild.setSplash(splash).then(() => {
            return session.grant(session, message, `Set the splash to **[this image](${splash})**`)
        });
    }
}