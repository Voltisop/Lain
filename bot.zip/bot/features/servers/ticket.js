const fs = require('fs');
const { MessageEmbed, MessageButton, MessageActionRow } = require('discord.js');
const ticketsFilePath = '/root/bot/tools/db/ticket.json';
const ticketsConfigFilePath = '/root/bot/tools/db/tickets.json';

module.exports = {
    configuration: {
        name: 'ticket',
        aliases: ['none'],
        description: 'Set up ticketing system in a specific channel.',
        syntax: 'ticket channel #tickets',
        module: 'servers',
        subcommands: ['> ticket add\n> ticket remove\n> ticket channel\n> ticket category\n> ticket clear\n> ticket close']
    },
    run: async (session, message, args) => {
        const subcommand = args[0];
        const guildId = message.guild.id;

        switch (subcommand) {
            case 'add': {
                const mentionedMember = message.mentions.members.first();
                const targetUser = mentionedMember ? mentionedMember : args[1];
                
                if (!targetUser) {
                    return session.warn(session, message, 'Please specify a user to add to the ticket');
                }

                const ticketData = loadTicketData(guildId);
                if (!ticketData.category) {
                    return session.warn(session, message, 'Ticket category not set, hence cannot add a user to the ticket');
                }

                const ticketChannel = message.channel;
                if (ticketChannel.parentId !== ticketData.category) {
                    return session.warn(session, message, 'This channel is not a ticket channel');
                }

                ticketChannel.permissionOverwrites.edit(targetUser.id || targetUser, {
                    VIEW_CHANNEL: true,
                    SEND_MESSAGES: true
                }).then(() => {
                    session.grant(session, message, 'User has been added to the ticket successfully');
                }).catch(error => {
                    session.log('Error within ticket add command:', error);
                    session.warn(session, message, error);
                });
                break;
            }
            
            case 'remove': {
                const mentionedMember = message.mentions.members.first();
                const targetUser = mentionedMember ? mentionedMember : args[1];

                if (!targetUser) {
                    return session.warn(session, message, 'Please specify a user to remove from the ticket');
                }

                const ticketData = loadTicketData(guildId);
                if (!ticketData.category) {
                    return session.warn(session, message, 'Ticket category not set, hence cannot remove a user from the ticket');
                }

                const ticketChannel = message.channel;
                if (ticketChannel.parentId !== ticketData.category) {
                    return session.warn(session, message, 'This channel is not a ticket channel');
                }

                ticketChannel.permissionOverwrites.edit(targetUser.id || targetUser, {
                    VIEW_CHANNEL: false,
                    SEND_MESSAGES: false
                }).then(() => {
                    session.grant(session, message, 'User has been removed from the ticket successfully');
                }).catch(error => {
                    session.log('Error within ticket remove command:', error);
                    session.warn(session, message, error);
                });
                break;
            }

            case 'channel': {
                const ticketData = loadTicketData(guildId);
                const channel = message.mentions.channels.first();

                if (!ticketData.category) {
                    return session.warn(session, message, 'Ticket category not set, hence cannot set the ticket channel');
                }

                if (ticketData.channel) {
                    return session.warn(session, message, 'Ticket channel already set');
                }

                if (!channel) {
                    return session.command(module.exports, session, message);
                }

                ticketData.channel = channel.id;

                const embed = new MessageEmbed()
                    .setAuthor(message.guild.name, message.guild.iconURL({ format: 'png', size: 512, dynamic: true }))
                    .setTitle('Create a ticket')
                    .setColor(session.color)
                    .setDescription('Click on the button below this message to create a ticket');

                const createButton = new MessageButton()
                    .setCustomId('create_ticket')
                    .setLabel('Create')
                    .setEmoji('🎫')
                    .setStyle('SECONDARY');

                const row = new MessageActionRow().addComponents(createButton);

                channel.send({ embeds: [embed], components: [row] }).then(sentMessage => {
                    ticketData.messageLink = sentMessage.url;
                    saveTicketData(guildId, ticketData);
                });
                break;
            }

            case 'category': {
                const categoryID = args[1];
                const ticketData = loadTicketData(guildId);

                if (!categoryID) {
                    return session.command(module.exports, session, message);
                }

                ticketData.category = categoryID;
                saveTicketData(guildId, ticketData);

                session.grant(session, message, 'Ticket category set successfully');
                break;
            }

            case 'clear': {
                saveTicketData(guildId, { channel: null, category: null, messageLink: null });
                session.grant(session, message, 'Ticket settings have been reset successfully');
                break;
            }

            case 'close': {
                const ticketData = loadTicketData(guildId);
                if (!ticketData.category) {
                    return session.warn(session, message, 'Ticket category not set, hence cannot close the ticket');
                }

                const channelID = message.channel.id;

                if (message.channel.parentId === ticketData.category) {
                    message.channel.delete().then(() => {
                        clearTicketSettings(guildId);
                        removeTicketConfig(guildId, channelID);
                    }).catch(error => {
                        session.log('Error within ticket close command:', error);
                        session.warn(session, message, error);
                    });
                } else {
                    return session.warn(session, message, 'This channel is not a ticket channel');
                }
                break;
            }
            default:
                return session.command(module.exports, session, message);
        }
    }
};

function saveTicketData(guildID, ticketData) {
    try {
        let ticketConfig = JSON.parse(fs.readFileSync(ticketsFilePath, 'utf8'));
        ticketConfig[guildID] = ticketData;
        fs.writeFileSync(ticketsFilePath, JSON.stringify(ticketConfig, null, 2), 'utf8');
    } catch (error) {
        console.error('Error saving ticket data:', error);
    }
}

function loadTicketData(guildID) {
    try {
        const rawData = fs.readFileSync(ticketsFilePath, 'utf8');
        const ticketData = JSON.parse(rawData);
        return ticketData[guildID] || { channel: null, category: null, messageLink: null };
    } catch (error) {
        console.error('Error loading ticket data:', error);
        return { channel: null, category: null, messageLink: null };
    }
}

function clearTicketSettings(guildID) {
    saveTicketData(guildID, { channel: null, category: null, messageLink: null });
}

function removeTicketConfig(guildID, channelID) {
    try {
        let config = JSON.parse(fs.readFileSync(ticketsConfigFilePath, 'utf8'));
        delete config[channelID];
        fs.writeFileSync(ticketsConfigFilePath, JSON.stringify(config, null, 2), 'utf8');
    } catch (error) {
        console.error('Error removing ticket config:', error);
    }
}
