const fs = require('fs');
const path = '/root/bot/tools/db/voicemaster.json';

module.exports = {
    configuration: {
        name: 'voicemaster',
        aliases: ['vm'],
        description: 'Create personal voice channels',
        syntax: 'voicemaster setup',
        subcommands: ['> voicemaster setup\n> voicemaster remove\n> voicemaster category\n> voicemaster setname']
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const guildID = message.guild.id;
        const voicemasterData = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path)) : {};

        const saveData = () => fs.writeFileSync(path, JSON.stringify(voicemasterData, null, 2));

        switch (args[0]) {
            case 'setup':
                if (voicemasterData[guildID]) {
                    return session.warn(session, message, 'Voicemaster is already set up for this server');
                }

                const category = await message.guild.channels.create('Voicemaster', { type: 'GUILD_CATEGORY' });
                const channel = await message.guild.channels.create('Join to create', { type: 'GUILD_VOICE', parent: category.id });

                voicemasterData[guildID] = { categoryID: category.id, channelID: channel.id };
                saveData();

                return session.grant(session, message, 'Voicemaster has been set up');

            case 'remove':
                if (!voicemasterData[guildID]) {
                    return session.warn(session, message, 'Voicemaster is not set up for this server. Use `voicemaster setup` first');
                }

                const { categoryID, channelID } = voicemasterData[guildID];
                const categoryToDelete = message.guild.channels.cache.get(categoryID);
                const channelToDelete = message.guild.channels.cache.get(channelID);

                if (categoryToDelete) await categoryToDelete.delete();
                if (channelToDelete) await channelToDelete.delete();

                delete voicemasterData[guildID];
                saveData();

                return session.grant(session, message, 'Voicemaster has been removed');

            case 'category':
                if (!voicemasterData[guildID]) {
                    return session.warn(session, message, 'Voicemaster is not set up for this server. Use `voicemaster setup` first');
                }

                const newCategoryID = args[1];
                const newCategory = message.guild.channels.cache.get(newCategoryID);

                if (!newCategory || newCategory.type !== 'GUILD_CATEGORY') {
                    return session.warn(session, message, 'Please provide a valid category ID');
                }

                voicemasterData[guildID].categoryID = newCategoryID;
                saveData();

                return session.grant(session, message, 'Voicemaster category has been updated');

            case 'setname':
                if (!voicemasterData[guildID]) {
                    return session.warn(session, message, 'Voicemaster is not set up for this server. Use `voicemaster setup` first');
                }

                const newName = args.slice(1).join(' ');

                if (!newName) {
                    return session.warn(session, message, 'Please provide a name for the voice channel');
                }

                voicemasterData[guildID].customName = newName;
                saveData();

                return session.grant(session, message, `Now naming voicemaster channels **${newName}**`);

            default:
                session.command(module.exports, session, message);
        }
    }
};
