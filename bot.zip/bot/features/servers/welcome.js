const { MessageEmbed } = require('discord.js');
const fs = require('fs').promises;
const db = '/root/bot/tools/db/welcome.json';

async function loadWelcomeSettings() {
    try {
        const data = await fs.readFile(db, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading welcome settings file:', error.message);
        return {};
    }
}

async function saveWelcomeSettings(settings) {
    try {
        await fs.writeFile(db, JSON.stringify(settings, null, 2), 'utf8');
    } catch (error) {
        console.error('Error writing welcome settings file:', error.message);
    }
}

module.exports = {
    configuration: {
        name: 'welcome',
        aliases: ['welc'],
        description: 'Manage welcome settings for the server.',
        syntax: 'welcome <subcommand>',
        subcommands: ['> welcome message\n> welcome channel\n> welcome view\n> welcome clear'],
        module: 'servers'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }
        const subcommand = args[0];

        if (!subcommand) {
            return session.command(module.exports, session, message)
        }

        const guildId = message.guild.id;
        const allSettings = await loadWelcomeSettings();
        const guildSettings = allSettings[guildId] || {};

        switch (subcommand.toLowerCase()) {
            case 'message':
                const welcomeMessage = args.slice(1).join(' ');

                if (!welcomeMessage) {
                    return session.warn(session, message, 'Please provide a welcome message');
                }

                const hasEmbedFormatting = welcomeMessage.includes('{');

                if (hasEmbedFormatting) {
                    guildSettings.message = welcomeMessage;
                } else {
                    guildSettings.message = welcomeMessage;
                }

                allSettings[guildId] = guildSettings;
                await saveWelcomeSettings(allSettings);

                message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(session.color)
                            .setDescription(`Welcome message set to:\n\`\`\`${welcomeMessage}\`\`\``)
                    ]
                });
                break;

            case 'channel':
                const welcomeChannel = message.mentions.channels.first();
                if (!welcomeChannel) {
                    return session.warn(session, message, 'Please mention a channel');
                }

                guildSettings.channelID = welcomeChannel.id;
                allSettings[guildId] = guildSettings;
                await saveWelcomeSettings(allSettings);
                return session.grant(session, message, `Now greeting new users in ${welcomeChannel}`);
                break;

            case 'view':
                const viewEmbed = new MessageEmbed()
                    .setColor(session.color)
                    .setTitle('Welcome Settings')
                    .addField('Message', guildSettings.message || 'Not set', true)
                    .addField('Channel', guildSettings.channelID ? `<#${guildSettings.channelID}>` : 'Not set', true);
                message.channel.send({ embeds: [viewEmbed] });
                break;

            case 'clear':
                delete allSettings[guildId];
                await saveWelcomeSettings(allSettings);
                return session.grant(session, message, 'Welcome settings have been cleared');
                break;

            default:
                return session.command(module.exports, session, message);
                break;
        }
    },
};
