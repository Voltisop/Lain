module.exports = {
    configuration: {
        name: 'birthday',
        description: 'See how far your birthday is',
        syntax: 'birthday <month> <day>',
        aliases: ['bday'],
        module: 'utility',
    },
    run: async (session, message, args) => {
        if (args.length !== 2) {
            return session.command(module.exports, session, message);
        }

        const providedMonth = args[0].toLowerCase();
        const providedDay = parseInt(args[1]);

        const months = [
            'january', 'february', 'march', 'april', 'may', 'june',
            'july', 'august', 'september', 'october', 'november', 'december'
        ];

        const monthIndex = months.indexOf(providedMonth);
        if (monthIndex === -1 || isNaN(providedDay) || providedDay < 1 || providedDay > 31) {
            return session.warn(session, message, 'Invalid month or day');
        }

        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const birthdayDate = new Date(currentYear, monthIndex, providedDay);
        const difference = birthdayDate - currentDate;

        const daysUntilBirthday = difference < 0 ? Math.ceil((birthdayDate.setFullYear(currentYear + 1) - currentDate) / (1000 * 60 * 60 * 24)) : Math.ceil(difference / (1000 * 60 * 60 * 24));

        return session.neutral(session, message, `There are ${daysUntilBirthday} days until your birthday`)
    }
};
