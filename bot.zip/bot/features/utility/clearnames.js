const fs = require('fs');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const nameHistoryPath = '/root/bot/tools/db/namehistory.json';

module.exports = {
    configuration: {
        name: 'clearnames',
        aliases: ['clearnamehistory', 'clearnames'],
        description: 'Clears your name history',
        syntax: 'clearnames',
        module: 'information'
    },

    run: async (session, message, args) => {
        const userId = message.author.id;

        try {
            const nameHistoryData = JSON.parse(fs.readFileSync(nameHistoryPath, 'utf8'));
            const userHistory = nameHistoryData[userId];

            const confirmationEmbed = new MessageEmbed()
                .setColor(session.color)
                .setDescription('Are you sure you want to clear your name history?');

            const row = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('clearNameHistory')
                        .setLabel('Yes')
                        .setStyle('SUCCESS'),
                    new MessageButton()
                        .setCustomId('cancelClearNameHistory')
                        .setLabel('No')
                        .setStyle('DANGER')
                );

            const confirmationMessage = await message.channel.send({ embeds: [confirmationEmbed], components: [row] });

            const filter = i => i.customId === 'clearNameHistory' || i.customId === 'cancelClearNameHistory';
            const collector = confirmationMessage.createMessageComponentCollector({ filter, time: 15000 });

            collector.on('collect', async interaction => {
                if (interaction.customId === 'clearNameHistory') {
                    delete nameHistoryData[userId];
                    fs.writeFileSync(nameHistoryPath, JSON.stringify(nameHistoryData, null, 2));
                    await session.grant(session, message, 'Your name history has been cleared');
                } else {
                    await session.neutral(session, message, 'This action has been canceled');
                }
                collector.stop();
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    confirmationMessage.edit({ components: [] });
                }
            });

        } catch (error) {
            console.error('Error reading name history:', error);
            return session.warn(session, message, 'An error occurred while reading name history.');
        }
    }
};
