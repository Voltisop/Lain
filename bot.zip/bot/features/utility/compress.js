const { MessageAttachment } = require('discord.js');
const sharp = require('sharp');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    configuration: {
        name: 'compress',
        aliases: ['none'],
        description: 'Compresses the quality of the given image',
        syntax: 'compress <attachment>',
        module: 'utility'
    },

    run: async (session, message) => {
        if (message.attachments.size === 0) {
            return session.warn(session, message, 'Please attach an image to compress.');
        }

        const attachment = message.attachments.first();
        const imageUrl = attachment.url;
        const imageExt = path.extname(attachment.name);

        if (!['.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff'].includes(imageExt.toLowerCase())) {
            return session.warn(session, message, 'Please attach a valid image file.');
        }

        try {
            const response = await axios({
                url: imageUrl,
                responseType: 'arraybuffer'
            });
            const buffer = Buffer.from(response.data, 'binary');

            sharp(buffer)
                .jpeg({ quality: 50 }) // Set default quality to 50
                .toBuffer()
                .then(compressedBuffer => {
                    const compressedImagePath = path.join(__dirname, `compressed${imageExt}`);
                    
                    fs.writeFileSync(compressedImagePath, compressedBuffer);
                    const compressedAttachment = new MessageAttachment(compressedImagePath);

                    message.channel.send({ files: [compressedAttachment] })
                        .then(() => {
                            fs.unlinkSync(compressedImagePath);
                        })
                        .catch(error => {
                            console.error('Error sending compressed image:', error);
                            session.warn(session, message, 'An error occurred while sending the compressed image.');
                        });
                })
                .catch(error => {
                    console.error('Error compressing image:', error);
                    session.warn(session, message, 'An error occurred while compressing the image.');
                });
        } catch (error) {
            console.error('Error fetching image:', error);
            session.warn(session, message, 'An error occurred while fetching the image.');
        }
    }
};
