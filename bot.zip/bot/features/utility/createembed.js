const { EmbedBuilder } = require('/root/bot/tools/embeds/builder.js');
const { Permissions } = require('discord.js')

module.exports = {
    configuration: {
        name: 'createembed',
        aliases: ['ce'],
        description: 'Create and send a custom embed message.',
        syntax: 'createembed <embed code>',
        module: 'utility'
    },
    run: async (session, message, args) => {
        if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_MESSAGES)) {
            return session.warn('You do not have the required permissions to use this command');
        }

        try {
            if (!args.length) {
                return session.command(module.exports, session, message)
            }

            const embedCode = args.join(' ');

            new EmbedBuilder(message.channel, embedCode, message.author);

        } catch (error) {
            session.log('Error created embed', error)
            session.warn(session, message, 'An error occured')
        }
    }
};
