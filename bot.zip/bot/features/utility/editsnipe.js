const { MessageEmbed } = require('discord.js');
const moment = require('moment');

module.exports = {
    configuration: {
        name: 'editsnipe',
        description: 'View recently edited messages',
        aliases: ['es'],
        syntax: 'editsnipe',
        module: 'utility'
    },
    run: async (session, message, args) => {
        const editsnipes = session.editsnipes.get(message.channel.id);
        
        if (!editsnipes || editsnipes.length === 0) {
            return session.warn(session, message, 'There are no edited messages to snipe');
        }
        
        const latestEditsnipe = editsnipes[0];
        const embed = new MessageEmbed()
        .setColor(session.color)
        .setAuthor(latestEditsnipe.oldMessage.author.username, latestEditsnipe.oldMessage.author.displayAvatarURL({ dynamic: true }))
        .setDescription(`${latestEditsnipe.oldMessage.content} ( original )\n> ${latestEditsnipe.newMessage.content} ( edited )`)
        .setFooter(`Edited ${moment(latestEditsnipe.editedAt).fromNow()}`);
    
        
        message.channel.send({ embeds: [embed] });
    }
};
