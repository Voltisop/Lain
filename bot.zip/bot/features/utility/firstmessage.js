module.exports = {
    configuration: {
        name: 'firstmessage',
        aliases: ['firstmsg'],
        description: 'View the channel\'s first message',
        syntax: 'firstmessage',
        module: 'utility'
    },
    run: async (session, message, args) => {
        
        const channel = message.channel.id;

        const fetchMessages = await message.channel.messages.fetch({
            after: 1,
            limit: 1,
        });
        const firstmessage = fetchMessages.first();

        return session.neutral(session, message, `[here](https://discord.com/channels/${message.guild.id}/${channel}/${firstmessage.id})`)
    }
};
