const DDG = require('duck-duck-scrape');

module.exports = {
    configuration: {
        name: 'google',
        aliases: ['g'],
        description: 'Search using google',
        syntax: 'google <query>',
        example: 'google Node.js'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        try {
            const searchResults = await DDG.search(args.join(' '), {
                safeSearch: DDG.SafeSearchType.STRICT
            });

            if (!searchResults.results || !searchResults.results.length) {
                return session.warn(session, message, 'No results found');
            }

            const embeds = [];
            for (let i = 0; i < searchResults.results.length; i += 3) {
                const fields = searchResults.results.slice(i, i + 3).map(result => ({
                    name: result.title,
                    value: `[${result.hostname}](${result.url})\n${result.rawDescription.replace(/<\/?b>|<\/?s>/g, '')}`, // Filter out <b> and <s> tags
                }));

                embeds.push({
                    title: `Search Results for ${args.join(' ')}`,
                    URL: searchResults.url,
                    fields,
                    color: session.color
                });
            }

            session.pagination(session, message, embeds, embeds.length, searchResults.results.length, null, null);

        } catch (error) {
            session.log('Error fetching DuckDuckGo search results:', error);
            session.warn(session, message, 'Error fetching search results');
        }
    }
};
