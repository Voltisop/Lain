const { MessageEmbed } = require("discord.js");
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'image',
        description: 'Search for an image on google',
        aliases: ["img"],
        syntax: 'image <query>',
        example: 'image cats',
        module: 'utility'
    },
    run: async (session, message, args) => {
        if (!args.length) return session.command(module.exports, session, message);
        
        try {
            const res = await axios(`https://www.googleapis.com/customsearch/v1?key=${session.google}&cx=${session.cxKey}&q=${args.join(' ')}&searchType=image${message.channel.nsfw ? '' : '&safe=active'}&alt=json&start=1`);
            const images = res.data.items;

            if (!images || images.length === 0) {
                return session.warn(session, message, 'No results found');
            }

            const embeds = images.slice(0, 10).map(image => (
                new MessageEmbed()
                    .setAuthor(message.author.username, message.author.displayAvatarURL({ dynamic: true }))
                    .setImage(image.link)
                    .setTitle(image.title)
                    .setColor(session.color)
            ));

            session.pagination(session, message, embeds, 1);
        } catch (error) {
            session.warn(session, message, error.message);
            session.log('Error fetching images:', error);
        }
    }
};
