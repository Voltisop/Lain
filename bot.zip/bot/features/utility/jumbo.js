const { MessageEmbed, Util } = require('discord.js');

module.exports = {
    configuration: {
        name: 'jumbo',
        aliases: ['e', 'enlarge'],
        description: 'Enlarge an emoji',
        syntax: 'enlarge <emoji>',
        module: 'information'
    },
    run: async (session, message, args) => {
        const emoji = args[0];

        if (!emoji) {
            return session.command(module.exports, session, message)
        }

        let custom = Util.parseEmoji(emoji);
        const embed = new MessageEmbed()
            .setColor(session.color);

        if (custom.id) {
            embed.setImage(`https://cdn.discordapp.com/emojis/${custom.id}.${custom.animated ? "gif" : "png"}`);
            return message.channel.send({ embeds: [embed] });
        } else {
            return session.warn(session, message, 'Invalid emoji')
        }
    }
};
