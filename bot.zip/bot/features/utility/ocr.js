const axios = require('axios');
const formdata = require('form-data');

module.exports = {
    configuration: {
        name: 'ocr',
        aliases: ['read'],
        description: 'Extract text from an image',
        syntax: 'ocr [attachment]',
        module: 'utility'
    },
    run: async (session, message, args) => {
        let imageURL;

        if (message.attachments.size === 1) {
            imageURL = message.attachments.first().url;
        } else if (args.length === 1 && (args[0].startsWith('http://') || args[0].startsWith('https://'))) {
            imageURL = args[0];
        } else {
            return session.command(module.exports, session, message);
        }

        const data = new formdata();
        data.append('url', imageURL);
        data.append('language', 'eng');
        data.append('scale', 'true');
        data.append('OCREngine', '2');

        try {
            const response = await axios.post('https://api.ocr.space/parse/image', data, {
                headers: {
                    apikey: session.ocr,
                    ...data.getHeaders()
                },
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            const text = response.data?.ParsedResults?.[0]?.ParsedText;

            if (text !== undefined) {
                session.neutral(session, message, `${text}`)
            } else {
                session.warn(session, message, 'Couldn\t find text in that image')
            }
        } catch (error) {
            session.log('Error occured fetching text from image', error)
            session.warn(session, message, 'An error occured')
        }
    }
};
