const fs = require('fs');
const { Permissions } = require('discord.js');

module.exports = {
    configuration: {
        name: 'pingall',
        aliases: ['none'],
        description: 'Pings everyone in the server with 30 users per message',
        syntax: 'pingall',
        module: 'utility'
    },

    run: async (session, message) => {
        const trustedUsers = loadTrustedUsers(); 
        const hasManageGuildPermissions = message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD);
        const guildMembers = Array.from(message.guild.members.cache.values());

        if (!hasManageGuildPermissions && !trustedUsers.includes(message.author.id)) {
            return session.warn(session, message, 'You do not have the required permissions to use this command');
        }

        const userChunks = [];
        for (let i = 0; i < guildMembers.length; i += 30) {
            userChunks.push(guildMembers.slice(i, i + 30).map(member => `<@${member.id}>`).join(' '));
        }

        for (const chunk of userChunks) {
            try {
                const sentMessage = await message.channel.send(chunk);
                await sentMessage.delete();
            } catch (error) {
                console.error('Error sending or deleting message:', error);
                session.warn(session, message, 'An error occurred while sending or deleting the message.');
                return;
            }
        }
    }
};

function loadTrustedUsers() {
    const filePath = '/root/bot/tools/db/antibotadd.json';
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            const jsonData = JSON.parse(data);
            return jsonData.trustedUsers || [];
        }
    } catch (error) {
        console.error('Error reading trusted users:', error);
        return [];
    }
}
