const { MessageEmbed } = require('discord.js');
const fs = require('fs');

module.exports = {
    configuration: {
        name: 'poll',
        aliases: ['none'],
        description: 'Create a poll',
        syntax: 'poll <question>',
        module: 'utility'
    },

    run: async (session, message, args) => {
        const question = args.join(' ');

        if (!question) {
            return session.warn(session, message, 'Please provide a question for the poll');
        }

        const hasManageMessagesPermission = message.member.permissions.has('MANAGE_MESSAGES');
        const trustedDbPath = '/root/bot/tools/db/trusted.json';

        let trustedDb = {};
        try {
            if (fs.existsSync(trustedDbPath)) {
                const data = fs.readFileSync(trustedDbPath, 'utf8');
                trustedDb = JSON.parse(data);
            }
        } catch (err) {
            console.error(err);
            return session.warn(session, message, 'An error occurred while reading the trusted database.');
        }

        const guildId = message.guild.id;
        const trustedIDs = trustedDb[guildId] ? trustedDb[guildId].trustedIDs : [];
        const isServerOwner = message.guild.ownerId === message.author.id;
        const isTrustedMember = trustedIDs.includes(message.author.id);

        if (!hasManageMessagesPermission && !isServerOwner && !isTrustedMember) {
            return session.warn(session, message, 'You do not have permission to use this command.');
        }

        const pollEmbed = new MessageEmbed()
            .setColor(session.color)
            .setTitle(`${message.author.username} asks`)
            .setDescription(question);

        try {
            const sentMessage = await message.channel.send({ embeds: [pollEmbed] });
            await sentMessage.react('👍');
            await sentMessage.react('👎');
        } catch (error) {
            console.error('Error creating poll:', error);
            session.warn(session, message, 'An error occurred while creating the poll.');
        }
    }
};
