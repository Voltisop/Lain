const { MessageAttachment } = require('discord.js');
const sharp = require('sharp');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = {
    configuration: {
        name: 'rotate',
        aliases: ['none'],
        description: 'Rotates the given image by the specified degrees',
        syntax: 'rotate <attachment> <degrees>',
        module: 'utility'
    },

    run: async (session, message, args) => {
        if (message.attachments.size === 0) {
            return session.warn(session, message, 'Please attach an image to rotate.');
        }

        const degrees = parseInt(args[0], 10);
        if (isNaN(degrees)) {
            return session.warn(session, message, 'Please specify a valid number of degrees to rotate the image.');
        }

        const attachment = message.attachments.first();
        const imageUrl = attachment.url;
        const imageExt = path.extname(attachment.name);

        if (!['.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tiff'].includes(imageExt.toLowerCase())) {
            return session.warn(session, message, 'Please attach a valid image file.');
        }

        try {
            const response = await axios({
                url: imageUrl,
                responseType: 'arraybuffer'
            });
            const buffer = Buffer.from(response.data, 'binary');

            sharp(buffer)
                .rotate(degrees)
                .toBuffer()
                .then(rotatedBuffer => {
                    const rotatedImagePath = path.join(__dirname, `rotated${imageExt}`);
                    
                    fs.writeFileSync(rotatedImagePath, rotatedBuffer);
                    const rotatedAttachment = new MessageAttachment(rotatedImagePath);

                    message.channel.send({ files: [rotatedAttachment] })
                        .then(() => {
                            fs.unlinkSync(rotatedImagePath);
                        })
                        .catch(error => {
                            console.error('Error sending rotated image:', error);
                            session.warn(session, message, 'An error occurred while sending the rotated image.');
                        });
                })
                .catch(error => {
                    console.error('Error rotating image:', error);
                    session.warn(session, message, 'An error occurred while rotating the image.');
                });
        } catch (error) {
            console.error('Error fetching image:', error);
            session.warn(session, message, 'An error occurred while fetching the image.');
        }
    }
};
