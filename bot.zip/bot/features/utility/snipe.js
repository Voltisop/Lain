const moment = require("moment");
const { MessageEmbed } = require("discord.js");

module.exports = {
    configuration: {
        name: 'snipe',
        description: 'View a recently deleted message',
        aliases: ["s"],
        syntax: 'snipe',
        module: 'utility'
    },
    run: async (session, message, args) => {

        const snipes = session.snipes.get(message.channel.id);

        if (!snipes || snipes.length === 0) {
            return session.warn(session, message, "There are no messages to snipe");
        }

        const latestSnipe = snipes[0];

        const { msg, time, image } = latestSnipe;
        const username = msg.author.username;
        const avatar = msg.author.displayAvatarURL({ dynamic: true });

        const embed = new MessageEmbed()
            .setAuthor(`${msg.author.username}`, avatar)
            .setDescription(`${msg.content}`)
            .setImage(image)
            .setColor(session.color)
            .setFooter(`Deleted ${moment(time).fromNow()}`);

        if (msg.attachments.size > 0) {
            const attachments = msg.attachments.map((attachment) => attachment.url).join("\n");
            embed.addField("Attachments", attachments);
        }

        await message.channel.send({ embeds: [embed] });
    }
};
