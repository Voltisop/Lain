const axios = require('axios');
const { MessageEmbed } = require('discord.js');
const qs = require('qs');
const moment = require('moment-timezone');
const geo = require('geo-tz');

module.exports = {
    configuration: {
        name: 'timezone',
        aliases: ['tz'],
        description: 'View a location\'s timezone',
        syntax: 'timezone <city>',
        example: 'timezone Chicago',
        module: 'utility'
    },

    run: async (session, message, args) => {
        try {
            const query = args.join(' ');

            if (!query) {
                return session.command(module.exports, session, message);
            }

            const queryString = qs.stringify({
                q: query,
                limit: 1,
                appid: session.timezone
            });

            const response = await axios.get(`http://api.openweathermap.org/geo/1.0/direct?${queryString}`);

            const results = response.data;

            if (!results || results.length === 0) {
                return session.warn(session, message, 'Location not found');
            }

            const location = geo.find(results[0].lat, results[0].lon)[0];
            const time = moment.tz(new Date(), location).format('hh:mm A');

            return session.neutral(session, message, `The timezone for ${results[0].name} is ${location} and the current time is ${time}`);
        } catch (error) {
            session.log('Error sending a request to OpenWeatherMap:', error);
            return session.warn(session, message, error.message);
        }
    }
};
