const axios = require('axios');
const { MessageEmbed } = require('discord.js');

module.exports = {
    configuration: {
        name: 'urban',
        aliases: ['ud'],
        description: 'Search ',
        syntax: 'urban <word>',
        example: 'urban meme',
        module: 'utility'
    },

    run: async (session, message, args) => {
        const word = args.join(' ');
        const data = json.list[0];
        try {
            const response = await axios.get(`http://api.urbandictionary.com/v0/define?term=${word}`);
            const json = response.data;

            if (!json.list || json.list.length === 0) {
                return session.warn(session, message, 'No results found');
            }

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setTitle(data.word)
                        .setURL(data.permalink)
                        .setDescription(`${data.definition}`)
                        .addFields(
                            { name: "Example", value: `${data.example}`, inline: false }
                        )
                ]
            });
        } catch (error) {
            session.log('Error sending a request to Urban Dictionary:', error);
            session.warn(session, message, error.message);
        }
    }
};
