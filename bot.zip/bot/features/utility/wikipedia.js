const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
    configuration: {
        name: 'wikipedia',
        aliases: ['wiki'],
        description: 'Search wiki for a query',
        syntax: 'wikipedia <query>',
        example: 'wikipedia earth',
        module: 'utility'
    },
    run: async (session, message, args) => {
        if (!args.length) {
            return session.command(module.exports, session, message);
        }

        const query = args.join(' ');

        try {
            const response = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
            const res = response.data;

            if (!res || res.title === 'Not found.') {
                return session.warn(session, message, 'No results found');
            }

            const arr = [];
            const content_urls = res.content_urls;

            if (content_urls) {
                if (content_urls.desktop.page) arr.push(content_urls.desktop.page);
                if (content_urls.desktop.revisions) arr.push(content_urls.desktop.revisions);
                if (content_urls.desktop.edit) arr.push(content_urls.desktop.edit);
                if (content_urls.desktop.talk) arr.push(content_urls.desktop.talk);
            }

            const embed = new MessageEmbed()
                .setAuthor(message.author.username, message.author.avatarURL({ dynamic: true }))
                .setTitle(res.title)
                .setColor(session.color)
                .setDescription(res.description || 'UNKNOWN_SEARCH_TERM');

            if (arr.length) embed.addField('Pages', arr.join('\n'));

            message.channel.send({ embeds: [embed] });

        } catch (error) {
            session.log('Error sending a request to Wikipedia:', error);
            session.warn(session, message, error.message);
        }
    }
};
