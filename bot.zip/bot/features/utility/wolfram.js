const WolframAlpha = require('@dguttman/wolfram-alpha-api');

module.exports = {
    configuration: {
        name: 'wolfram',
        aliases: ['w'],
        description: 'Get math answers',
        syntax: 'wolfram <query>',
        example: 'wolfram 2+2',
        module: 'utility'
    },

    run: async (session, message, args) => {
        try {
            if (!args[0]) {
                return session.command(module.exports, session, message);
            }

            const wolframAlphaApi = new WolframAlpha(session.wolfram);
            const results = await wolframAlphaApi.getShort(args.join(' '));

            if (!results) {
                return session.warn(session, message, 'No results found');
            }

            return session.neutral(session, message, `\`\`\`${results}\`\`\``);
        } catch (error) {
            session.log('Error sending a request to Wolfram Alpha:', error);
            session.warn(session, message, error.message);
        }
    }
};
