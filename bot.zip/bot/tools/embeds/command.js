const { MessageEmbed } = require('discord.js');
const fs = require('fs');

function embeds(guildID) {
    try {
        const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json', 'utf8'));
        return embedsConfig[guildID] || false;
    } catch (error) {
        console.error(`Error reading embeds config for guild ${guildID}:`, error);
        return false;
    }
}

function command(command, session, message) {
    try {
        if (!command || !session || !message) {
            console.error('Invalid arguments provided to command function:', { command, session, message });
            return message.channel.send('An error occurred while processing the command.');
        }

        if (!message.guild) {
            console.error('Message does not belong to a guild:', message);
            return message.channel.send('This command can only be used in a server.');
        }

        if (!message.guild.id) {
            console.error('Guild ID is undefined:', message.guild);
            return message.channel.send('An error occurred while processing the command.');
        }

        if (!session.color || !session.prefix) {
            console.error('Session properties are undefined:', session);
            return message.channel.send('An error occurred while processing the command.');
        }

        if (!command.configuration || !command.configuration.syntax || !command.configuration.aliases || !command.configuration.description) {
            console.error('Command configuration is incomplete:', command.configuration);
            return message.channel.send('An error occurred while processing the command.');
        }

        const commandInfo = new MessageEmbed()
            .setColor(session.color)
            .setAuthor(`${session.user.username} help`, session.user.displayAvatarURL())
            .setTitle(`__${command.configuration.name}__`)
            .setDescription(`${command.configuration.description || 'No description has been set'}`)
            .addField('Aliases', `${command.configuration.aliases.join(', ') || 'N/A'}`, true)
            .addField('Module', `${command.configuration.module}`, true)
            .addField('Usage:', `\`\`\`${command.configuration.syntax || 'No syntax has been set'}\`\`\``);

        if (command.configuration.subcommands && command.configuration.subcommands.length > 0) {
            commandInfo.addField('Subcommands', `${command.configuration.subcommands.join(', ')}`, true);
        }

        return message.channel.send({ embeds: [commandInfo] });
    } catch (error) {
        console.error('Error executing command function:', error);
        console.error('Command:', command);
        console.error('Session:', session);
        console.error('Message:', message);
        return message.channel.send('An error occurred while processing the command.');
    }
}

module.exports = {
    command
};
