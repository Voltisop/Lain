const { MessageEmbed } = require('discord.js');
const fs = require('fs');

function embeds(guildID) {
    const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json'));

    return embedsConfig[guildID] || false;
}

function grant(session, message, error) {
    if (message.guild && message.guild.available) {
        const embedsEnabled = embeds(message.guild.id);
        if (embedsEnabled) {
            const embed = new MessageEmbed()
                .setColor('#a9e97a')
                .setDescription(`<:approve:1249773912212901907> ${message.author}: ${error}`);

            return message.channel.send({ embeds: [embed] });
        }
    }
    return message.channel.send(error);
}

module.exports = {
    grant
};
