const { MessageEmbed } = require('discord.js');
const fs = require('fs');

function embeds(guildID) {
    const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json'));

    return embedsConfig[guildID] || false;
}

function cleanContent(content) {
    return content.replace(/@(here|everyone|&\d+)/g, '@\u200B$1');
}

function neutral(session, message, error) {
    if (message.guild && message.guild.available) {
        const embedsEnabled = embeds(message.guild.id);

        if (embedsEnabled) {
            const embed = new MessageEmbed()
                .setColor(session.color)
                .setDescription(`> ${message.author}: ${cleanContent(error)}`);

            return message.channel.send({ embeds: [embed] });
        }
    }

    return message.channel.send(cleanContent(error));
}

module.exports = {
    neutral
};
