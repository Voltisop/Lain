const { MessageEmbed } = require('discord.js');
const fs = require('fs');

function embeds(guildID) {
    const embedsConfig = JSON.parse(fs.readFileSync('/root/bot/tools/db/embeds.json'));

    return embedsConfig[guildID] || false;
}

function warn(session, message, error) {
    if (message.guild && message.guild.available) {
        const embedsEnabled = embeds(message.guild.id);

        if (embedsEnabled) {
            const embed = new MessageEmbed()
                .setColor('#FFCC00')
                .setDescription(`<:warning:1249773911823089664> ${message.author}: ${error}`);

            return message.channel.send({ embeds: [embed] });
        }
    }

    return message.channel.send(error);
}

module.exports = {
    warn
};
